from datetime import datetime


class TicketEventProcessor:
    """
    Processes ticket events safely.

    Handles:
    - Duplicate events
    - Delayed events
    - Out-of-order events
    """

    def __init__(self):

        # Stores the latest state of every ticket
        self.ticket_state = {}

        # Stores processed event IDs for duplicate detection
        self.processed_events = set()

        # Stores rejected/ignored events for auditing
        self.event_log = []


    def process_event(self, event):
        """
        Process one incoming ticket event.
        """

        event_id = event["event_id"]
        ticket_id = event["ticket_id"]
        event_timestamp = event["event_timestamp"]
        event_version = event["event_version"]

        # ------------------------------------------
        # 1. DUPLICATE EVENT DETECTION
        # ------------------------------------------

        if event_id in self.processed_events:

            result = {
                "status": "DUPLICATE_IGNORED",
                "ticket_id": ticket_id,
                "event_id": event_id,
                "message": (
                    "Duplicate event detected. "
                    "State was not changed."
                )
            }

            self.event_log.append(result)

            return result


        # Mark event as processed
        self.processed_events.add(event_id)


        # ------------------------------------------
        # 2. FIRST EVENT FOR THIS TICKET
        # ------------------------------------------

        if ticket_id not in self.ticket_state:

            self.ticket_state[ticket_id] = {
                "latest_version": event_version,
                "latest_timestamp": event_timestamp,
                "event_type": event["event_type"],
                "data": event.get("data", {})
            }

            result = {
                "status": "APPLIED",
                "ticket_id": ticket_id,
                "event_id": event_id,
                "message": (
                    "First event applied successfully."
                )
            }

            self.event_log.append(result)

            return result


        # ------------------------------------------
        # 3. CHECK EVENT ORDER
        # ------------------------------------------

        current_state = self.ticket_state[ticket_id]

        current_version = current_state["latest_version"]


        # Older event version
        if event_version < current_version:

            result = {
                "status": "OUT_OF_ORDER_IGNORED",
                "ticket_id": ticket_id,
                "event_id": event_id,
                "message": (
                    "Older event received after a newer "
                    "event. State was not overwritten."
                )
            }

            self.event_log.append(result)

            return result


        # Same version but different event ID
        if event_version == current_version:

            result = {
                "status": "STALE_EVENT_IGNORED",
                "ticket_id": ticket_id,
                "event_id": event_id,
                "message": (
                    "Event version is not newer than "
                    "the current state."
                )
            }

            self.event_log.append(result)

            return result


        # ------------------------------------------
        # 4. NEWER EVENT
        # ------------------------------------------

        self.ticket_state[ticket_id] = {
            "latest_version": event_version,
            "latest_timestamp": event_timestamp,
            "event_type": event["event_type"],
            "data": event.get("data", {})
        }

        result = {
            "status": "APPLIED",
            "ticket_id": ticket_id,
            "event_id": event_id,
            "message": "Newer event applied successfully."
        }

        self.event_log.append(result)

        return result


    def get_ticket_state(self, ticket_id):
        """
        Return the current state of a ticket.
        """

        return self.ticket_state.get(ticket_id)


# ==========================================
# TEST FAILURE SCENARIOS
# ==========================================

if __name__ == "__main__":

    processor = TicketEventProcessor()


    # ======================================
    # TEST 1: NORMAL EVENT
    # ======================================

    event_1 = {
        "event_id": "E001",
        "ticket_id": "T1001",
        "event_type": "TICKET_CREATED",
        "event_timestamp": "2026-08-27T09:00:00",
        "event_version": 1,
        "data": {
            "priority": "P2",
            "message": "EHR service degraded"
        }
    }

    print("\n===== TEST 1: NORMAL EVENT =====")

    print(
        processor.process_event(event_1)
    )


    # ======================================
    # TEST 2: DUPLICATE EVENT
    # ======================================

    duplicate_event = event_1.copy()

    print("\n===== TEST 2: DUPLICATE EVENT =====")

    print(
        processor.process_event(duplicate_event)
    )


    # ======================================
    # TEST 3: NEWER EVENT
    # ======================================

    event_2 = {
        "event_id": "E002",
        "ticket_id": "T1001",
        "event_type": "PRIORITY_UPDATED",
        "event_timestamp": "2026-08-27T09:05:00",
        "event_version": 2,
        "data": {
            "priority": "P1",
            "message": "Issue escalated to critical"
        }
    }

    print("\n===== TEST 3: NEWER EVENT =====")

    print(
        processor.process_event(event_2)
    )


    # ======================================
    # TEST 4: OUT-OF-ORDER EVENT
    # ======================================

    delayed_old_event = {
        "event_id": "E003",
        "ticket_id": "T1001",
        "event_type": "PRIORITY_UPDATED",
        "event_timestamp": "2026-08-27T09:02:00",
        "event_version": 1,
        "data": {
            "priority": "P3",
            "message": "Older update arrived late"
        }
    }

    print("\n===== TEST 4: OUT-OF-ORDER EVENT =====")

    print(
        processor.process_event(
            delayed_old_event
        )
    )


    # ======================================
    # FINAL STATE CHECK
    # ======================================

    print("\n===== FINAL TICKET STATE =====")

    print(
        processor.get_ticket_state("T1001")
    )
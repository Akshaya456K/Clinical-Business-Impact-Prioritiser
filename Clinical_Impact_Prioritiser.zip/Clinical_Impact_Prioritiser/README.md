# Clinical Business-Impact Prioritiser

An AI-assisted incident prioritisation system designed for hospital IT teams to identify urgent clinical and business-impacting service failures among routine support requests.

## Problem Statement

Hospital IT teams support clinical systems around the clock. Urgent patient-facing failures can be hidden among routine IT requests.

This project prioritises hospital IT tickets based on ticket content and operational context, helping identify high-impact incidents that may require faster escalation.

## Key Features

- Rule-based baseline prioritisation
- Machine learning-based priority prediction
- Four priority levels: P1, P2, P3 and P4
- High-impact incident detection for P1 and P2 incidents
- Evidence and explanation layer
- Safety checks and fallback workflow
- Human review for uncertain or failed predictions
- Duplicate event detection
- Delayed and out-of-order event handling
- Performance evaluation against a target processing time
- Multi-page Streamlit application

## Dataset

The project uses a synthetic hospital IT ticket dataset.

- Total tickets: 2,000
- Training samples: 1,600
- Testing samples: 400
- Missing values: 0
- Duplicate rows: 0

Priority distribution:

| Priority | Tickets |
|----------|--------:|
| P1 | 200 |
| P2 | 400 |
| P3 | 600 |
| P4 | 800 |

The dataset includes ticket content, affected service, user group, operating schedule, impact scope and escalation outcome.

## Results

| Metric | Result |
|--------|-------:|
| Baseline Accuracy | 59.25% |
| ML Model Accuracy | 99.75% |
| Improvement | 40.50 percentage points |
| High-Impact Precision | 100% |
| High-Impact Recall | 100% |
| High-Impact F1 Score | 100% |
| Average Processing Time | 0.0946 ms |
| Target Processing Time | 1000 ms |
| Target Achieved | Yes |

The results were obtained using a held-out synthetic test dataset.

## Failure-State Testing

The system was tested against the following scenarios:

1. **Duplicate Events**  
   Repeated events are detected and do not corrupt ticket state.

2. **Out-of-Order Events**  
   Older events cannot overwrite newer ticket information.

3. **Delayed Events**  
   The latest valid ticket state is preserved when delayed events arrive.

## Application

The Streamlit application includes:

- **Operations Dashboard** — Incident and escalation overview
- **Prioritise Ticket** — AI-assisted priority prediction
- **Active Incident Queue** — View and filter high-impact incidents
- **System Monitoring** — Model and performance metrics
- **Failure and Recovery** — Event failure-state demonstrations
- **Responsible AI** — Safety controls, limitations and deployment checklist

## Project Structure

```text
clinical_impact_prioritiser/
│
├── app.py
├── baseline.py
├── train_model.py
├── predict.py
├── decision_engine.py
├── event_processor.py
├── safety.py
├── evaluate_system.py
├── hospital_it_tickets.csv
├── README.md
├── requirements.txt
│
├── models/
├── reports/
│
└── .streamlit/
    └── config.toml


## Installation

```powershell
python -m venv .venv
.venv\Scripts\Activate.ps1
pip install -r requirements.txt
Running the Application

Start the Streamlit application:

streamlit run app.py

##Responsible AI Considerations

This project is designed as a decision-support prototype and does not replace clinical or operational judgement.

The system includes:

Input validation
Evidence for high-impact predictions
Human review pathways
Fallback behaviour for prediction failures
Event-state protection
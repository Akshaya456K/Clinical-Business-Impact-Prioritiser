import streamlit as st
import pandas as pd
import plotly.express as px
from pathlib import Path

from decision_engine import process_ticket
from event_processor import TicketEventProcessor


# =========================================================
# PAGE CONFIGURATION
# =========================================================

st.set_page_config(
    page_title="Clinical Impact Prioritiser",
    page_icon="C",
    layout="wide",
    initial_sidebar_state="expanded"
)


# =========================================================
# CUSTOM CSS
# =========================================================

st.markdown("""
<style>

/* ---------------- GLOBAL ---------------- */

.stApp {
    background-color: #F4F7FB;
}

.main .block-container {
    padding-top: 2rem;
    padding-bottom: 2rem;
    max-width: 1400px;
}

h1 {
    color: #17365D !important;
    font-weight: 700 !important;
}

h2, h3 {
    color: #1F4E79 !important;
}

p, span, label {
    color: #1F2937;
}


/* ---------------- SIDEBAR ---------------- */

section[data-testid="stSidebar"] {
    background-color: #17365D;
}

section[data-testid="stSidebar"] * {
    color: #FFFFFF !important;
}

section[data-testid="stSidebar"] .stRadio label {
    padding: 6px 0px;
}


/* ---------------- METRICS ---------------- */

[data-testid="stMetric"] {
    background-color: #FFFFFF;
    border: 1px solid #D9E2EC;
    border-radius: 12px;
    padding: 18px;
    box-shadow: 0px 3px 10px rgba(0,0,0,0.05);
}

[data-testid="stMetricLabel"] {
    color: #52606D !important;
}

[data-testid="stMetricValue"] {
    color: #17365D !important;
}


/* ---------------- BUTTONS ---------------- */

.stButton > button {
    background-color: #17365D;
    color: #FFFFFF;
    border-radius: 8px;
    border: none;
    font-weight: 600;
    padding: 10px 20px;
}

.stButton > button:hover {
    background-color: #1F4E79;
    color: #FFFFFF;
}

[data-testid="stFormSubmitButton"] button {
    background-color: #17365D;
    color: #FFFFFF;
    border-radius: 8px;
    border: none;
    font-weight: 600;
}


/* ---------------- CARDS ---------------- */

.info-card {
    background-color: #FFFFFF;
    border: 1px solid #D9E2EC;
    border-radius: 12px;
    padding: 22px;
    margin-bottom: 15px;
    box-shadow: 0px 3px 10px rgba(0,0,0,0.04);
}

.info-card h3 {
    margin-top: 0px;
}


/* ---------------- PRIORITY CARDS ---------------- */

.priority-p1 {
    background-color: #FDECEC;
    border-left: 7px solid #C62828;
    padding: 24px;
    border-radius: 10px;
    margin-top: 15px;
}

.priority-p1 h2,
.priority-p1 h3 {
    color: #7F1D1D !important;
}


.priority-p2 {
    background-color: #FFF3E0;
    border-left: 7px solid #EF6C00;
    padding: 24px;
    border-radius: 10px;
    margin-top: 15px;
}

.priority-p2 h2,
.priority-p2 h3 {
    color: #7C2D12 !important;
}


.priority-p3 {
    background-color: #FFF9DB;
    border-left: 7px solid #B7791F;
    padding: 24px;
    border-radius: 10px;
    margin-top: 15px;
}

.priority-p3 h2,
.priority-p3 h3 {
    color: #713F12 !important;
}


.priority-p4 {
    background-color: #E8F5E9;
    border-left: 7px solid #2E7D32;
    padding: 24px;
    border-radius: 10px;
    margin-top: 15px;
}

.priority-p4 h2,
.priority-p4 h3 {
    color: #14532D !important;
}


/* ---------------- SECTION LABELS ---------------- */

.section-label {
    color: #52606D;
    font-size: 15px;
}


/* ---------------- ALERT TEXT ---------------- */

[data-testid="stAlert"] * {
    color: #1F2937 !important;
}


/* ---------------- DIVIDERS ---------------- */

hr {
    border-color: #D9E2EC;
}

</style>
""", unsafe_allow_html=True)


# =========================================================
# PROJECT PATHS
# =========================================================

BASE_DIR = Path(__file__).resolve().parent

DATA_PATH = BASE_DIR / "hospital_it_tickets.csv"


# =========================================================
# LOAD DATA
# =========================================================

@st.cache_data
def load_dataset():

    return pd.read_csv(DATA_PATH)


df = load_dataset()


# =========================================================
# HELPER FUNCTIONS
# =========================================================

def get_high_impact_count():

    return len(
        df[
            df["priority"].isin(["P1", "P2"])
        ]
    )


def get_p1_count():

    return len(
        df[
            df["priority"] == "P1"
        ]
    )


def get_escalated_count():

    return len(
        df[
            df["escalation_outcome"]
            .isin([
                "Escalated",
                "Emergency Escalation"
            ])
        ]
    )


def create_operational_queue():

    queue_columns = [
        col for col in [
            "ticket_id",
            "affected_service",
            "user_group",
            "operating_schedule",
            "scope",
            "priority",
            "escalation_outcome"
        ]
        if col in df.columns
    ]

    queue = df[
        df["priority"].isin(["P1", "P2"])
    ][queue_columns].copy()

    return queue


# =========================================================
# SIDEBAR
# =========================================================

st.sidebar.markdown("# Clinical Impact")
st.sidebar.markdown("### Prioritiser")

st.sidebar.markdown("---")

page = st.sidebar.radio(
    "Navigation",
    [
        "Operations Dashboard",
        "Prioritise Ticket",
        "Active Incident Queue",
        "System Monitoring",
        "Failure and Recovery",
        "Responsible AI"
    ]
)

st.sidebar.markdown("---")

st.sidebar.markdown("""
### System Status

Model Service: Online

Safety Layer: Active

Event Processor: Active

Fallback Workflow: Ready
""")

st.sidebar.markdown("---")

st.sidebar.caption(
    "Clinical Business-Impact Prioritiser"
)


# =========================================================
# PAGE 1: OPERATIONS DASHBOARD
# =========================================================

if page == "Operations Dashboard":

    st.title("Clinical IT Operations Dashboard")

    st.markdown(
        """
        <p class="section-label">
        Overview of incident prioritisation performance and
        operational risk indicators.
        </p>
        """,
        unsafe_allow_html=True
    )

    st.markdown("---")

    high_impact = get_high_impact_count()
    p1_count = get_p1_count()
    escalated_count = get_escalated_count()

    col1, col2, col3, col4 = st.columns(4)

    col1.metric(
        "Total Tickets Analysed",
        f"{len(df):,}"
    )

    col2.metric(
        "High-Impact Incidents",
        f"{high_impact:,}"
    )

    col3.metric(
        "Critical P1 Incidents",
        f"{p1_count:,}"
    )

    col4.metric(
        "Escalated Incidents",
        f"{escalated_count:,}"
    )

    st.markdown("---")

    st.subheader("Operational Overview")

    left, right = st.columns(2)

    with left:

        priority_summary = (
            df["priority"]
            .value_counts()
            .reindex(["P1", "P2", "P3", "P4"])
            .reset_index()
        )

        priority_summary.columns = [
            "Priority",
            "Tickets"
        ]

        fig = px.bar(
            priority_summary,
            x="Priority",
            y="Tickets",
            text="Tickets",
            title="Incident Priority Distribution"
        )

        fig.update_layout(
            xaxis_title="Priority",
            yaxis_title="Number of Tickets"
        )

        st.plotly_chart(
            fig,
            use_container_width=True
        )

    with right:

        escalation_summary = (
            df["escalation_outcome"]
            .value_counts()
            .reset_index()
        )

        escalation_summary.columns = [
            "Outcome",
            "Tickets"
        ]

        fig = px.bar(
            escalation_summary,
            x="Outcome",
            y="Tickets",
            text="Tickets",
            title="Escalation Outcomes"
        )

        st.plotly_chart(
            fig,
            use_container_width=True
        )

    st.markdown("---")

    st.subheader("Prioritisation Workflow")

    col1, col2, col3 = st.columns(3)

    with col1:

        st.markdown("""
        <div class="info-card">

        <h3>1. Incident Intake</h3>

        Ticket information is received from
        hospital IT support workflows.

        </div>
        """, unsafe_allow_html=True)

    with col2:

        st.markdown("""
        <div class="info-card">

        <h3>2. Impact Analysis</h3>

        The prioritiser evaluates ticket content
        and structured business-impact context.

        </div>
        """, unsafe_allow_html=True)

    with col3:

        st.markdown("""
        <div class="info-card">

        <h3>3. Safe Decision</h3>

        The system provides a priority,
        supporting evidence and escalation action.

        </div>
        """, unsafe_allow_html=True)


# =========================================================
# PAGE 2: PRIORITISE TICKET
# =========================================================

elif page == "Prioritise Ticket":

    st.title("Clinical IT Ticket Prioritisation")

    st.markdown(
        """
        Enter the incident information below.
        The system will generate a priority recommendation,
        evidence and a safe operational action.
        """
    )

    st.markdown("---")

    with st.form("priority_form"):

        ticket_content = st.text_area(
            "Incident Description",
            placeholder=(
                "Describe the incident, affected users "
                "and operational or clinical impact..."
            ),
            height=160
        )

        col1, col2 = st.columns(2)

        with col1:

            affected_service = st.selectbox(
                "Affected Service",
                sorted(
                    df["affected_service"].unique()
                )
            )

            user_group = st.selectbox(
                "Affected User Group",
                sorted(
                    df["user_group"].unique()
                )
            )

        with col2:

            operating_schedule = st.selectbox(
                "Operating Schedule",
                sorted(
                    df["operating_schedule"].unique()
                )
            )

            scope = st.selectbox(
                "Impact Scope",
                sorted(
                    df["scope"].unique()
                )
            )

        submitted = st.form_submit_button(
            "Analyse Ticket",
            use_container_width=True
        )

    if submitted:

        if not ticket_content.strip():

            st.error(
                "A ticket description is required."
            )

        else:

            ticket = {
                "ticket_content": ticket_content,
                "affected_service": affected_service,
                "user_group": user_group,
                "operating_schedule": operating_schedule,
                "scope": scope
            }

            with st.spinner(
                "Analysing incident impact..."
            ):

                result = process_ticket(ticket)

            st.markdown("---")

            # Fallback
            if result["status"] in [
                "FALLBACK",
                "MODEL_FAILURE"
            ]:

                st.error(
                    "Fallback Workflow Activated"
                )

                st.markdown(
                    "### Reason"
                )

                st.write(
                    result.get(
                        "reason",
                        "Prediction could not be completed."
                    )
                )

                errors = result.get(
                    "errors",
                    []
                )

                if errors:

                    st.markdown(
                        "### Validation Details"
                    )

                    for error in errors:

                        st.write(
                            f"- {error}"
                        )

                st.info(
                    "The ticket should be routed to "
                    "a human operator for manual assessment."
                )

            else:

                priority = result[
                    "predicted_priority"
                ]

                priority_class = (
                    "priority-" +
                    priority.lower()
                )

                confidence = result.get(
                    "confidence",
                    0
                )

                st.markdown(
                    f"""
                    <div class="{priority_class}">
                    <h2>Predicted Priority: {priority}</h2>
                    <h3>Model Confidence: {confidence}%</h3>
                    </div>
                    """,
                    unsafe_allow_html=True
                )

                st.markdown("---")

                st.subheader(
                    "Recommended Operational Action"
                )

                action = result.get(
                    "action",
                    "HUMAN_REVIEW"
                )

                if action == "URGENT_ESCALATION":

                    st.error(
                        "Urgent escalation required."
                    )

                elif action == "PRIORITY_ESCALATION":

                    st.warning(
                        "Priority escalation required."
                    )

                elif action == "HUMAN_REVIEW":

                    st.warning(
                        "Human review required."
                    )

                else:

                    st.success(
                        "Prediction accepted for normal workflow."
                    )

                st.write(
                    result.get(
                        "reason",
                        ""
                    )
                )

                st.markdown("---")

                st.subheader(
                    "Supporting Evidence"
                )

                evidence = result.get(
                    "evidence",
                    []
                )

                if evidence:

                    for item in evidence:

                        st.info(
                            item
                        )

                else:

                    st.warning(
                        "No additional evidence was generated."
                    )

                st.markdown("---")

                st.subheader(
                    "Priority Probability Distribution"
                )

                probabilities = result.get(
                    "probabilities",
                    {}
                )

                if probabilities:

                    probability_df = pd.DataFrame(
                        list(
                            probabilities.items()
                        ),
                        columns=[
                            "Priority",
                            "Probability"
                        ]
                    )

                    fig = px.bar(
                        probability_df,
                        x="Priority",
                        y="Probability",
                        text="Probability"
                    )

                    fig.update_layout(
                        yaxis_title="Probability (%)"
                    )

                    st.plotly_chart(
                        fig,
                        use_container_width=True
                    )


# =========================================================
# PAGE 3: ACTIVE INCIDENT QUEUE
# =========================================================

elif page == "Active Incident Queue":

    st.title("Active High-Impact Incident Queue")

    st.markdown(
        """
        Operational view of incidents classified as
        P1 or P2 and requiring increased attention.
        """
    )

    st.markdown("---")

    queue = create_operational_queue()

    col1, col2, col3 = st.columns(3)

    with col1:

        priority_filter = st.multiselect(
            "Priority",
            options=["P1", "P2"],
            default=["P1", "P2"]
        )

    with col2:

        services = sorted(
            queue["affected_service"].unique()
        )

        service_filter = st.multiselect(
            "Affected Service",
            options=services,
            default=services
        )

    with col3:

        outcomes = sorted(
            queue["escalation_outcome"].unique()
        )

        outcome_filter = st.multiselect(
            "Escalation Status",
            options=outcomes,
            default=outcomes
        )

    filtered_queue = queue[
        (queue["priority"].isin(priority_filter))
        &
        (
            queue["affected_service"]
            .isin(service_filter)
        )
        &
        (
            queue["escalation_outcome"]
            .isin(outcome_filter)
        )
    ]

    col1, col2, col3 = st.columns(3)

    col1.metric(
        "Active High-Impact Queue",
        len(filtered_queue)
    )

    col2.metric(
        "P1 Incidents",
        len(
            filtered_queue[
                filtered_queue["priority"] == "P1"
            ]
        )
    )

    col3.metric(
        "P2 Incidents",
        len(
            filtered_queue[
                filtered_queue["priority"] == "P2"
            ]
        )
    )

    st.markdown("---")

    display_columns = [
        col for col in [
            "ticket_id",
            "affected_service",
            "user_group",
            "operating_schedule",
            "scope",
            "priority",
            "escalation_outcome"
        ]
        if col in filtered_queue.columns
    ]

    st.markdown("### Current High-Impact Incidents")

# Limit visible incidents for a cleaner dashboard
    display_queue = filtered_queue.head(10)

    for _, row in display_queue.iterrows():

        priority = row["priority"]

        if priority == "P1":
            priority_class = "priority-p1"
        else:
            priority_class = "priority-p2"

    st.markdown(
        f"""
        <div class="{priority_class}">

        <h3>Ticket {row["ticket_id"]} | {priority}</h3>

        <p>
        <b>Affected Service:</b> {row["affected_service"]}<br>
        <b>User Group:</b> {row["user_group"]}<br>
        <b>Operating Schedule:</b> {row["operating_schedule"]}<br>
        <b>Impact Scope:</b> {row["scope"]}<br>
        <b>Escalation Status:</b> {row["escalation_outcome"]}
        </p>

        </div>
        """,
        unsafe_allow_html=True
    )
    csv = filtered_queue.to_csv(
        index=False
    ).encode("utf-8")

    st.download_button(
        label="Export Operational Queue",
        data=csv,
        file_name="high_impact_incident_queue.csv",
        mime="text/csv"
    )

# =========================================================
# PAGE 4: SYSTEM MONITORING
# =========================================================

elif page == "System Monitoring":

    st.title("System Monitoring")

    st.markdown(
        """
        Evaluation metrics for the baseline and
        machine learning prioritisation systems.
        """
    )

    st.markdown("---")

    col1, col2, col3, col4 = st.columns(4)

    col1.metric(
        "Baseline Accuracy",
        "59.25%"
    )

    col2.metric(
        "ML Accuracy",
        "99.75%",
        "+40.50 points"
    )

    col3.metric(
        "High-Impact Recall",
        "100%"
    )

    col4.metric(
        "Average Processing Time",
        "0.0946 ms"
    )

    st.markdown("---")

    st.subheader(
        "Baseline vs Machine Learning"
    )

    comparison_df = pd.DataFrame({
        "System": [
            "Rule-Based Baseline",
            "Machine Learning Model"
        ],
        "Accuracy": [
            59.25,
            99.75
        ]
    })

    fig = px.bar(
        comparison_df,
        x="System",
        y="Accuracy",
        text="Accuracy"
    )

    fig.update_layout(
        yaxis_range=[0, 100],
        yaxis_title="Accuracy (%)"
    )

    st.plotly_chart(
        fig,
        use_container_width=True
    )

    st.markdown("---")

    st.subheader(
        "High-Impact Error Analysis"
    )

    error_df = pd.DataFrame({
        "Outcome": [
            "True Positives",
            "False Positives",
            "False Negatives",
            "True Negatives"
        ],
        "Count": [
            120,
            0,
            0,
            280
        ]
    })

    fig = px.bar(
        error_df,
        x="Outcome",
        y="Count",
        text="Count"
    )

    st.plotly_chart(
        fig,
        use_container_width=True
    )

    st.markdown("---")

    st.subheader(
        "Target Time Performance"
    )

    time_col1, time_col2, time_col3 = st.columns(3)

    time_col1.metric(
        "Target Per Ticket",
        "1000 ms"
    )

    time_col2.metric(
        "Measured Average",
        "0.0946 ms"
    )

    time_col3.metric(
        "Target Achieved",
        "Yes"
    )

    st.info(
        "High-impact incidents were prioritised within "
        "the defined target processing time."
    )


# =========================================================
# PAGE 5: FAILURE AND RECOVERY
# =========================================================

elif page == "Failure and Recovery":

    st.title("Failure-State and Recovery Testing")

    st.markdown(
        """
        This section demonstrates that the system handles
        abnormal event conditions without corrupting
        ticket state.
        """
    )

    st.markdown("---")

    scenario = st.selectbox(
        "Select Test Scenario",
        [
            "Duplicate Event",
            "Out-of-Order Event",
            "Delayed Event Recovery"
        ]
    )

    st.markdown(
        "Select a scenario and run the test."
    )

    if st.button(
        "Run Failure Test",
        use_container_width=True
    ):

        processor = TicketEventProcessor()

        if scenario == "Duplicate Event":

            event = {
                "event_id": "TEST-001",
                "ticket_id": "T-TEST-001",
                "event_type": "TICKET_CREATED",
                "event_timestamp": "2026-08-27T09:00:00",
                "event_version": 1,
                "data": {
                    "priority": "P2"
                }
            }

            first_result = processor.process_event(
                event
            )

            duplicate_result = processor.process_event(
                event
            )

            st.subheader("Initial Event")

            st.json(first_result)

            st.subheader("Duplicate Event")

            st.json(duplicate_result)

            st.success(
                "Duplicate event handling completed. "
                "Ticket state was not corrupted."
            )


        elif scenario == "Out-of-Order Event":

            newer_event = {
                "event_id": "TEST-002",
                "ticket_id": "T-TEST-002",
                "event_type": "PRIORITY_UPDATED",
                "event_timestamp": "2026-08-27T10:05:00",
                "event_version": 2,
                "data": {
                    "priority": "P1"
                }
            }

            older_event = {
                "event_id": "TEST-003",
                "ticket_id": "T-TEST-002",
                "event_type": "PRIORITY_UPDATED",
                "event_timestamp": "2026-08-27T10:00:00",
                "event_version": 1,
                "data": {
                    "priority": "P3"
                }
            }

            processor.process_event(
                newer_event
            )

            result = processor.process_event(
                older_event
            )

            final_state = (
                processor.get_ticket_state(
                    "T-TEST-002"
                )
            )

            st.subheader(
                "Out-of-Order Event Result"
            )

            st.json(result)

            st.subheader(
                "Final Ticket State"
            )

            st.json(final_state)

            st.success(
                "Older event was prevented from "
                "overwriting the newer ticket state."
            )


        else:

            event_v1 = {
                "event_id": "TEST-004",
                "ticket_id": "T-TEST-003",
                "event_type": "TICKET_CREATED",
                "event_timestamp": "2026-08-27T11:00:00",
                "event_version": 1,
                "data": {
                    "priority": "P3"
                }
            }

            event_v3 = {
                "event_id": "TEST-005",
                "ticket_id": "T-TEST-003",
                "event_type": "PRIORITY_UPDATED",
                "event_timestamp": "2026-08-27T11:10:00",
                "event_version": 3,
                "data": {
                    "priority": "P1"
                }
            }

            delayed_event_v2 = {
                "event_id": "TEST-006",
                "ticket_id": "T-TEST-003",
                "event_type": "PRIORITY_UPDATED",
                "event_timestamp": "2026-08-27T11:05:00",
                "event_version": 2,
                "data": {
                    "priority": "P2"
                }
            }

            processor.process_event(
                event_v1
            )

            processor.process_event(
                event_v3
            )

            delayed_result = (
                processor.process_event(
                    delayed_event_v2
                )
            )

            final_state = (
                processor.get_ticket_state(
                    "T-TEST-003"
                )
            )

            st.subheader(
                "Delayed Event Result"
            )

            st.json(delayed_result)

            st.subheader(
                "Recovered Ticket State"
            )

            st.json(final_state)

            st.success(
                "The latest valid state was preserved."
            )


# =========================================================
# PAGE 6: RESPONSIBLE AI
# =========================================================

elif page == "Responsible AI":

    st.title("Responsible AI and Deployment")

    st.markdown(
        """
        The prioritiser is designed as a decision-support
        system and not as a replacement for clinical or
        operational judgement.
        """
    )

    st.markdown("---")

    st.subheader("System Safety Controls")

    controls = pd.DataFrame({
        "Control": [
            "Input Validation",
            "Confidence Threshold",
            "Evidence Requirement",
            "Human Review",
            "Fallback Workflow",
            "Duplicate Detection",
            "Out-of-Order Protection"
        ],
        "Purpose": [
            "Reject incomplete or invalid ticket inputs",
            "Route uncertain predictions for review",
            "Provide supporting evidence for high-impact outputs",
            "Maintain human oversight of important decisions",
            "Provide a safe route when prediction fails",
            "Prevent duplicate events from being processed twice",
            "Prevent older events from overwriting newer state"
        ]
    })

    st.dataframe(
        controls,
        use_container_width=True,
        hide_index=True
    )

    st.markdown("---")

    st.subheader("Known Limitations")

    st.warning("""
The current prototype was evaluated using synthetic ticket data.

The near-perfect machine learning performance may reflect patterns
introduced during dataset generation and should not be assumed to
represent real-world hospital performance.

Before deployment, the system should be validated using representative
historical data and reviewed by relevant IT, clinical, governance and
security stakeholders.
""")

    st.markdown("---")

    st.subheader("Deployment Readiness Checklist")

    checklist = [
        "Validate with representative historical incident data",
        "Conduct stakeholder validation with hospital IT users",
        "Perform privacy and security assessment",
        "Protect patient-identifiable information",
        "Define escalation ownership and response procedures",
        "Monitor false positives and false negatives",
        "Monitor model drift and changing incident patterns",
        "Maintain decision and audit logs",
        "Test fallback and recovery workflows",
        "Define rollback and incident-response procedures"
    ]

    for item in checklist:

        st.checkbox(
            item,
            value=False,
            key=f"check_{item}"
        )

    st.markdown("---")

    st.subheader("Project Outcome")

    st.success("""
The prototype demonstrates an end-to-end clinical and business-impact
prioritisation workflow including:

- A rule-based baseline
- A machine learning prioritiser
- High-impact incident detection
- Evidence and explanation support
- Human review and fallback paths
- Duplicate, delayed and out-of-order event handling
- Performance measurement against a target processing time
""")
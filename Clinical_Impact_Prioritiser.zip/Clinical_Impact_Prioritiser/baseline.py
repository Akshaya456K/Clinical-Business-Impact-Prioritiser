import pandas as pd

from sklearn.metrics import (
    accuracy_score,
    classification_report,
    confusion_matrix
)

# Criticality scores for hospital services
SERVICE_SCORES = {
    "EHR": 4,
    "Medication Management": 4,
    "Nurse Call System": 4,
    "PACS/Radiology": 3,
    "Laboratory Information System": 3,
    "Hospital Network": 3,
    "Identity/Login": 2,
    "Email": 1,
    "Printing": 1,
    "Staff Portal": 1
}


# Impact scores based on affected users
USER_GROUP_SCORES = {
    "ICU Clinicians": 4,
    "Emergency Department Clinicians": 4,
    "Doctors": 3,
    "Nurses": 3,
    "Radiology Staff": 3,
    "Laboratory Staff": 3,
    "Administrative Staff": 1,
    "IT Staff": 1
}


# Impact scores based on scope
SCOPE_SCORES = {
    "Single User": 0,
    "Multiple Users": 2,
    "Department": 3,
    "Hospital-wide": 4
}


# Schedule importance
SCHEDULE_SCORES = {
    "24/7": 2,
    "Clinical Hours": 1,
    "Business Hours": 0,
    "Scheduled/Non-Critical": 0
}


def get_keyword_score(ticket_content):
    """
    Assign a score based on important words
    found in the ticket description.
    """

    text = str(ticket_content).lower()

    critical_keywords = [
        "completely unavailable",
        "system unavailable",
        "cannot access",
        "not reaching staff",
        "outage",
        "down",
        "failure"
    ]

    high_keywords = [
        "multiple users",
        "several users",
        "intermittently failing",
        "timing out",
        "severely degraded",
        "unable to"
    ]

    score = 0

    for keyword in critical_keywords:
        if keyword in text:
            score += 3

    for keyword in high_keywords:
        if keyword in text:
            score += 2

    return score


def calculate_risk_score(row):
    """
    Calculate the total risk score for one ticket.
    """

    score = 0

    score += SERVICE_SCORES.get(
        row["affected_service"], 0
    )

    score += USER_GROUP_SCORES.get(
        row["user_group"], 0
    )

    score += SCOPE_SCORES.get(
        row["scope"], 0
    )

    score += SCHEDULE_SCORES.get(
        row["operating_schedule"], 0
    )

    score += get_keyword_score(
        row["ticket_content"]
    )

    return score


def assign_priority(score):
    """
    Convert risk score into priority level.
    """

    if score >= 12:
        return "P1"

    elif score >= 8:
        return "P2"

    elif score >= 4:
        return "P3"

    else:
        return "P4"


def predict_priority(row):
    """
    Complete baseline prediction.
    """

    risk_score = calculate_risk_score(row)

    predicted_priority = assign_priority(
        risk_score
    )

    return predicted_priority, risk_score


if __name__ == "__main__":

    from pathlib import Path

    BASE_DIR = Path(__file__).resolve().parent
    DATA_PATH = BASE_DIR / "hospital_it_tickets.csv"

    print("Looking for dataset at:")
    print(DATA_PATH)

    df = pd.read_csv(DATA_PATH)
    # Calculate predictions
    results = df.apply(
        predict_priority,
        axis=1,
        result_type="expand"
    )

    # Store results
    df["baseline_priority"] = results[0]
    df["baseline_risk_score"] = results[1]

    # ==========================================
    # BASELINE EVALUATION
    # ==========================================

    y_true = df["priority"]
    y_pred = df["baseline_priority"]

# Overall accuracy
    accuracy = accuracy_score(y_true, y_pred)

    print("\n===== BASELINE EVALUATION =====")

    print(f"\nBaseline Accuracy: {accuracy:.4f}")
    print(f"Baseline Accuracy Percentage: {accuracy * 100:.2f}%")

# Classification report
    print("\n===== CLASSIFICATION REPORT =====\n")

    print(
        classification_report(
        y_true,
        y_pred,
        labels=["P1", "P2", "P3", "P4"],
        zero_division=0
    )
)

# Confusion matrix
    print("\n===== CONFUSION MATRIX =====\n")

    cm = confusion_matrix(
        y_true,
        y_pred,
        labels=["P1", "P2", "P3", "P4"]
)

    cm_df = pd.DataFrame(
        cm,
        index=["Actual_P1", "Actual_P2", "Actual_P3", "Actual_P4"],
        columns=["Predicted_P1", "Predicted_P2", "Predicted_P3", "Predicted_P4"]
)

    print(cm_df)

    # ==========================================
# HIGH-IMPACT INCIDENT EVALUATION
# P1 and P2 = High Impact
# P3 and P4 = Normal Impact
# ==========================================

    df["actual_high_impact"] = df["priority"].isin(["P1", "P2"])
    df["predicted_high_impact"] = df["baseline_priority"].isin(["P1", "P2"])

    high_impact_cm = confusion_matrix(
        df["actual_high_impact"],
        df["predicted_high_impact"],
        labels=[True, False]
)

    high_impact_cm_df = pd.DataFrame(
        high_impact_cm,
        index=["Actual_High_Impact", "Actual_Normal"],
        columns=["Predicted_High_Impact", "Predicted_Normal"]
)

    print("\n===== HIGH-IMPACT CONFUSION MATRIX =====\n")
    print(high_impact_cm_df)

    # False Positives:
    # Actual P3/P4 but predicted as P1/P2

    false_positives = df[
        (~df["actual_high_impact"])
        &
        (df["predicted_high_impact"])
]

# False Negatives:
# Actual P1/P2 but predicted as P3/P4

    false_negatives = df[
        (df["actual_high_impact"])
        &
        (~df["predicted_high_impact"])
]

    print("\n===== FALSE POSITIVES =====")
    print(f"Count: {len(false_positives)}")

    print(
    false_positives[
        [
            "ticket_id",
            "ticket_content",
            "affected_service",
            "user_group",
            "scope",
            "priority",
            "baseline_priority"
        ]
    ].head(10)
)

    print("\n===== FALSE NEGATIVES =====")
    print(f"Count: {len(false_negatives)}")

    print(
    false_negatives[
        [
            "ticket_id",
            "ticket_content",
            "affected_service",
            "user_group",
            "scope",
            "priority",
            "baseline_priority"
        ]
    ].head(10)
)

    print("\n===== BASELINE RESULTS =====\n")

    print(
        df[
            [
                "ticket_id",
                "ticket_content",
                "priority",
                "baseline_priority",
                "baseline_risk_score"
            ]
        ].head(10)
    )
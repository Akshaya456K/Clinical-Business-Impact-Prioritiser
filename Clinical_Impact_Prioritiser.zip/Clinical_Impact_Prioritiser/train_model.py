import pandas as pd
import joblib

from pathlib import Path

from sklearn.model_selection import train_test_split
from sklearn.compose import ColumnTransformer
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.preprocessing import OneHotEncoder
from sklearn.pipeline import Pipeline
from sklearn.linear_model import LogisticRegression
from sklearn.metrics import (
    accuracy_score,
    classification_report,
    confusion_matrix
)


# ==========================================
# 1. LOAD DATA
# ==========================================

BASE_DIR = Path(__file__).resolve().parent
DATA_PATH = BASE_DIR / "hospital_it_tickets.csv"

df = pd.read_csv(DATA_PATH)

print("Dataset loaded successfully.")
print("Dataset shape:", df.shape)


# ==========================================
# 2. SELECT FEATURES AND TARGET
# ==========================================

FEATURES = [
    "ticket_content",
    "affected_service",
    "user_group",
    "operating_schedule",
    "scope"
]

TARGET = "priority"

X = df[FEATURES]
y = df[TARGET]


# ==========================================
# 3. TRAIN / TEST SPLIT
# ==========================================

X_train, X_test, y_train, y_test = train_test_split(
    X,
    y,
    test_size=0.20,
    random_state=42,
    stratify=y
)

print("\nTraining samples:", X_train.shape[0])
print("Testing samples:", X_test.shape[0])


# ==========================================
# 4. PREPROCESSING
# ==========================================

preprocessor = ColumnTransformer(
    transformers=[
        (
            "text",
            TfidfVectorizer(
                lowercase=True,
                stop_words="english",
                ngram_range=(1, 2),
                min_df=1
            ),
            "ticket_content"
        ),
        (
            "categorical",
            OneHotEncoder(
                handle_unknown="ignore"
            ),
            [
                "affected_service",
                "user_group",
                "operating_schedule",
                "scope"
            ]
        )
    ]
)


# ==========================================
# 5. MACHINE LEARNING MODEL
# ==========================================

model = LogisticRegression(
    max_iter=2000,
    class_weight="balanced",
    random_state=42
)


# ==========================================
# 6. CREATE PIPELINE
# ==========================================

pipeline = Pipeline(
    steps=[
        ("preprocessor", preprocessor),
        ("model", model)
    ]
)


# ==========================================
# 7. TRAIN MODEL
# ==========================================

print("\nTraining machine learning model...")

pipeline.fit(X_train, y_train)

print("Training completed successfully.")


# ==========================================
# 8. MAKE PREDICTIONS
# ==========================================

y_pred = pipeline.predict(X_test)


# ==========================================
# 9. EVALUATE MODEL
# ==========================================

accuracy = accuracy_score(
    y_test,
    y_pred
)

print("\n===== ML MODEL EVALUATION =====")

print(f"\nAccuracy: {accuracy:.4f}")
print(f"Accuracy Percentage: {accuracy * 100:.2f}%")

print("\n===== CLASSIFICATION REPORT =====\n")

print(
    classification_report(
        y_test,
        y_pred,
        labels=["P1", "P2", "P3", "P4"],
        zero_division=0
    )
)
# ==========================================
# HIGH-IMPACT INCIDENT EVALUATION
# P1/P2 = High Impact
# P3/P4 = Normal Impact
# ==========================================

from sklearn.metrics import precision_score, recall_score, f1_score

actual_high_impact = y_test.isin(["P1", "P2"])
predicted_high_impact = pd.Series(y_pred).isin(["P1", "P2"])

high_precision = precision_score(
    actual_high_impact,
    predicted_high_impact,
    zero_division=0
)

high_recall = recall_score(
    actual_high_impact,
    predicted_high_impact,
    zero_division=0
)

high_f1 = f1_score(
    actual_high_impact,
    predicted_high_impact,
    zero_division=0
)

print("\n===== HIGH-IMPACT EVALUATION =====")

print(f"Precision: {high_precision:.4f}")
print(f"Recall: {high_recall:.4f}")
print(f"F1-score: {high_f1:.4f}")

# ==========================================
# 10. CONFUSION MATRIX
# ==========================================

cm = confusion_matrix(
    y_test,
    y_pred,
    labels=["P1", "P2", "P3", "P4"]
)

cm_df = pd.DataFrame(
    cm,
    index=[
        "Actual_P1",
        "Actual_P2",
        "Actual_P3",
        "Actual_P4"
    ],
    columns=[
        "Predicted_P1",
        "Predicted_P2",
        "Predicted_P3",
        "Predicted_P4"
    ]
)

print("\n===== CONFUSION MATRIX =====\n")

print(cm_df)

# ==========================================
# FEATURE ABLATION / SANITY CHECK
# ==========================================

print("\n===== FEATURE ABLATION EXPERIMENT =====")

# ------------------------------------------
# 1. TEXT-ONLY MODEL
# ------------------------------------------

text_only_pipeline = Pipeline(
    steps=[
        (
            "tfidf",
            TfidfVectorizer(
                lowercase=True,
                stop_words="english",
                ngram_range=(1, 2),
                min_df=1
            )
        ),
        (
            "model",
            LogisticRegression(
                max_iter=2000,
                class_weight="balanced",
                random_state=42
            )
        )
    ]
)

text_only_pipeline.fit(
    X_train["ticket_content"],
    y_train
)

text_only_pred = text_only_pipeline.predict(
    X_test["ticket_content"]
)

text_only_accuracy = accuracy_score(
    y_test,
    text_only_pred
)

print(
    f"\nText-only Accuracy: "
    f"{text_only_accuracy:.4f} "
    f"({text_only_accuracy * 100:.2f}%)"
)


# ------------------------------------------
# 2. STRUCTURED-ONLY MODEL
# ------------------------------------------

structured_features = [
    "affected_service",
    "user_group",
    "operating_schedule",
    "scope"
]

structured_pipeline = Pipeline(
    steps=[
        (
            "encoder",
            OneHotEncoder(
                handle_unknown="ignore"
            )
        ),
        (
            "model",
            LogisticRegression(
                max_iter=2000,
                class_weight="balanced",
                random_state=42
            )
        )
    ]
)

structured_pipeline.fit(
    X_train[structured_features],
    y_train
)

structured_pred = structured_pipeline.predict(
    X_test[structured_features]
)

structured_accuracy = accuracy_score(
    y_test,
    structured_pred
)

print(
    f"Structured-only Accuracy: "
    f"{structured_accuracy:.4f} "
    f"({structured_accuracy * 100:.2f}%)"
)


# ------------------------------------------
# 3. FULL MODEL COMPARISON
# ------------------------------------------

print("\n===== MODEL COMPARISON =====")

comparison = pd.DataFrame({
    "Model": [
        "Rule-Based Baseline",
        "Text-Only ML",
        "Structured-Only ML",
        "Full Hybrid Features ML"
    ],
    "Accuracy": [
        0.5925,
        text_only_accuracy,
        structured_accuracy,
        accuracy
    ]
})

comparison["Accuracy Percentage"] = (
    comparison["Accuracy"] * 100
).round(2)

print(comparison.to_string(index=False))
# ==========================================
# 11. SAVE MODEL
# ==========================================

MODEL_DIR = BASE_DIR / "models"
MODEL_DIR.mkdir(exist_ok=True)

MODEL_PATH = MODEL_DIR / "priority_model.joblib"

joblib.dump(
    pipeline,
    MODEL_PATH
)

print("\nModel saved successfully at:")
print(MODEL_PATH)
from predict import prioritise_ticket
from safety import validate_ticket, validate_and_decide


def process_ticket(ticket):
    """
    Complete end-to-end workflow.

    1. Validate ticket
    2. Run ML prioritisation
    3. Generate explanation
    4. Apply safety rules
    5. Return final decision
    """

    # -----------------------------------------
    # STEP 1: VALIDATE INPUT FIRST
    # -----------------------------------------

    validation_errors = validate_ticket(ticket)

    if validation_errors:

        return {
            "status": "FALLBACK",
            "predicted_priority": None,
            "confidence": None,
            "action": "HUMAN_REVIEW",
            "reason": "Ticket is incomplete or invalid.",
            "errors": validation_errors,
            "evidence": []
        }

    # -----------------------------------------
    # STEP 2: ML PREDICTION
    # -----------------------------------------

    try:

        prediction_result = prioritise_ticket(ticket)

    except Exception as e:

        return {
            "status": "MODEL_FAILURE",
            "predicted_priority": None,
            "confidence": None,
            "action": "HUMAN_REVIEW",
            "reason": (
                "ML prediction failed. "
                "Fallback workflow activated."
            ),
            "errors": [str(e)],
            "evidence": []
        }

    # -----------------------------------------
    # STEP 3: SAFETY DECISION
    # -----------------------------------------

    safety_result = validate_and_decide(
        ticket,
        prediction_result
    )

    # -----------------------------------------
    # STEP 4: COMBINE RESULTS
    # -----------------------------------------

    return {
        "status": "SUCCESS",
        "predicted_priority":
            prediction_result["predicted_priority"],

        "confidence":
            prediction_result["confidence"],

        "probabilities":
            prediction_result["probabilities"],

        "action":
            safety_result["action"],

        "reason":
            safety_result["reason"],

        "errors":
            safety_result["errors"],

        "evidence":
            prediction_result["evidence"]
    }


# ==========================================
# TEST THE COMPLETE WORKFLOW
# ==========================================

if __name__ == "__main__":

    # ------------------------------------------
    # TEST 1: HIGH-IMPACT INCIDENT
    # ------------------------------------------

    ticket_1 = {
        "ticket_content": (
            "EHR system completely unavailable. "
            "ICU clinicians cannot access patient records. "
            "Multiple users are affected."
        ),
        "affected_service": "EHR",
        "user_group": "ICU Clinicians",
        "operating_schedule": "24/7",
        "scope": "Hospital-wide"
    }

    # ------------------------------------------
    # TEST 2: NORMAL TICKET
    # ------------------------------------------

    ticket_2 = {
        "ticket_content": (
            "One staff member is having a minor "
            "issue accessing the staff portal."
        ),
        "affected_service": "Staff Portal",
        "user_group": "Administrative Staff",
        "operating_schedule": "Business Hours",
        "scope": "Single User"
    }

    # ------------------------------------------
    # TEST 3: INCOMPLETE TICKET
    # ------------------------------------------

    ticket_3 = {
        "ticket_content": "Critical system problem",
        "affected_service": "EHR"
    }

    tickets = [
        ("TEST 1: HIGH IMPACT", ticket_1),
        ("TEST 2: NORMAL", ticket_2),
        ("TEST 3: INCOMPLETE", ticket_3)
    ]

    for test_name, ticket in tickets:

        print("\n")
        print("=" * 60)
        print(test_name)
        print("=" * 60)

        result = process_ticket(ticket)

        print("\nStatus:", result["status"])
        print("Predicted Priority:", result["predicted_priority"])
        print("Confidence:", result["confidence"])
        print("Action:", result["action"])
        print("Reason:", result["reason"])

        if result["errors"]:
            print("\nErrors:")

            for error in result["errors"]:
                print("-", error)

        if result["evidence"]:
            print("\nEvidence:")

            for item in result["evidence"]:
                print("-", item)
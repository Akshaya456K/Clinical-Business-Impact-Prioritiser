import pandas as pd
import joblib
import time

from pathlib import Path

from sklearn.model_selection import train_test_split
from sklearn.metrics import (
    accuracy_score,
    precision_score,
    recall_score,
    f1_score,
    confusion_matrix
)


# ==========================================
# CONFIGURATION
# ==========================================

BASE_DIR = Path(__file__).resolve().parent

DATA_PATH = BASE_DIR / "hospital_it_tickets.csv"

MODEL_PATH = (
    BASE_DIR
    / "models"
    / "priority_model.joblib"
)

TARGET_TIME_SECONDS = 1.0


# ==========================================
# LOAD DATA AND MODEL
# ==========================================

df = pd.read_csv(DATA_PATH)

model = joblib.load(MODEL_PATH)

print("Dataset and trained model loaded successfully.")


# ==========================================
# FEATURES
# ==========================================

FEATURES = [
    "ticket_content",
    "affected_service",
    "user_group",
    "operating_schedule",
    "scope"
]

TARGET = "priority"

X = df[FEATURES]
y = df[TARGET]


# ==========================================
# RECREATE SAME TEST SPLIT
# ==========================================

_, X_test, _, y_test = train_test_split(
    X,
    y,
    test_size=0.20,
    random_state=42,
    stratify=y
)


# ==========================================
# MEASURE PREDICTION TIME
# ==========================================

start_time = time.perf_counter()

y_pred = model.predict(X_test)

end_time = time.perf_counter()

total_prediction_time = (
    end_time - start_time
)

average_prediction_time = (
    total_prediction_time / len(X_test)
)


# ==========================================
# OVERALL ACCURACY
# ==========================================

accuracy = accuracy_score(
    y_test,
    y_pred
)


# ==========================================
# HIGH-IMPACT EVALUATION
# P1/P2 = HIGH IMPACT
# ==========================================

actual_high_impact = y_test.isin(
    ["P1", "P2"]
)

predicted_high_impact = pd.Series(
    y_pred,
    index=y_test.index
).isin(
    ["P1", "P2"]
)

high_impact_precision = precision_score(
    actual_high_impact,
    predicted_high_impact,
    zero_division=0
)

high_impact_recall = recall_score(
    actual_high_impact,
    predicted_high_impact,
    zero_division=0
)

high_impact_f1 = f1_score(
    actual_high_impact,
    predicted_high_impact,
    zero_division=0
)


# ==========================================
# HIGH-IMPACT CONFUSION MATRIX
# ==========================================

high_cm = confusion_matrix(
    actual_high_impact,
    predicted_high_impact
)

tn, fp, fn, tp = high_cm.ravel()


# ==========================================
# TARGET TIME RESULTS
# ==========================================

within_target = (
    average_prediction_time
    <= TARGET_TIME_SECONDS
)


# ==========================================
# PRINT RESULTS
# ==========================================

print("\n" + "=" * 60)
print("FINAL SYSTEM EVALUATION")
print("=" * 60)

print("\n===== BASELINE VS ML =====")

print("Baseline Accuracy: 59.25%")

print(
    f"ML Accuracy: "
    f"{accuracy * 100:.2f}%"
)

print(
    f"Improvement: "
    f"{(accuracy - 0.5925) * 100:.2f} percentage points"
)


print("\n===== HIGH-IMPACT INCIDENT EVALUATION =====")

print(
    f"Precision: "
    f"{high_impact_precision * 100:.2f}%"
)

print(
    f"Recall: "
    f"{high_impact_recall * 100:.2f}%"
)

print(
    f"F1 Score: "
    f"{high_impact_f1 * 100:.2f}%"
)


print("\n===== HIGH-IMPACT ERROR ANALYSIS =====")

print(
    f"True Positives: {tp}"
)

print(
    f"False Positives: {fp}"
)

print(
    f"False Negatives: {fn}"
)

print(
    f"True Negatives: {tn}"
)


print("\n===== TARGET TIME EVALUATION =====")

print(
    f"Target Time Per Ticket: "
    f"{TARGET_TIME_SECONDS * 1000:.2f} ms"
)

print(
    f"Total Time for {len(X_test)} Tickets: "
    f"{total_prediction_time * 1000:.2f} ms"
)

print(
    f"Average Time Per Ticket: "
    f"{average_prediction_time * 1000:.4f} ms"
)

print(
    "Target Achieved:",
    "YES" if within_target else "NO"
)


# ==========================================
# CREATE RESULTS DATAFRAME
# ==========================================

results_df = X_test.copy()

results_df["actual_priority"] = y_test

results_df["predicted_priority"] = y_pred

results_df["actual_high_impact"] = actual_high_impact

results_df["predicted_high_impact"] = (
    predicted_high_impact
)


# ==========================================
# SAVE RESULTS
# ==========================================

REPORT_DIR = BASE_DIR / "reports"

REPORT_DIR.mkdir(
    exist_ok=True
)

RESULT_PATH = (
    REPORT_DIR
    / "evaluation_results.csv"
)

results_df.to_csv(
    RESULT_PATH,
    index=False
)

print(
    "\nDetailed evaluation results saved to:"
)

print(RESULT_PATH)
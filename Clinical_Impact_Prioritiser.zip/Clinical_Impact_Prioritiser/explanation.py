import re


# High-risk keywords that can be used as evidence
CRITICAL_KEYWORDS = [
    "system unavailable",
    "completely unavailable",
    "outage",
    "down",
    "critical failure",
    "cannot access",
    "unable to access",
    "not working"
]

HIGH_IMPACT_KEYWORDS = [
    "multiple users",
    "several users",
    "all users",
    "emergency",
    "urgent",
    "timing out",
    "severely degraded",
    "unable to"
]


# Critical clinical services
CRITICAL_SERVICES = [
    "EHR",
    "Medication Management",
    "Nurse Call System"
]


# High-impact user groups
HIGH_IMPACT_USERS = [
    "ICU Clinicians",
    "Emergency Department Clinicians",
    "Doctors",
    "Nurses"
]


def find_matching_keywords(ticket_content):
    """
    Find important keywords or phrases present
    in the ticket content.
    """

    text = str(ticket_content).lower()

    matches = []

    all_keywords = (
        CRITICAL_KEYWORDS +
        HIGH_IMPACT_KEYWORDS
    )

    for keyword in all_keywords:

        if keyword in text:
            matches.append(keyword)

    return list(set(matches))


def generate_explanation(
    ticket,
    predicted_priority,
    confidence
):
    """
    Generate human-readable evidence explaining
    why the ticket received its predicted priority.
    """

    evidence = []

    # ----------------------------------------
    # 1. AFFECTED SERVICE
    # ----------------------------------------

    service = ticket.get(
        "affected_service",
        "Unknown"
    )

    if service in CRITICAL_SERVICES:
        evidence.append(
            f"Critical clinical service affected: {service}"
        )

    else:
        evidence.append(
            f"Affected service: {service}"
        )

    # ----------------------------------------
    # 2. USER GROUP
    # ----------------------------------------

    user_group = ticket.get(
        "user_group",
        "Unknown"
    )

    if user_group in HIGH_IMPACT_USERS:
        evidence.append(
            f"High-impact clinical users affected: {user_group}"
        )

    else:
        evidence.append(
            f"User group affected: {user_group}"
        )

    # ----------------------------------------
    # 3. SCOPE
    # ----------------------------------------

    scope = ticket.get(
        "scope",
        "Unknown"
    )

    evidence.append(
        f"Impact scope: {scope}"
    )

    # ----------------------------------------
    # 4. OPERATING SCHEDULE
    # ----------------------------------------

    schedule = ticket.get(
        "operating_schedule",
        "Unknown"
    )

    evidence.append(
        f"Operating schedule: {schedule}"
    )

    # ----------------------------------------
    # 5. TICKET TEXT EVIDENCE
    # ----------------------------------------

    ticket_content = ticket.get(
        "ticket_content",
        ""
    )

    matched_keywords = find_matching_keywords(
        ticket_content
    )

    if matched_keywords:

        evidence.append(
            "Ticket evidence: " +
            ", ".join(matched_keywords)
        )

    else:

        evidence.append(
            "No predefined critical keyword matched; "
            "prediction was based on the learned ticket "
            "and structured feature pattern."
        )

    # ----------------------------------------
    # 6. FINAL DECISION
    # ----------------------------------------

    explanation = {
        "predicted_priority": predicted_priority,
        "confidence": round(
            float(confidence) * 100,
            2
        ),
        "evidence": evidence
    }

    return explanation

if __name__ == "__main__":

    sample_ticket = {
        "ticket_content": (
            "EHR system completely unavailable. "
            "ICU clinicians cannot access patient records. "
            "Multiple users affected."
        ),
        "affected_service": "EHR",
        "user_group": "ICU Clinicians",
        "operating_schedule": "24/7",
        "scope": "Hospital-wide"
    }

    explanation = generate_explanation(
        ticket=sample_ticket,
        predicted_priority="P1",
        confidence=0.98
    )

    print("\n===== EXPLANATION =====\n")

    print(
        "Predicted Priority:",
        explanation["predicted_priority"]
    )

    print(
        "Confidence:",
        explanation["confidence"],
        "%"
    )

    print("\nEvidence:")

    for item in explanation["evidence"]:
        print("-", item)
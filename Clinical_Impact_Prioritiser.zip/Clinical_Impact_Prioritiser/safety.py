# ==========================================
# RESPONSIBLE AI SAFETY AND FALLBACK LAYER
# ==========================================

REQUIRED_FIELDS = [
    "ticket_content",
    "affected_service",
    "user_group",
    "operating_schedule",
    "scope"
]

VALID_PRIORITIES = ["P1", "P2", "P3", "P4"]

# Confidence thresholds
HIGH_CONFIDENCE_THRESHOLD = 0.80
LOW_CONFIDENCE_THRESHOLD = 0.60


def validate_ticket(ticket):
    """
    Check whether all required fields are present
    and contain meaningful values.
    """

    errors = []

    for field in REQUIRED_FIELDS:

        if field not in ticket:
            errors.append(
                f"Missing required field: {field}"
            )

        elif ticket[field] is None:

            errors.append(
                f"Empty required field: {field}"
            )

        elif isinstance(ticket[field], str) and not ticket[field].strip():

            errors.append(
                f"Empty required field: {field}"
            )

    return errors


def evaluate_prediction(
    predicted_priority,
    confidence,
    evidence
):
    """
    Decide whether the prediction can be accepted,
    escalated, or requires human review.
    """

    confidence = float(confidence)

    # ------------------------------------------
    # LOW CONFIDENCE
    # ------------------------------------------

    if confidence < LOW_CONFIDENCE_THRESHOLD:

        return {
            "action": "HUMAN_REVIEW",
            "reason": (
                "Prediction confidence is below "
                f"{LOW_CONFIDENCE_THRESHOLD * 100:.0f}%."
            )
        }

    # ------------------------------------------
    # HIGH-IMPACT WITH INSUFFICIENT EVIDENCE
    # ------------------------------------------

    if predicted_priority in ["P1", "P2"]:

        if not evidence or len(evidence) < 3:

            return {
                "action": "HUMAN_REVIEW",
                "reason": (
                    "High-impact prediction does not "
                    "contain sufficient supporting evidence."
                )
            }

        # P1 always gets urgent escalation
        if predicted_priority == "P1":

            return {
                "action": "URGENT_ESCALATION",
                "reason": (
                    "High-impact P1 incident with "
                    "sufficient evidence."
                )
            }

        # P2
        if confidence < HIGH_CONFIDENCE_THRESHOLD:

            return {
                "action": "HUMAN_REVIEW",
                "reason": (
                    "P2 incident requires review because "
                    "confidence is below "
                    f"{HIGH_CONFIDENCE_THRESHOLD * 100:.0f}%."
                )
            }

        return {
            "action": "PRIORITY_ESCALATION",
            "reason": (
                "P2 incident with high confidence "
                "and sufficient evidence."
            )
        }

    # ------------------------------------------
    # NORMAL PRIORITY
    # ------------------------------------------

    return {
        "action": "ACCEPT",
        "reason": (
            "Prediction passed confidence and "
            "evidence checks."
        )
    }


def validate_and_decide(
    ticket,
    prediction_result
):
    """
    Validate ticket input and decide what action
    should be taken.
    """

    validation_errors = validate_ticket(ticket)

    if validation_errors:

        return {
            "safe": False,
            "action": "HUMAN_REVIEW",
            "reason": "Invalid or incomplete ticket input.",
            "errors": validation_errors
        }

    decision = evaluate_prediction(
        predicted_priority=
        prediction_result["predicted_priority"],

        confidence=
        prediction_result["confidence"] / 100,

        evidence=
        prediction_result["evidence"]
    )

    return {
        "safe": decision["action"] == "ACCEPT",
        "action": decision["action"],
        "reason": decision["reason"],
        "errors": []
    }


# ==========================================
# TEST SAFETY LOGIC
# ==========================================

if __name__ == "__main__":

    # Test 1: Valid P1
    valid_ticket = {
        "ticket_content": "EHR system is down.",
        "affected_service": "EHR",
        "user_group": "ICU Clinicians",
        "operating_schedule": "24/7",
        "scope": "Hospital-wide"
    }

    valid_prediction = {
        "predicted_priority": "P1",
        "confidence": 98.0,
        "evidence": [
            "Critical clinical service affected: EHR",
            "High-impact clinical users affected: ICU Clinicians",
            "Impact scope: Hospital-wide"
        ]
    }

    result = validate_and_decide(
        valid_ticket,
        valid_prediction
    )

    print("\n===== TEST 1: VALID P1 =====")
    print(result)


    # Test 2: Missing field
    incomplete_ticket = {
        "ticket_content": "System is down",
        "affected_service": "EHR"
    }

    result = validate_and_decide(
        incomplete_ticket,
        valid_prediction
    )

    print("\n===== TEST 2: MISSING FIELDS =====")
    print(result)


    # Test 3: Low confidence
    low_confidence_prediction = {
        "predicted_priority": "P2",
        "confidence": 45.0,
        "evidence": [
            "Affected service: EHR",
            "User group: Doctors",
            "Impact scope: Department"
        ]
    }

    result = validate_and_decide(
        valid_ticket,
        low_confidence_prediction
    )

    print("\n===== TEST 3: LOW CONFIDENCE =====")
    print(result)
import pandas as pd
import joblib

from pathlib import Path
from explanation import generate_explanation


# ==========================================
# LOAD TRAINED MODEL
# ==========================================

BASE_DIR = Path(__file__).resolve().parent

MODEL_PATH = (
    BASE_DIR
    / "models"
    / "priority_model.joblib"
)

model = joblib.load(MODEL_PATH)

print("ML model loaded successfully.")


# ==========================================
# PREDICTION FUNCTION
# ==========================================

def prioritise_ticket(ticket):
    """
    Predict priority, confidence, probabilities
    and generate supporting evidence.
    """

    # Convert ticket dictionary to DataFrame
    ticket_df = pd.DataFrame([ticket])

    # Predict priority
    predicted_priority = model.predict(ticket_df)[0]

    # Get probability for each class
    probabilities = model.predict_proba(ticket_df)[0]

    # Get class names
    classes = model.classes_

    # Create probability dictionary
    probability_dict = {
        priority: round(
            float(probability) * 100,
            2
        )
        for priority, probability
        in zip(classes, probabilities)
    }

    # Confidence = probability of predicted class
    predicted_index = list(classes).index(
        predicted_priority
    )

    confidence = probabilities[predicted_index]

    # Generate explanation
    explanation = generate_explanation(
        ticket=ticket,
        predicted_priority=predicted_priority,
        confidence=confidence
    )

    # Return complete result
    return {
        "predicted_priority": predicted_priority,
        "confidence": round(
            float(confidence) * 100,
            2
        ),
        "probabilities": probability_dict,
        "evidence": explanation["evidence"]
    }


# ==========================================
# TEST WITH SAMPLE TICKET
# ==========================================

if __name__ == "__main__":

    sample_ticket = {
        "ticket_content": (
            "EHR system completely unavailable. "
            "ICU clinicians cannot access patient records. "
            "Multiple users affected."
        ),
        "affected_service": "EHR",
        "user_group": "ICU Clinicians",
        "operating_schedule": "24/7",
        "scope": "Hospital-wide"
    }

    result = prioritise_ticket(sample_ticket)

    print("\n===== CLINICAL IMPACT PRIORITISER =====\n")

    print(
        "Predicted Priority:",
        result["predicted_priority"]
    )

    print(
        "Confidence:",
        result["confidence"],
        "%"
    )

    print("\nPriority Probabilities:")

    for priority, probability in (
        result["probabilities"].items()
    ):
        print(
            f"{priority}: {probability}%"
        )

    print("\nEvidence:")

    for evidence in result["evidence"]:
        print("-", evidence)
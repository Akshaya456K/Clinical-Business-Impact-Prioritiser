from event_processor import TicketEventProcessor


def run_test(test_name, condition):
    if condition:
        print(f"PASS - {test_name}")
        return True
    else:
        print(f"FAIL - {test_name}")
        return False


def test_duplicate_event():
    processor = TicketEventProcessor()

    event = {
        "event_id": "E001",
        "ticket_id": "T1001",
        "event_type": "TICKET_CREATED",
        "event_timestamp": "2026-08-27T09:00:00",
        "event_version": 1,
        "data": {
            "priority": "P2"
        }
    }

    first_result = processor.process_event(event)
    duplicate_result = processor.process_event(event)

    final_state = processor.get_ticket_state("T1001")

    return (
        first_result["status"] == "APPLIED"
        and duplicate_result["status"] == "DUPLICATE_IGNORED"
        and final_state["latest_version"] == 1
        and final_state["data"]["priority"] == "P2"
    )


def test_out_of_order_event():
    processor = TicketEventProcessor()

    newer_event = {
        "event_id": "E002",
        "ticket_id": "T1002",
        "event_type": "PRIORITY_UPDATED",
        "event_timestamp": "2026-08-27T10:05:00",
        "event_version": 2,
        "data": {
            "priority": "P1"
        }
    }

    older_event = {
        "event_id": "E003",
        "ticket_id": "T1002",
        "event_type": "PRIORITY_UPDATED",
        "event_timestamp": "2026-08-27T10:00:00",
        "event_version": 1,
        "data": {
            "priority": "P3"
        }
    }

    processor.process_event(newer_event)
    old_result = processor.process_event(older_event)

    final_state = processor.get_ticket_state("T1002")

    return (
        old_result["status"] == "OUT_OF_ORDER_IGNORED"
        and final_state["latest_version"] == 2
        and final_state["data"]["priority"] == "P1"
    )


def test_delayed_event_recovery():
    processor = TicketEventProcessor()

    event_v1 = {
        "event_id": "E004",
        "ticket_id": "T1003",
        "event_type": "TICKET_CREATED",
        "event_timestamp": "2026-08-27T11:00:00",
        "event_version": 1,
        "data": {
            "priority": "P3"
        }
    }

    event_v3 = {
        "event_id": "E005",
        "ticket_id": "T1003",
        "event_type": "PRIORITY_UPDATED",
        "event_timestamp": "2026-08-27T11:10:00",
        "event_version": 3,
        "data": {
            "priority": "P1"
        }
    }

    delayed_v2 = {
        "event_id": "E006",
        "ticket_id": "T1003",
        "event_type": "PRIORITY_UPDATED",
        "event_timestamp": "2026-08-27T11:05:00",
        "event_version": 2,
        "data": {
            "priority": "P2"
        }
    }

    processor.process_event(event_v1)
    processor.process_event(event_v3)

    delayed_result = processor.process_event(delayed_v2)

    final_state = processor.get_ticket_state("T1003")

    return (
        delayed_result["status"] == "OUT_OF_ORDER_IGNORED"
        and final_state["latest_version"] == 3
        and final_state["data"]["priority"] == "P1"
    )


def test_newer_event_updates_state():
    processor = TicketEventProcessor()

    event_v1 = {
        "event_id": "E007",
        "ticket_id": "T1004",
        "event_type": "TICKET_CREATED",
        "event_timestamp": "2026-08-27T12:00:00",
        "event_version": 1,
        "data": {
            "priority": "P3"
        }
    }

    event_v2 = {
        "event_id": "E008",
        "ticket_id": "T1004",
        "event_type": "PRIORITY_UPDATED",
        "event_timestamp": "2026-08-27T12:05:00",
        "event_version": 2,
        "data": {
            "priority": "P2"
        }
    }

    processor.process_event(event_v1)
    result = processor.process_event(event_v2)

    final_state = processor.get_ticket_state("T1004")

    return (
        result["status"] == "APPLIED"
        and final_state["latest_version"] == 2
        and final_state["data"]["priority"] == "P2"
    )


if __name__ == "__main__":

    print("\n===== EVENT PROCESSOR EDGE-CASE TESTS =====\n")

    results = []

    results.append(
        run_test(
            "Duplicate event does not corrupt state",
            test_duplicate_event()
        )
    )

    results.append(
        run_test(
            "Out-of-order event does not overwrite newer state",
            test_out_of_order_event()
        )
    )

    results.append(
        run_test(
            "Delayed event recovery preserves latest state",
            test_delayed_event_recovery()
        )
    )

    results.append(
        run_test(
            "Newer event correctly updates state",
            test_newer_event_updates_state()
        )
    )

    passed = sum(results)
    total = len(results)

    print("\n===== TEST SUMMARY =====")

    print(f"Passed: {passed}/{total}")

    print(
        f"Success Rate: {(passed / total) * 100:.2f}%"
    )
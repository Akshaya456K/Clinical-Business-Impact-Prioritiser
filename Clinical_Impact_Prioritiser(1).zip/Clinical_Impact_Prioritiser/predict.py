import pandas as pd
import joblib

from env_check import check_sklearn_version

from pathlib import Path
from explanation import generate_explanation


# ==========================================
# LOAD TRAINED MODEL
# ==========================================

BASE_DIR = Path(__file__).resolve().parent

MODEL_PATH = (
    BASE_DIR
    / "models"
    / "priority_model.joblib"
)

# Optional calibrated model (created by calibrate_model.py --adopt).
# If it is missing or fails to load, the original model is used.
CALIBRATED_MODEL_PATH = (
    BASE_DIR
    / "models"
    / "priority_model_calibrated.joblib"
)


def _load_model():
    """
    Load the calibrated model when available, otherwise the original.
    Returns (model, source) where source is "calibrated" or "original".
    """

    if CALIBRATED_MODEL_PATH.exists():
        try:
            return joblib.load(CALIBRATED_MODEL_PATH), "calibrated"
        except Exception as error:
            print(
                "Calibrated model could not be loaded "
                f"({error}). Falling back to the original model."
            )

    return joblib.load(MODEL_PATH), "original"


# Verify the declared scikit-learn version BEFORE any model is loaded.
check_sklearn_version()

model, MODEL_SOURCE = _load_model()

print(f"ML model loaded successfully ({MODEL_SOURCE}).")


# ==========================================
# PREDICTION FUNCTION
# ==========================================

def prioritise_ticket(ticket):
    """
    Predict priority, confidence, probabilities
    and generate supporting evidence.
    """

    # Convert ticket dictionary to DataFrame
    ticket_df = pd.DataFrame([ticket])

    # Get probability for each class
    # (calibrated if a calibrated model is loaded, otherwise raw)
    probabilities = model.predict_proba(ticket_df)[0]

    # Get class names
    classes = model.classes_

    # Predict priority from the SAME probabilities that are reported as
    # confidence, so predicted class and confidence can never disagree.
    # For the original Logistic Regression pipeline this equals
    # model.predict().
    predicted_priority = classes[probabilities.argmax()]

    # Create probability dictionary
    probability_dict = {
        priority: round(
            float(probability) * 100,
            2
        )
        for priority, probability
        in zip(classes, probabilities)
    }

    # Confidence = probability of predicted class
    predicted_index = list(classes).index(
        predicted_priority
    )

    confidence = probabilities[predicted_index]

    # Generate explanation
    explanation = generate_explanation(
        ticket=ticket,
        predicted_priority=predicted_priority,
        confidence=confidence
    )

    # Return complete result
    # confidence_type states what the confidence/probabilities are:
    # "calibrated" (calibrated model loaded) or "raw" (original Logistic
    # Regression probabilities).
    return {
        "predicted_priority": predicted_priority,
        "confidence": round(
            float(confidence) * 100,
            2
        ),
        "probabilities": probability_dict,
        "evidence": explanation["evidence"],
        "confidence_type": (
            "calibrated" if MODEL_SOURCE == "calibrated" else "raw"
        )
    }


# ==========================================
# TEST WITH SAMPLE TICKET
# ==========================================

if __name__ == "__main__":

    sample_ticket = {
        "ticket_content": (
            "EHR system completely unavailable. "
            "ICU clinicians cannot access patient records. "
            "Multiple users affected."
        ),
        "affected_service": "EHR",
        "user_group": "ICU Clinicians",
        "operating_schedule": "24/7",
        "scope": "Hospital-wide"
    }

    result = prioritise_ticket(sample_ticket)

    print("\n===== CLINICAL IMPACT PRIORITISER =====\n")

    print(
        "Predicted Priority:",
        result["predicted_priority"]
    )

    print(
        "Confidence:",
        result["confidence"],
        "%"
    )

    print("\nPriority Probabilities:")

    for priority, probability in (
        result["probabilities"].items()
    ):
        print(
            f"{priority}: {probability}%"
        )

    print("\nEvidence:")

    for evidence in result["evidence"]:
        print("-", evidence)
"""
Round 4: generalised safety behaviour (text evidence / fields / model).

These tests use wordings that do NOT appear in the robustness CSVs or the
training data, so they check the principle, not the three known examples.
Run:  python -m pytest test_generalised_safety.py -v
"""
import contextlib
import io
import unittest

with contextlib.redirect_stdout(io.StringIO()):
    from decision_engine import process_ticket

from safety import (FLAG_INSUFFICIENT_INFO, FLAG_OPERATIONAL_IMPACT,
                    find_insufficient_information_risk,
                    find_operational_impact_conflict, validate_and_decide)
from text_evidence import extract_evidence

LOW_FIELDS = dict(affected_service="Email", user_group="Administrative Staff",
                  operating_schedule="Business Hours", scope="Single User")
CRIT_LOW_SCOPE = dict(affected_service="EHR", user_group="Administrative Staff",
                      operating_schedule="Business Hours", scope="Single User")
LOW_RISK_FIELDS = dict(affected_service="Printing", user_group="Administrative Staff",
                       operating_schedule="Business Hours", scope="Single User")
HIGH_FIELDS = dict(affected_service="EHR", user_group="ICU Clinicians",
                   operating_schedule="24/7", scope="Hospital-wide")


def run(text, **fields):
    return process_ticket(dict(ticket_content=text, **fields))


class TestA_HighTextLowFields(unittest.TestCase):
    """Operational impact in text + low-impact fields -> HUMAN_REVIEW."""

    TEXTS = [
        # indirect wording, no 'critical'/'outage'/'down'/'ICU'/'emergency'
        "Theatre teams are holding back the first cases because they can't view the results they require.",
        "Consultants have postponed ward rounds as nobody is able to open the patient information.",
        "Anaesthetists are waiting to start procedures since the scan history will not display for them.",
        "Clinics are being cancelled this morning, the doctors cannot get to the information they need.",
    ]

    def test_indirect_high_impact_not_accepted(self):
        for text in self.TEXTS:
            with self.subTest(text=text):
                r = run(text, **LOW_FIELDS)
                self.assertNotEqual(r["action"], "ACCEPT")
                self.assertEqual(r["action"], "HUMAN_REVIEW")

    def test_reason_and_flag_are_auditable(self):
        r = run(self.TEXTS[0], **LOW_FIELDS)
        self.assertIn(FLAG_OPERATIONAL_IMPACT, r["safety_flags"])
        self.assertIn("human review", r["reason"].lower())


class TestA_ExplicitLimitedImpactIsNotEscalated(unittest.TestCase):
    """
    Text that itself restricts impact to one person is not operational-impact
    evidence. Asserted on the new check directly: the pre-existing Round 3
    learned text-vs-fields rule is independent and may still route some of
    these wordings to review, which is acceptable (it only adds caution).
    """

    TEXTS = [
        "A pharmacist cannot open the dispensing screen on her own desktop, colleagues are fine.",
        "One nurse cannot view her rota page, the rest of the ward is unaffected.",
        "A locum doctor is locked out of his account after several failed sign-in attempts.",
    ]

    def test_limited_impact_is_not_operational_evidence(self):
        for text in self.TEXTS:
            with self.subTest(text=text):
                ticket = dict(ticket_content=text, **LOW_RISK_FIELDS)
                self.assertFalse(extract_evidence(text)["operational_impact_evidence"])
                self.assertIsNone(find_operational_impact_conflict(ticket))
                self.assertNotIn(FLAG_OPERATIONAL_IMPACT,
                                 run(text, **LOW_RISK_FIELDS)["safety_flags"])


class TestB_LowTextHighFields(unittest.TestCase):
    """Low-impact text + high-impact fields is never silently accepted."""

    def test_never_accepted(self):
        for text in ["Please update my display name.",
                     "Tiny typo on a settings page.",
                     "Question about renewing a licence."]:
            with self.subTest(text=text):
                self.assertNotEqual(run(text, **HIGH_FIELDS)["action"], "ACCEPT")

    def test_model_accepting_while_fields_model_clearly_high_goes_to_review(self):
        ticket = dict(ticket_content="Question about a menu item.", **HIGH_FIELDS)
        pred = {"predicted_priority": "P4", "confidence": 95.0,
                "evidence": ["x", "y", "z"]}
        r = validate_and_decide(ticket, pred)
        self.assertEqual(r["action"], "HUMAN_REVIEW")
        self.assertIn("FIELDS_HIGH_MODEL_LOW", r["flags"])


class TestC_AmbiguousAndLowConfidence(unittest.TestCase):

    def test_ambiguous_text_ambiguous_fields_low_confidence(self):
        ticket = dict(ticket_content="Not sure, something odd.",
                      affected_service="Staff Portal", user_group="Nurses",
                      operating_schedule="Clinical Hours", scope="Multiple Users")
        pred = {"predicted_priority": "P3", "confidence": 41.0,
                "evidence": ["a", "b", "c"]}
        self.assertEqual(validate_and_decide(ticket, pred)["action"], "HUMAN_REVIEW")


class TestB_InsufficientInformation(unittest.TestCase):

    VAGUE = [
        "Something seems off and users keep mentioning it.",
        "Could somebody take a look when possible?",
        "Reporting a problem, details to follow.",
        "People are unhappy with how things are running.",
    ]

    def test_vague_text_on_critical_service_is_reviewed(self):
        for text in self.VAGUE:
            with self.subTest(text=text):
                for svc in ("EHR", "Nurse Call System", "Medication Management"):
                    fields = dict(CRIT_LOW_SCOPE, affected_service=svc)
                    r = run(text, **fields)
                    self.assertEqual(r["action"], "HUMAN_REVIEW")

    def test_vague_text_on_low_risk_service_does_not_trigger_new_check(self):
        for text in self.VAGUE:
            with self.subTest(text=text):
                ticket = dict(ticket_content=text, **LOW_RISK_FIELDS)
                self.assertIsNone(find_insufficient_information_risk(ticket))
                self.assertNotIn(FLAG_INSUFFICIENT_INFO,
                                 run(text, **LOW_RISK_FIELDS)["safety_flags"])

    def test_vague_text_check_fires_on_potential_impact_fields(self):
        for text in self.VAGUE:
            with self.subTest(text=text):
                ticket = dict(ticket_content=text, **CRIT_LOW_SCOPE)
                self.assertIsNotNone(find_insufficient_information_risk(ticket))

    def test_specific_text_is_not_insufficient_information(self):
        ticket = dict(ticket_content="EHR login page returns an error for one user.",
                      **CRIT_LOW_SCOPE)
        self.assertIsNone(find_insufficient_information_risk(ticket))

    def test_check_only_applies_to_would_be_accept(self):
        # model already escalating -> new check must not alter it
        ticket = dict(ticket_content=self.VAGUE[0], **HIGH_FIELDS)
        pred = {"predicted_priority": "P1", "confidence": 97.0,
                "evidence": ["a", "b", "c"]}
        self.assertEqual(validate_and_decide(ticket, pred)["action"], "URGENT_ESCALATION")


class TestD_ClearLowImpact(unittest.TestCase):

    def test_clear_low_impact_unchanged(self):
        for text, fields in [
            ("One staff member needs a printer toner cartridge replaced.", LOW_RISK_FIELDS),
            ("Please install a PDF reader on a new administrative workstation.", LOW_RISK_FIELDS),
            ("The staff portal shows an outdated rota for one person.",
             dict(LOW_RISK_FIELDS, affected_service="Staff Portal")),
        ]:
            with self.subTest(text=text):
                r = run(text, **fields)
                self.assertEqual(r["action"], "ACCEPT")
                self.assertEqual(r["safety_flags"], [])


class TestE_ClearHighImpact(unittest.TestCase):

    def test_clear_high_impact_unchanged(self):
        r = run("EHR system completely unavailable. ICU clinicians cannot access "
                "patient records. Multiple users are affected.", **HIGH_FIELDS)
        self.assertEqual(r["predicted_priority"], "P1")
        self.assertEqual(r["action"], "URGENT_ESCALATION")


class TestEscalationsNeverDowngraded(unittest.TestCase):

    def test_new_checks_do_not_touch_escalations(self):
        ticket = dict(ticket_content="Something is not right.", **HIGH_FIELDS)
        for pri, conf, expect in [("P1", 98.0, "URGENT_ESCALATION"),
                                  ("P2", 90.0, "PRIORITY_ESCALATION")]:
            pred = {"predicted_priority": pri, "confidence": conf,
                    "evidence": ["a", "b", "c"]}
            self.assertEqual(validate_and_decide(ticket, pred)["action"], expect)


if __name__ == "__main__":
    unittest.main()

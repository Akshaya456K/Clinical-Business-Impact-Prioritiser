"""
Auxiliary safety-signal models (NOT the production classifier).

The production model (train_model.py) is unchanged. These two small models
exist only so the safety layer can detect a disagreement between what the
ticket TEXT says and what the STRUCTURED FIELDS say, without relying on a
hand-written keyword list:

    text model        TF-IDF only          -> P(high impact | text)
    structured model  one-hot fields only  -> P(high impact | fields)

where high impact = P1 + P2 probability.

They reuse the exact architectures of the text-only / structured-only
ablation models in train_model.py, are trained on the SAME 80% training split
(random_state=42), and never see the 20% test set, the robustness cases or the
calibration data.

Conflict rule used by safety.py (fixed before evaluation on the extended
robustness cases; not tuned afterwards):
    only for a decision that would otherwise be ACCEPT:
        P_text(high) >= 0.5  and  P_struct(high) < 0.5   -> HUMAN_REVIEW

This script also estimates how often that rule would fire on ordinary
synthetic tickets (false alarms) using 5-fold out-of-fold predictions over
the whole dataset, plus the held-out test split.

Outputs
-------
    models/signal_text_model.joblib
    models/signal_structured_model.joblib
    reports/signal_models_report.json

Usage:
    python train_signal_models.py
"""
import json
from pathlib import Path

import joblib
import numpy as np
import pandas as pd
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.linear_model import LogisticRegression
from sklearn.model_selection import StratifiedKFold, train_test_split
from sklearn.pipeline import Pipeline
from sklearn.preprocessing import OneHotEncoder

BASE_DIR = Path(__file__).resolve().parent
DATA_PATH = BASE_DIR / "hospital_it_tickets.csv"
MODEL_DIR = BASE_DIR / "models"
REPORT_DIR = BASE_DIR / "reports"
TEXT_MODEL_PATH = MODEL_DIR / "signal_text_model.joblib"
STRUCT_MODEL_PATH = MODEL_DIR / "signal_structured_model.joblib"

STRUCTURED = ["affected_service", "user_group", "operating_schedule", "scope"]
FEATURES = ["ticket_content"] + STRUCTURED
LABELS = ["P1", "P2", "P3", "P4"]
RANDOM_STATE = 42

# Fixed decision thresholds (see module docstring)
TEXT_HIGH_THRESHOLD = 0.5
STRUCT_LOW_THRESHOLD = 0.5


def build_text_model():
    return Pipeline([
        ("tfidf", TfidfVectorizer(lowercase=True, stop_words="english",
                                  ngram_range=(1, 2), min_df=1)),
        ("model", LogisticRegression(max_iter=2000, class_weight="balanced",
                                     random_state=RANDOM_STATE)),
    ])


def build_structured_model():
    return Pipeline([
        ("encoder", OneHotEncoder(handle_unknown="ignore")),
        ("model", LogisticRegression(max_iter=2000, class_weight="balanced",
                                     random_state=RANDOM_STATE)),
    ])


def p_high(model, X):
    proba = model.predict_proba(X)
    classes = list(model.classes_)
    return proba[:, classes.index("P1")] + proba[:, classes.index("P2")]


def conflict_mask(p_text_high, p_struct_high):
    return (p_text_high >= TEXT_HIGH_THRESHOLD) & (p_struct_high < STRUCT_LOW_THRESHOLD)


def main():
    df = pd.read_csv(DATA_PATH)
    X, y = df[FEATURES], df["priority"]
    X_train, X_test, y_train, y_test = train_test_split(
        X, y, test_size=0.20, random_state=RANDOM_STATE, stratify=y)

    text_model = build_text_model().fit(X_train["ticket_content"], y_train)
    struct_model = build_structured_model().fit(X_train[STRUCTURED], y_train)
    MODEL_DIR.mkdir(exist_ok=True)
    joblib.dump(text_model, TEXT_MODEL_PATH)
    joblib.dump(struct_model, STRUCT_MODEL_PATH)

    # ---- held-out test split (reporting only)
    pt = p_high(text_model, X_test["ticket_content"])
    ps = p_high(struct_model, X_test[STRUCTURED])
    test_high = y_test.isin(["P1", "P2"]).to_numpy()
    flagged = conflict_mask(pt, ps)
    report = {
        "split": "same 80/20 stratified split as train_model.py (random_state=42); models fitted on the 80% only",
        "rule": f"P_text(high) >= {TEXT_HIGH_THRESHOLD} and P_struct(high) < {STRUCT_LOW_THRESHOLD}",
        "heldout_test": {
            "n": int(len(y_test)),
            "text_model_accuracy": round(float((text_model.predict(X_test['ticket_content']) == y_test).mean()), 4),
            "structured_model_accuracy": round(float((struct_model.predict(X_test[STRUCTURED]) == y_test).mean()), 4),
            "conflict_flagged": int(flagged.sum()),
            "conflict_flagged_among_low_impact": int((flagged & ~test_high).sum()),
            "n_low_impact": int((~test_high).sum()),
        },
    }

    # ---- out-of-fold over all 2000 tickets (false-alarm estimate, leak-free)
    oof_t = np.zeros(len(df))
    oof_s = np.zeros(len(df))
    skf = StratifiedKFold(n_splits=5, shuffle=True, random_state=RANDOM_STATE)
    for tr, va in skf.split(X, y):
        t = build_text_model().fit(X.iloc[tr]["ticket_content"], y.iloc[tr])
        s = build_structured_model().fit(X.iloc[tr][STRUCTURED], y.iloc[tr])
        oof_t[va] = p_high(t, X.iloc[va]["ticket_content"])
        oof_s[va] = p_high(s, X.iloc[va][STRUCTURED])
    all_high = y.isin(["P1", "P2"]).to_numpy()
    fl = conflict_mask(oof_t, oof_s)
    report["out_of_fold_all_tickets"] = {
        "n": int(len(df)),
        "n_low_impact": int((~all_high).sum()),
        "false_alarms_on_low_impact": int((fl & ~all_high).sum()),
        "false_alarm_rate_on_low_impact": round(float((fl & ~all_high).sum() / (~all_high).sum()), 4),
        "flagged_on_high_impact": int((fl & all_high).sum()),
        "text_high_struct_low_total": int(fl.sum()),
    }
    # reverse direction (informational flag only)
    rev = (oof_t < TEXT_HIGH_THRESHOLD) & (oof_s >= STRUCT_LOW_THRESHOLD)
    report["out_of_fold_all_tickets"]["reverse_mismatch_on_high_impact"] = int((rev & all_high).sum())
    report["out_of_fold_all_tickets"]["reverse_mismatch_rate_on_high_impact"] = round(
        float((rev & all_high).sum() / all_high.sum()), 4)

    REPORT_DIR.mkdir(exist_ok=True)
    (REPORT_DIR / "signal_models_report.json").write_text(json.dumps(report, indent=2))
    print(json.dumps(report, indent=2))
    print("\nSaved models/signal_text_model.joblib, models/signal_structured_model.joblib, "
          "reports/signal_models_report.json")


if __name__ == "__main__":
    main()

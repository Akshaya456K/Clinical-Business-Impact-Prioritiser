import copy
from datetime import datetime


# ==========================================
# EVENT SCHEMA CONTRACT
# ==========================================
#
# Every incoming event must be a mapping with these fields.
#
#   event_id         str (non-blank) or int   unique id, used for de-duplication
#   ticket_id        str (non-blank) or int   ticket the event belongs to
#   event_type       str (non-blank)          e.g. TICKET_CREATED, PRIORITY_UPDATED
#   event_timestamp  ISO-8601 str or datetime e.g. "2026-08-27T09:00:00"
#   event_version    int >= 0 (not bool)      per-ticket ordering number
#
# Optional:
#   data             dict (None is treated as {})
#
# Extra, unknown fields are tolerated and ignored (forward compatible).

REQUIRED_EVENT_FIELDS = (
    "event_id",
    "ticket_id",
    "event_type",
    "event_timestamp",
    "event_version"
)

OPTIONAL_EVENT_FIELDS = ("data",)

# Status returned for events that fail the schema contract.
INVALID_EVENT_STATUS = "INVALID_EVENT_REJECTED"


def _is_valid_identifier(value):
    """str (non-blank) or int (not bool). Always hashable."""

    if isinstance(value, bool):
        return False

    if isinstance(value, int):
        return True

    return isinstance(value, str) and bool(value.strip())


def _is_valid_timestamp(value):
    """ISO-8601 string or datetime object."""

    if isinstance(value, datetime):
        return True

    if not isinstance(value, str) or not value.strip():
        return False

    text = value.strip()

    # Normalise a trailing "Z" (UTC) for older Python versions.
    if text.endswith("Z"):
        text = text[:-1] + "+00:00"

    try:
        datetime.fromisoformat(text)
    except ValueError:
        return False

    return True


def validate_event(event, allowed_event_types=None):
    """
    Check one event against the schema contract.

    Returns a list of human-readable error strings.
    An empty list means the event is valid.
    This function never raises and never modifies the event.
    """

    if not isinstance(event, dict):
        return [
            "Event must be a dict, got "
            f"{type(event).__name__}."
        ]

    errors = []

    for field in REQUIRED_EVENT_FIELDS:
        if field not in event:
            errors.append(f"Missing required field: {field}")

    # --- identifiers -------------------------------------------------
    for field in ("event_id", "ticket_id"):

        if field in event and not _is_valid_identifier(event[field]):

            value = event[field]

            if isinstance(value, str):
                errors.append(f"Empty required field: {field}")
            else:
                errors.append(
                    f"Invalid {field}: expected non-empty str or int, "
                    f"got {type(value).__name__}."
                )

    # --- event type --------------------------------------------------
    if "event_type" in event:

        event_type = event["event_type"]

        if not isinstance(event_type, str):
            errors.append(
                "Invalid event_type: expected str, "
                f"got {type(event_type).__name__}."
            )

        elif not event_type.strip():
            errors.append("Empty required field: event_type")

        elif (
            allowed_event_types is not None
            and event_type not in allowed_event_types
        ):
            errors.append(
                f"Unsupported event_type: {event_type}"
            )

    # --- timestamp ---------------------------------------------------
    if "event_timestamp" in event:

        if not _is_valid_timestamp(event["event_timestamp"]):
            errors.append(
                "Invalid event_timestamp: expected an ISO-8601 "
                "string such as 2026-08-27T09:00:00."
            )

    # --- version -----------------------------------------------------
    if "event_version" in event:

        version = event["event_version"]

        if isinstance(version, bool) or not isinstance(version, int):
            errors.append(
                "Invalid event_version: expected int, "
                f"got {type(version).__name__}."
            )

        elif version < 0:
            errors.append(
                "Invalid event_version: must not be negative."
            )

    # --- optional data -----------------------------------------------
    if "data" in event and event["data"] is not None:

        if not isinstance(event["data"], dict):
            errors.append(
                "Invalid data: expected dict, "
                f"got {type(event['data']).__name__}."
            )

    return errors


class TicketEventProcessor:
    """
    Processes ticket events safely.

    Handles:
    - Duplicate events
    - Delayed events
    - Out-of-order events
    - Malformed events (see validate_event and the schema contract)
    """

    def __init__(self, allowed_event_types=None):

        # Optional whitelist of event types. None (default) accepts
        # any non-empty string, which is the original behaviour.
        self.allowed_event_types = allowed_event_types

        # Stores the latest state of every ticket
        self.ticket_state = {}

        # Stores processed event IDs for duplicate detection
        self.processed_events = set()

        # Stores rejected/ignored events for auditing
        self.event_log = []


    def process_event(self, event):
        """
        Process one incoming ticket event.

        Events that break the schema contract are rejected with status
        INVALID_EVENT_REJECTED. A rejected event never changes ticket
        state and is not recorded as processed, so a corrected event
        re-sent with the same event_id can still be applied.
        """

        # ------------------------------------------
        # 0. SCHEMA VALIDATION
        # ------------------------------------------

        validation_errors = validate_event(
            event,
            self.allowed_event_types
        )

        if validation_errors:

            safe_event = event if isinstance(event, dict) else {}

            result = {
                "status": INVALID_EVENT_STATUS,
                "ticket_id": safe_event.get("ticket_id"),
                "event_id": safe_event.get("event_id"),
                "message": (
                    "Event failed schema validation. "
                    "State was not changed."
                ),
                "errors": validation_errors
            }

            self.event_log.append(result)

            return result


        event_id = event["event_id"]
        ticket_id = event["ticket_id"]
        event_timestamp = event["event_timestamp"]
        event_version = event["event_version"]

        # ------------------------------------------
        # 1. DUPLICATE EVENT DETECTION
        # ------------------------------------------

        if event_id in self.processed_events:

            result = {
                "status": "DUPLICATE_IGNORED",
                "ticket_id": ticket_id,
                "event_id": event_id,
                "message": (
                    "Duplicate event detected. "
                    "State was not changed."
                )
            }

            self.event_log.append(result)

            return result


        # Mark event as processed
        self.processed_events.add(event_id)


        # ------------------------------------------
        # 2. FIRST EVENT FOR THIS TICKET
        # ------------------------------------------

        if ticket_id not in self.ticket_state:

            self.ticket_state[ticket_id] = {
                "latest_version": event_version,
                "latest_timestamp": event_timestamp,
                "event_type": event["event_type"],
                "data": copy.deepcopy(event.get("data") or {})
            }

            result = {
                "status": "APPLIED",
                "ticket_id": ticket_id,
                "event_id": event_id,
                "message": (
                    "First event applied successfully."
                )
            }

            self.event_log.append(result)

            return result


        # ------------------------------------------
        # 3. CHECK EVENT ORDER
        # ------------------------------------------

        current_state = self.ticket_state[ticket_id]

        current_version = current_state["latest_version"]


        # Older event version
        if event_version < current_version:

            result = {
                "status": "OUT_OF_ORDER_IGNORED",
                "ticket_id": ticket_id,
                "event_id": event_id,
                "message": (
                    "Older event received after a newer "
                    "event. State was not overwritten."
                )
            }

            self.event_log.append(result)

            return result


        # Same version but different event ID
        if event_version == current_version:

            result = {
                "status": "STALE_EVENT_IGNORED",
                "ticket_id": ticket_id,
                "event_id": event_id,
                "message": (
                    "Event version is not newer than "
                    "the current state."
                )
            }

            self.event_log.append(result)

            return result


        # ------------------------------------------
        # 4. NEWER EVENT
        # ------------------------------------------

        self.ticket_state[ticket_id] = {
            "latest_version": event_version,
            "latest_timestamp": event_timestamp,
            "event_type": event["event_type"],
            "data": copy.deepcopy(event.get("data") or {})
        }

        result = {
            "status": "APPLIED",
            "ticket_id": ticket_id,
            "event_id": event_id,
            "message": "Newer event applied successfully."
        }

        self.event_log.append(result)

        return result


    def get_ticket_state(self, ticket_id):
        """
        Return the current state of a ticket.
        """

        # Return a copy so callers cannot alter the stored state.
        return copy.deepcopy(self.ticket_state.get(ticket_id))


# ==========================================
# TEST FAILURE SCENARIOS
# ==========================================

if __name__ == "__main__":

    processor = TicketEventProcessor()


    # ======================================
    # TEST 1: NORMAL EVENT
    # ======================================

    event_1 = {
        "event_id": "E001",
        "ticket_id": "T1001",
        "event_type": "TICKET_CREATED",
        "event_timestamp": "2026-08-27T09:00:00",
        "event_version": 1,
        "data": {
            "priority": "P2",
            "message": "EHR service degraded"
        }
    }

    print("\n===== TEST 1: NORMAL EVENT =====")

    print(
        processor.process_event(event_1)
    )


    # ======================================
    # TEST 2: DUPLICATE EVENT
    # ======================================

    duplicate_event = event_1.copy()

    print("\n===== TEST 2: DUPLICATE EVENT =====")

    print(
        processor.process_event(duplicate_event)
    )


    # ======================================
    # TEST 3: NEWER EVENT
    # ======================================

    event_2 = {
        "event_id": "E002",
        "ticket_id": "T1001",
        "event_type": "PRIORITY_UPDATED",
        "event_timestamp": "2026-08-27T09:05:00",
        "event_version": 2,
        "data": {
            "priority": "P1",
            "message": "Issue escalated to critical"
        }
    }

    print("\n===== TEST 3: NEWER EVENT =====")

    print(
        processor.process_event(event_2)
    )


    # ======================================
    # TEST 4: OUT-OF-ORDER EVENT
    # ======================================

    delayed_old_event = {
        "event_id": "E003",
        "ticket_id": "T1001",
        "event_type": "PRIORITY_UPDATED",
        "event_timestamp": "2026-08-27T09:02:00",
        "event_version": 1,
        "data": {
            "priority": "P3",
            "message": "Older update arrived late"
        }
    }

    print("\n===== TEST 4: OUT-OF-ORDER EVENT =====")

    print(
        processor.process_event(
            delayed_old_event
        )
    )


    # ======================================
    # FINAL STATE CHECK
    # ======================================

    print("\n===== FINAL TICKET STATE =====")

    print(
        processor.get_ticket_state("T1001")
    )
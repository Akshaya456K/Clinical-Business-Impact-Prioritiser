# ==========================================
# RESPONSIBLE AI SAFETY AND FALLBACK LAYER
# ==========================================

REQUIRED_FIELDS = [
    "ticket_content",
    "affected_service",
    "user_group",
    "operating_schedule",
    "scope"
]

VALID_PRIORITIES = ["P1", "P2", "P3", "P4"]

# Confidence thresholds
HIGH_CONFIDENCE_THRESHOLD = 0.80
LOW_CONFIDENCE_THRESHOLD = 0.60


# ==========================================
# TEXT-VS-STRUCTURED-FIELDS CONSISTENCY CHECK
# ==========================================
#
# Guards against: high-impact evidence in the ticket text while the
# structured fields say low impact, which would otherwise be ACCEPTed.
#
# The text counts as STRONG high-impact evidence only when it contains
#   (a) a failure/outage term, AND
#   (b) a patient-safety context term OR a hospital-wide breadth term.
# Alarmist wording alone ("URGENT!!!", "outage" with no clinical context)
# is deliberately not enough, to avoid sending routine tickets to review.

import re

# Reuse the project's existing keyword / service lists.
from explanation import CRITICAL_KEYWORDS, CRITICAL_SERVICES

# (a) existing critical keywords plus a few outage phrasings
CONSISTENCY_FAILURE_TERMS = list(CRITICAL_KEYWORDS) + [
    "not arriving",
    "no alerts",
    "no incoming alerts",
    "stopped updating",
    "not responding",
    "unreachable",
    "offline"
]

# (b) patient-safety context
CONSISTENCY_CLINICAL_TERMS = [
    "icu",
    "intensive care",
    "nurse call",
    "medication",
    "medications",
    "dose",
    "doses",
    "emergency department",
    "a&e",
    "trauma",
    "bedside",
    "triage",
    "theatre",
    "patient charts",
    "patient records",
    "patient calls",
    "wards"
]

# (b) breadth of impact
CONSISTENCY_BREADTH_TERMS = [
    "entire",
    "whole hospital",
    "hospital-wide",
    "hospital wide",
    "all wards",
    "every ward",
    "across the hospital",
    "across the building"
]

# Structured fields indicate LOW impact when the scope is a single user,
# or when the service is not a critical service and the schedule is not
# one of the critical operating schedules.
CONSISTENCY_LOW_IMPACT_SCOPES = ["Single User"]
CONSISTENCY_CRITICAL_SCHEDULES = ["24/7", "Clinical Hours"]


def validate_ticket(ticket):
    """
    Check whether all required fields are present
    and contain meaningful values.
    """

    errors = []

    for field in REQUIRED_FIELDS:

        if field not in ticket:
            errors.append(
                f"Missing required field: {field}"
            )

        elif ticket[field] is None:

            errors.append(
                f"Empty required field: {field}"
            )

        elif isinstance(ticket[field], str) and not ticket[field].strip():

            errors.append(
                f"Empty required field: {field}"
            )

    return errors


def _matched_terms(text, terms):
    """Whole-word / whole-phrase matches of terms in lower-cased text."""

    return [
        term for term in terms
        if re.search(
            r"(?<![a-z0-9])" + re.escape(term) + r"(?![a-z0-9])",
            text
        )
    ]


def find_text_field_conflict(ticket):
    """
    Return a reason string when the ticket text strongly describes a
    high-impact incident but the structured fields indicate low impact.
    Return None when there is no conflict (including when the structured
    fields already indicate high impact, which is consistent).
    """

    text = str(ticket.get("ticket_content", "")).lower()

    failure = _matched_terms(text, CONSISTENCY_FAILURE_TERMS)
    context = (
        _matched_terms(text, CONSISTENCY_CLINICAL_TERMS)
        + _matched_terms(text, CONSISTENCY_BREADTH_TERMS)
    )

    # Text is not strong high-impact evidence
    if not failure or not context:
        return None

    structured_low_impact = (
        ticket.get("scope") in CONSISTENCY_LOW_IMPACT_SCOPES
        or (
            ticket.get("affected_service") not in CRITICAL_SERVICES
            and ticket.get("operating_schedule")
            not in CONSISTENCY_CRITICAL_SCHEDULES
        )
    )

    if not structured_low_impact:
        return None

    return (
        "Ticket text indicates a possible high-impact incident ("
        + ", ".join(failure + context)
        + ") but the structured fields indicate low impact (scope: "
        + f"{ticket.get('scope')}; service: "
        + f"{ticket.get('affected_service')}; schedule: "
        + f"{ticket.get('operating_schedule')}). "
        "Conflicting evidence requires human review."
    )


# ==========================================
# LEARNED TEXT-VS-STRUCTURE SIGNAL
# ==========================================
#
# Complements the keyword rule above, which cannot recognise incidents that
# are described without the listed words. Two small auxiliary models
# (see train_signal_models.py) estimate P(high impact) from the ticket text
# alone and from the structured fields alone. They are NOT the production
# classifier and they never lower an escalation: they can only
#   (a) turn an otherwise-ACCEPTed ticket into HUMAN_REVIEW, or
#   (b) attach an informational warning to an escalated ticket.
# If the auxiliary models are missing or fail, this check is skipped and the
# rest of the safety layer behaves exactly as before.

from pathlib import Path

import joblib

from env_check import check_sklearn_version
from text_evidence import describe_operational_impact, extract_evidence
from train_signal_models import (
    STRUCT_LOW_THRESHOLD,
    STRUCTURED,
    STRUCT_MODEL_PATH,
    TEXT_HIGH_THRESHOLD,
    TEXT_MODEL_PATH,
    p_high as _signal_p_high
)

FLAG_KEYWORD_CONFLICT = "TEXT_FIELD_CONFLICT_KEYWORD"
FLAG_LEARNED_CONFLICT = "TEXT_FIELD_CONFLICT_LEARNED"
FLAG_TEXT_LOW_FIELDS_HIGH = "TEXT_LOW_FIELDS_HIGH"
FLAG_SIGNAL_UNAVAILABLE = "SIGNAL_CHECK_UNAVAILABLE"
FLAG_OPERATIONAL_IMPACT = "TEXT_OPERATIONAL_IMPACT_EVIDENCE"
FLAG_INSUFFICIENT_INFO = "INSUFFICIENT_INFORMATION"
FLAG_STRUCTURED_HIGH_MODEL_LOW = "FIELDS_HIGH_MODEL_LOW"

# The reverse-direction warning (text looks low impact, fields look high
# impact, ticket escalated) is DISABLED by default. On the 225-case
# robustness suite it fired on 44 escalated tickets, of which only 11 were
# genuine mismatches; the other 33 were real incidents whose wording the
# text-only model could not read (precision 25%). A warning that is wrong
# three times out of four causes alert fatigue, so it is off unless a
# better signal is available. It never changes an escalation either way.
ENABLE_TEXT_LOW_FIELDS_HIGH_WARNING = False

_signal_models_cache = {}


def _get_signal_models():
    """Load (and cache) the auxiliary models; None if unavailable."""

    if "models" not in _signal_models_cache:

        # Version mismatch must surface, not be swallowed as 'unavailable'.
        check_sklearn_version()

        try:
            _signal_models_cache["models"] = (
                joblib.load(TEXT_MODEL_PATH),
                joblib.load(STRUCT_MODEL_PATH)
            )
        except Exception:
            _signal_models_cache["models"] = None

    return _signal_models_cache["models"]


def get_signal_probabilities(ticket):
    """
    Return (P_text_high, P_structured_high) for a ticket,
    or None when the auxiliary models are unavailable or fail.
    """

    models = _get_signal_models()

    if models is None:
        return None

    text_model, struct_model = models

    try:
        import pandas as pd

        row = pd.DataFrame([{
            "ticket_content": str(ticket.get("ticket_content", "")),
            **{field: ticket.get(field) for field in STRUCTURED}
        }])

        return (
            float(_signal_p_high(text_model, row["ticket_content"])[0]),
            float(_signal_p_high(struct_model, row[STRUCTURED])[0])
        )

    except Exception:
        return None


def find_learned_conflict(ticket, probabilities=None):
    """
    Reason string when an independent text-only model indicates high impact
    but the structured fields indicate low impact; otherwise None.
    """

    probabilities = probabilities or get_signal_probabilities(ticket)

    if probabilities is None:
        return None

    p_text, p_struct = probabilities

    if p_text >= TEXT_HIGH_THRESHOLD and p_struct < STRUCT_LOW_THRESHOLD:

        return (
            "Ticket text is assessed as high impact by an independent "
            f"text-only model (P(high)={p_text:.2f}) but the structured "
            f"fields indicate low impact (P(high)={p_struct:.2f}). "
            "Conflicting evidence requires human review."
        )

    return None


def has_text_low_fields_high_mismatch(probabilities):
    """
    True when the text looks low impact but the structured fields look high
    impact. Used only as an informational warning on escalated tickets.
    """

    if probabilities is None:
        return False

    p_text, p_struct = probabilities

    return p_text < TEXT_HIGH_THRESHOLD and p_struct >= STRUCT_LOW_THRESHOLD


# ==========================================
# ROUND 4: EVIDENCE-BASED CHECKS ON TEXT / FIELDS / MODEL
# ==========================================
#
# All three checks below apply ONLY to a decision that would otherwise be
# ACCEPT, and can only change it to HUMAN_REVIEW. Escalations and existing
# review decisions are never touched.
#
#   1. operational-impact evidence in the text (concept based, see
#      text_evidence.py) while the model / fields say low impact
#   2. insufficient information: the text names no identifiable problem
#      AND the structured fields show potential for meaningful impact
#      (a critical service, a 24/7 service, or a department/hospital-wide
#      scope). Vague text on a clearly low-risk service stays ACCEPT.
#   3. the independent structured-fields model says high impact while the
#      production model is about to ACCEPT as low impact

# Structured P(high) at/above this is "fields clearly indicate high impact".
# 0.5 raised 5 in-distribution false alarms on 600 ordinary P3 training
# tickets (multi-user Staff Portal slowness, aux-model P(high)=0.75), so a
# clearly-high 0.8 is used. Fixed from the TRAINING data only; no
# robustness case changes outcome between 0.5 and 0.8.
STRUCT_HIGH_THRESHOLD = 0.8

BROAD_SCOPES = ["Department", "Hospital-wide"]
ALWAYS_ON_SCHEDULES = ["24/7"]


def structured_fields_indicate_potential_impact(ticket):
    """
    True when the metadata alone means a vague ticket cannot be assumed
    to be low impact: critical service, always-on service, or broad scope.
    """

    return (
        ticket.get("affected_service") in CRITICAL_SERVICES
        or ticket.get("operating_schedule") in ALWAYS_ON_SCHEDULES
        or ticket.get("scope") in BROAD_SCOPES
    )


def find_operational_impact_conflict(ticket, evidence=None):
    """Reason string when the text itself describes meaningful impact."""

    evidence = evidence or extract_evidence(ticket.get("ticket_content", ""))

    if not evidence["operational_impact_evidence"]:
        return None

    return (
        "Ticket text describes potentially meaningful operational or "
        "clinical impact (" + describe_operational_impact(evidence) + ") "
        "but the prediction treats it as routine "
        f"(scope: {ticket.get('scope')}; service: "
        f"{ticket.get('affected_service')}). "
        "Uncertain impact requires human review."
    )


def find_insufficient_information_risk(ticket, evidence=None):
    """
    Reason string when the text is too vague to judge impact AND the
    metadata shows potential for meaningful impact; otherwise None.
    """

    evidence = evidence or extract_evidence(ticket.get("ticket_content", ""))

    if not evidence["lacks_identifiable_problem"]:
        return None

    if not structured_fields_indicate_potential_impact(ticket):
        return None

    return (
        "Ticket text does not describe an identifiable problem, so impact "
        "cannot be judged from it, and the structured fields (service: "
        f"{ticket.get('affected_service')}; schedule: "
        f"{ticket.get('operating_schedule')}; scope: {ticket.get('scope')}) "
        "show potential for meaningful impact. Confidence is not "
        "supported by the text; insufficient information requires "
        "human review."
    )


def find_fields_high_model_low_conflict(probabilities):
    """Reason string when the fields-only model says high but ACCEPT is pending."""

    if probabilities is None:
        return None

    _, p_struct = probabilities

    if p_struct >= STRUCT_HIGH_THRESHOLD:

        return (
            "Structured fields are assessed as high impact by an "
            f"independent model (P(high)={p_struct:.2f}) but the "
            "prediction treats the ticket as routine. Conflicting "
            "evidence requires human review."
        )

    return None


def evaluate_prediction(
    predicted_priority,
    confidence,
    evidence
):
    """
    Decide whether the prediction can be accepted,
    escalated, or requires human review.
    """

    confidence = float(confidence)

    # ------------------------------------------
    # LOW CONFIDENCE
    # ------------------------------------------

    if confidence < LOW_CONFIDENCE_THRESHOLD:

        return {
            "action": "HUMAN_REVIEW",
            "reason": (
                "Prediction confidence is below "
                f"{LOW_CONFIDENCE_THRESHOLD * 100:.0f}%."
            )
        }

    # ------------------------------------------
    # HIGH-IMPACT WITH INSUFFICIENT EVIDENCE
    # ------------------------------------------

    if predicted_priority in ["P1", "P2"]:

        if not evidence or len(evidence) < 3:

            return {
                "action": "HUMAN_REVIEW",
                "reason": (
                    "High-impact prediction does not "
                    "contain sufficient supporting evidence."
                )
            }

        # P1 always gets urgent escalation
        if predicted_priority == "P1":

            return {
                "action": "URGENT_ESCALATION",
                "reason": (
                    "High-impact P1 incident with "
                    "sufficient evidence."
                )
            }

        # P2
        if confidence < HIGH_CONFIDENCE_THRESHOLD:

            return {
                "action": "HUMAN_REVIEW",
                "reason": (
                    "P2 incident requires review because "
                    "confidence is below "
                    f"{HIGH_CONFIDENCE_THRESHOLD * 100:.0f}%."
                )
            }

        return {
            "action": "PRIORITY_ESCALATION",
            "reason": (
                "P2 incident with high confidence "
                "and sufficient evidence."
            )
        }

    # ------------------------------------------
    # NORMAL PRIORITY
    # ------------------------------------------

    return {
        "action": "ACCEPT",
        "reason": (
            "Prediction passed confidence and "
            "evidence checks."
        )
    }


def validate_and_decide(
    ticket,
    prediction_result
):
    """
    Validate ticket input and decide what action
    should be taken.
    """

    validation_errors = validate_ticket(ticket)

    if validation_errors:

        return {
            "safe": False,
            "action": "HUMAN_REVIEW",
            "reason": "Invalid or incomplete ticket input.",
            "errors": validation_errors,
            "flags": []
        }

    decision = evaluate_prediction(
        predicted_priority=
        prediction_result["predicted_priority"],

        confidence=
        prediction_result["confidence"] / 100,

        evidence=
        prediction_result["evidence"]
    )

    # Consistency checks: never ACCEPT when the text indicates a high-impact
    # incident but the structured fields indicate low impact. Only an
    # otherwise-ACCEPTed decision can change; every existing escalation /
    # review decision is left exactly as it was.
    flags = []

    if decision["action"] == "ACCEPT":

        keyword_reason = find_text_field_conflict(ticket)
        learned_reason = find_learned_conflict(ticket)

        if keyword_reason:
            flags.append(FLAG_KEYWORD_CONFLICT)

        if learned_reason:
            flags.append(FLAG_LEARNED_CONFLICT)

        text_evidence = extract_evidence(ticket.get("ticket_content", ""))
        operational_reason = find_operational_impact_conflict(
            ticket, text_evidence
        )
        insufficient_reason = find_insufficient_information_risk(
            ticket, text_evidence
        )
        fields_high_reason = find_fields_high_model_low_conflict(
            get_signal_probabilities(ticket)
        )

        if operational_reason:
            flags.append(FLAG_OPERATIONAL_IMPACT)

        if insufficient_reason:
            flags.append(FLAG_INSUFFICIENT_INFO)

        if fields_high_reason:
            flags.append(FLAG_STRUCTURED_HIGH_MODEL_LOW)

        review_reason = (
            keyword_reason
            or learned_reason
            or operational_reason
            or insufficient_reason
            or fields_high_reason
        )

        if review_reason:

            decision = {
                "action": "HUMAN_REVIEW",
                "reason": review_reason
            }

        elif _get_signal_models() is None:
            flags.append(FLAG_SIGNAL_UNAVAILABLE)

    elif decision["action"] in [
        "URGENT_ESCALATION",
        "PRIORITY_ESCALATION"
    ]:

        # Escalations are never downgraded. If the text looks low impact
        # while the fields look high impact, only a warning is attached.
        if ENABLE_TEXT_LOW_FIELDS_HIGH_WARNING and has_text_low_fields_high_mismatch(
            get_signal_probabilities(ticket)
        ):
            flags.append(FLAG_TEXT_LOW_FIELDS_HIGH)

    return {
        "safe": decision["action"] == "ACCEPT",
        "action": decision["action"],
        "reason": decision["reason"],
        "errors": [],
        "flags": flags
    }


# ==========================================
# TEST SAFETY LOGIC
# ==========================================

if __name__ == "__main__":

    # Test 1: Valid P1
    valid_ticket = {
        "ticket_content": "EHR system is down.",
        "affected_service": "EHR",
        "user_group": "ICU Clinicians",
        "operating_schedule": "24/7",
        "scope": "Hospital-wide"
    }

    valid_prediction = {
        "predicted_priority": "P1",
        "confidence": 98.0,
        "evidence": [
            "Critical clinical service affected: EHR",
            "High-impact clinical users affected: ICU Clinicians",
            "Impact scope: Hospital-wide"
        ]
    }

    result = validate_and_decide(
        valid_ticket,
        valid_prediction
    )

    print("\n===== TEST 1: VALID P1 =====")
    print(result)


    # Test 2: Missing field
    incomplete_ticket = {
        "ticket_content": "System is down",
        "affected_service": "EHR"
    }

    result = validate_and_decide(
        incomplete_ticket,
        valid_prediction
    )

    print("\n===== TEST 2: MISSING FIELDS =====")
    print(result)


    # Test 3: Low confidence
    low_confidence_prediction = {
        "predicted_priority": "P2",
        "confidence": 45.0,
        "evidence": [
            "Affected service: EHR",
            "User group: Doctors",
            "Impact scope: Department"
        ]
    }

    result = validate_and_decide(
        valid_ticket,
        low_confidence_prediction
    )

    print("\n===== TEST 3: LOW CONFIDENCE =====")
    print(result)
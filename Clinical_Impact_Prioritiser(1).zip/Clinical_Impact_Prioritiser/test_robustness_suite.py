"""
Robustness-suite tests.

Part 1 checks dataset integrity (all nine requested categories present, valid
labels, explicit expected handling, no leakage from the training data).

Part 2 are REGRESSION GUARDS on the current behaviour of the full decision
pipeline. They record what the system does today so that a future change
cannot silently make safety worse. They are not performance targets, and the
known failures are listed explicitly rather than hidden:

  X087  obfuscated surgical-impact text with low-impact fields  (false acceptance)
  X110  vague text, EHR service, single user                     (false acceptance)
  X111  contentless text, Nurse Call service, single user        (false acceptance)

Fixing any of these makes the test below pass with a smaller set; a new
false acceptance makes it fail.

Run:  python -m unittest test_robustness_suite -v
"""
import unittest
from pathlib import Path

import pandas as pd

import evaluate_robustness as er

BASE = Path(__file__).resolve().parent
KNOWN_FALSE_ACCEPTANCES = {"X087", "X110", "X111"}


class TestDatasetIntegrity(unittest.TestCase):

    @classmethod
    def setUpClass(cls):
        cls.ext = pd.read_csv(BASE / "robustness" / "robustness_extended_cases.csv")
        cls.leg = pd.read_csv(BASE / "robustness" / "robustness_test_cases.csv")
        cls.train = pd.read_csv(BASE / "hospital_it_tickets.csv")

    def test_all_nine_requested_categories_present_in_extended_suite(self):
        self.assertEqual(set(self.ext["category"]), set(er.REPORT_CATEGORIES))
        for cat, n in self.ext["category"].value_counts().items():
            self.assertGreaterEqual(n, 10, cat)

    def test_legacy_categories_all_map_to_report_categories(self):
        self.assertTrue(set(self.leg["category"]) <= set(er.LEGACY_CATEGORY_MAP))
        self.assertTrue(set(er.LEGACY_CATEGORY_MAP.values()) <= set(er.REPORT_CATEGORIES))

    def test_legacy_cases_are_intact(self):
        """The first-round cases must never be deleted or edited."""
        self.assertEqual(len(self.leg), 110)
        self.assertEqual(self.leg["case_id"].tolist(), [f"R{i:03d}" for i in range(1, 111)])

    def test_schema_and_vocabulary(self):
        for df in (self.ext, self.leg):
            self.assertTrue(set(er.FEATURES + ["expected_priority"]) <= set(df.columns))
            self.assertTrue(set(df["expected_priority"]) <= set(er.LABELS))
            self.assertFalse(df[er.FEATURES].isna().any().any())
        self.assertTrue(set(self.ext["expected_handling"]) <= {er.ESC, er.ACC, er.REV})
        self.assertTrue(set(self.ext["conflict_type"]) <=
                        {"none", "text_high_fields_low", "text_low_fields_high", "ambiguous"})
        self.assertTrue(self.ext["case_id"].is_unique)
        self.assertTrue(self.ext["ticket_content"].is_unique)

    def test_expected_handling_is_consistent_with_expected_priority_for_plain_cases(self):
        plain = self.ext[self.ext["conflict_type"] == "none"]
        high = plain["expected_priority"].isin(er.HIGH)
        self.assertTrue((plain.loc[high, "expected_handling"] == er.ESC).all())
        self.assertTrue((plain.loc[~high, "expected_handling"] == er.ACC).all())

    def test_conflict_cases_define_explicit_expected_behaviour(self):
        c = self.ext[self.ext["conflict_type"] == "text_high_fields_low"]
        self.assertGreaterEqual(len(c), 10)
        self.assertTrue((c["expected_handling"] == er.REV).all())
        rev = self.ext[self.ext["conflict_type"] == "text_low_fields_high"]
        self.assertGreaterEqual(len(rev), 5)
        self.assertTrue((rev["expected_handling"] == er.ESC).all())  # never silently accepted

    def test_requested_abbreviations_and_adversarial_features_are_covered(self):
        text = " ".join(self.ext["ticket_content"]).lower()
        for abbr in ("icu", "ehr", "emr", "pacu", " or ", "er ", "mar "):
            self.assertIn(abbr, text + " ", abbr)
        adv = self.ext[self.ext["category"] == "adversarial"]["ticket_content"].str.lower()
        obvious = ("critical", "outage", "down", "emergency")
        hidden = adv[~adv.apply(lambda t: any(w in t.split() for w in obvious))]
        self.assertGreaterEqual(len(hidden), 8)  # most adversarial text avoids the obvious words

    def test_no_text_overlap_with_training_or_between_suites(self):
        norm = lambda s: " ".join(str(s).lower().split())
        tr = {norm(t) for t in self.train["ticket_content"]}
        le = {norm(t) for t in self.leg["ticket_content"]}
        ex = {norm(t) for t in self.ext["ticket_content"]}
        self.assertEqual(ex & tr, set())
        self.assertEqual(le & tr, set())
        self.assertEqual(ex & le, set())


class TestPipelineRegressionGuards(unittest.TestCase):

    @classmethod
    def setUpClass(cls):
        import warnings
        with warnings.catch_warnings():
            warnings.simplefilter("ignore")
            cls.res = er.add_flags(er.run_pipeline(er.load_cases("all")))
        cls.ext = cls.res[cls.res["suite"] == "extended"]
        cls.leg = cls.res[cls.res["suite"] == "legacy"]

    def test_ml_scoring_does_not_use_expected_labels(self):
        """Predictions depend only on the five model features."""
        shuffled = er.load_cases("extended").copy()
        shuffled["expected_priority"] = "P4"
        shuffled["expected_handling"] = er.ACC
        again = er.run_pipeline(shuffled)
        self.assertEqual(again["predicted_priority"].tolist(), self.ext["predicted_priority"].tolist())
        self.assertEqual(again["action"].tolist(), self.ext["action"].tolist())

    def test_false_acceptances_are_only_the_documented_known_gaps(self):
        unsafe = set(self.res.loc[self.res["false_acceptance"], "case_id"])
        self.assertLessEqual(unsafe, KNOWN_FALSE_ACCEPTANCES, f"NEW unsafe acceptance(s): {unsafe - KNOWN_FALSE_ACCEPTANCES}")

    def test_no_false_acceptance_in_first_round_suite(self):
        self.assertEqual(int(self.leg["false_acceptance"].sum()), 0)

    def test_text_high_fields_low_conflicts_are_routed_to_human_review(self):
        c = self.ext[self.ext["conflict_type"] == "text_high_fields_low"]
        routed = int((c["action"] == "HUMAN_REVIEW").sum())
        self.assertGreaterEqual(routed, 13)           # 13 of 14 today (X087 is the known miss)
        self.assertEqual(int((c["action"] == "ACCEPT").sum()), len(c) - routed - int(c["action"].isin(
            ["URGENT_ESCALATION", "PRIORITY_ESCALATION"]).sum()))

    def test_reverse_conflicts_are_never_accepted(self):
        r = self.ext[self.ext["conflict_type"] == "text_low_fields_high"]
        self.assertTrue((r["action"] != "ACCEPT").all())

    def test_clean_cases_are_correct_and_not_over_reviewed(self):
        clean = self.res[self.res["category"] == "clean"]
        self.assertTrue(clean["correct"].all())
        self.assertEqual(int((clean["action"] == "HUMAN_REVIEW").sum()), 0)

    def test_text_noise_categories_keep_perfect_priority_accuracy(self):
        for cat in ("spelling", "noisy", "paraphrased"):
            d = self.res[(self.res["category"] == cat) & self.res["conflict_type"].isin(["none", "unspecified"])]
            self.assertTrue(d["correct"].all(), cat)

    def test_every_expected_high_impact_plain_case_is_not_accepted(self):
        plain_high = self.res[(self.res["conflict_type"].isin(["none", "unspecified"])) &
                              (self.res["expected_handling"] == er.ESC)]
        self.assertEqual(int((plain_high["action"] == "ACCEPT").sum()), 0)

    def test_review_burden_stays_bounded(self):
        self.assertLessEqual(float((self.res["action"] == "HUMAN_REVIEW").mean()), 0.15)
        low = self.res[self.res["expected_handling"] == er.ACC]
        self.assertLessEqual(float(low["false_rejection"].mean()), 0.20)

    def test_alarmist_but_trivial_tickets_are_not_sent_to_review(self):
        t = self.leg[self.leg["ticket_content"].str.contains("Catastrophic emergency|CRITICAL URGENT DOWN|Terrible outage", regex=True)]
        self.assertEqual(len(t), 3)
        self.assertTrue((t["action"] == "ACCEPT").all())

    def test_pipeline_outputs_confidence_type(self):
        self.assertTrue(self.res["confidence_type"].isin(["raw", "calibrated"]).all())

    def test_summary_metrics_are_computed_from_the_rows(self):
        m = er.metrics(self.res)
        self.assertEqual(m["n_cases"], len(self.res))
        self.assertEqual(m["safety"]["false_acceptance"], int(self.res["false_acceptance"].sum()))
        self.assertEqual(sum(m["safety"]["action_counts"].values()), len(self.res))


if __name__ == "__main__":
    unittest.main(verbosity=2)

"""
Generates robustness/robustness_extended_cases.csv.

These cases were written BEFORE any change to the safety layer in this
round and are never used for training, calibration or rule development.
They are evaluated as-is; the expected values below are not edited after
looking at model output.

Columns
-------
expected_priority  priority implied by the text and the dataset's convention
expected_handling  ESCALATE_OR_REVIEW : high impact; must NOT be auto-ACCEPTed
                   ACCEPT_NORMAL      : low impact; ACCEPT is the intended route
                   REVIEW_REQUIRED    : text/fields genuinely conflict; HUMAN_REVIEW expected
conflict_type      none | text_high_fields_low | text_low_fields_high | ambiguous
label_confidence   clear | borderline
"""
import csv
from pathlib import Path

OUT = Path(__file__).resolve().parent / "robustness_extended_cases.csv"

# service / group / schedule / scope shorthands
EHR, MM, NC, NET, ID, LIS, PACS, EM, PR, SP = (
    "EHR", "Medication Management", "Nurse Call System", "Hospital Network",
    "Identity/Login", "Laboratory Information System", "PACS/Radiology",
    "Email", "Printing", "Staff Portal")
ICU, ED, DR, NU, AD, LAB, RAD, IT = (
    "ICU Clinicians", "Emergency Department Clinicians", "Doctors", "Nurses",
    "Administrative Staff", "Laboratory Staff", "Radiology Staff", "IT Staff")
A7, BH, CH, SC = "24/7", "Business Hours", "Clinical Hours", "Scheduled/Non-Critical"
SU, DE, HW, MU = "Single User", "Department", "Hospital-wide", "Multiple Users"

ESC, ACC, REV = "ESCALATE_OR_REVIEW", "ACCEPT_NORMAL", "REVIEW_REQUIRED"
rows = []


def add(cat, text, svc, grp, sch, scope, pri, handling, conflict="none",
        conf="clear", why=""):
    rows.append([cat, text, svc, grp, sch, scope, pri, conf, why, handling, conflict])


# ---------------------------------------------------------------- A. clean
c = "clean"
add(c, "The Nurse Call System is not delivering patient alerts to the nursing station on Ward 5. Nurses are checking rooms manually.", NC, NU, A7, DE, "P1", ESC, why="Nurse call failure")
add(c, "Medication Management is unavailable for ICU nurses. Doses cannot be verified before administration.", MM, ICU, A7, DE, "P1", ESC, why="Medication verification blocked")
add(c, "The EHR is unavailable across the hospital and emergency department clinicians cannot open patient records.", EHR, ED, A7, HW, "P1", ESC, why="Hospital-wide EHR outage")
add(c, "The Hospital Network is unavailable across the whole site, so ward devices have lost connectivity.", NET, NU, A7, HW, "P1", ESC, why="Site-wide network outage")
add(c, "Laboratory staff cannot send results from the Laboratory Information System. The whole department is affected.", LIS, LAB, CH, DE, "P2", ESC, why="Department LIS outage")
add(c, "Radiology staff report that PACS images are loading very slowly for the entire department.", PACS, RAD, CH, DE, "P2", ESC, why="Department imaging degradation")
add(c, "Several nurses on one ward cannot sign in through Identity/Login this morning.", ID, NU, BH, MU, "P2", ESC, why="Multi-user login failure")
add(c, "A doctor cannot log into the EHR after changing their password.", EHR, DR, BH, SU, "P3", ACC, why="Single-user EHR access")
add(c, "A shared mailbox is not opening for the records team.", EM, AD, BH, DE, "P3", ACC, why="Partial email issue")
add(c, "A radiologist cannot open one study in PACS. Other studies load normally.", PACS, RAD, CH, SU, "P3", ACC, why="Single-user imaging issue")
add(c, "Please install a PDF reader on a new administrative workstation.", SP, AD, SC, SU, "P4", ACC, why="Routine install")
add(c, "The ward printer needs a new toner cartridge.", PR, NU, BH, SU, "P4", ACC, why="Consumable")
add(c, "An employee would like a mailbox alias added to their account.", EM, AD, SC, SU, "P4", ACC, why="Routine request")
add(c, "The Staff Portal shows the wrong department for one new employee.", SP, AD, BH, SU, "P4", ACC, why="Single-user cosmetic")

# ------------------------------------------------------------- B. spelling
c = "spelling"
add(c, "ICU servce is down", EHR, ICU, A7, DE, "P1", ESC, why="Garbled ICU service outage")
add(c, "patint records not accesible for the whole er team", EHR, ED, A7, HW, "P1", ESC, why="Patient record access lost in ED")
add(c, "medicaton system unavailble, nurses cant give scheduled drugs", MM, ICU, A7, DE, "P1", ESC, why="Medication system unavailable")
add(c, "nurce call buzers silant on the childrens ward", NC, NU, A7, DE, "P1", ESC, why="Nurse call failure")
add(c, "labratory results are stuk and not reaching the wards", LIS, LAB, CH, DE, "P2", ESC, why="LIS department failure")
add(c, "raiology viewr wont open scans for the departmnt", PACS, RAD, CH, DE, "P2", ESC, why="Department imaging outage")
add(c, "sevral docters cant autheticate this mornig", ID, DR, BH, MU, "P2", ESC, why="Multi-user login failure")
add(c, "one nures cant opn the ehr scren", EHR, NU, BH, SU, "P3", ACC, why="Single-user EHR")
add(c, "shred mailbx wont load for the finace team", EM, AD, BH, DE, "P3", ACC, why="Partial email issue")
add(c, "prnter in recption is jamed agian", PR, AD, BH, SU, "P4", ACC, why="Printer jam")
add(c, "pleese reset pasword for one lab techncian", ID, IT, BH, SU, "P4", ACC, why="Password reset")
add(c, "staf portl is showng last weks rota to one persn", SP, NU, BH, SU, "P4", ACC, why="Single-user portal")
add(c, "netwrk is compeltely off acros the hosital, no wardd can conect", NET, NU, A7, HW, "P1", ESC, why="Hospital-wide network outage")

# --------------------------------------------------------- C. abbreviations
c = "abbreviations"
add(c, "EMR unreachable from ICU bedside terminals, all shifts affected", EHR, ICU, A7, DE, "P1", ESC, why="EMR outage in ICU")
add(c, "MAR not loading in PACU, RNs cannot chart or confirm meds", MM, NU, CH, DE, "P1", ESC, why="MAR unavailable; medication safety")
add(c, "OR team locked out of EHR before list start, whole theatre suite", EHR, DR, CH, HW, "P1", ESC, why="Theatre-wide EHR lockout")
add(c, "ER triage board blank, EHR not responding hosp-wide", EHR, ED, A7, HW, "P1", ESC, why="ED triage and EHR outage")
add(c, "NCS silent on ICU pods 2 and 3, no pt call alerts", NC, ICU, A7, DE, "P1", ESC, why="Nurse call failure")
add(c, "PACS viewer down for ER docs, CT head scans cant be opened", PACS, ED, A7, DE, "P1", ESC, why="ED imaging outage")
add(c, "LIS to EMR interface backed up, lab dept results delayed", LIS, LAB, CH, DE, "P2", ESC, why="LIS interface delay at department level")
add(c, "RAD dept PACS very slow, MRI backlog building", PACS, RAD, CH, DE, "P2", ESC, why="Imaging degradation")
add(c, "SSO failing for several RNs on 4N, AD sync suspected", ID, NU, BH, MU, "P2", ESC, why="Multi-user login failure")
add(c, "1 RN cant open EMR chart after update, others fine", EHR, NU, BH, SU, "P3", ACC, why="Single-user EHR")
add(c, "pls add MS Office to new WS in OR admin office", SP, AD, SC, SU, "P4", ACC, why="Routine install")
add(c, "PW reset for 1 PACU clerk pls", ID, AD, BH, SU, "P4", ACC, why="Password reset")
add(c, "printer in ER admin out of paper again", PR, AD, BH, SU, "P4", ACC, why="Consumable")

# ------------------------------------------------------------------ D. noisy
c = "noisy"
add(c, "  EHR   is  DOWN   in   ICU    ,,   all  clinicans  cant   see   charts  ", EHR, ICU, A7, DE, "P1", ESC, why="Extra spaces, mixed noise; EHR outage")
add(c, "meds   sys ...  frozen   nurses  waitng   ICU  !!", MM, ICU, A7, DE, "P1", ESC, why="Fragmentary medication freeze")
add(c, "NuRsE cAlL pAnEl DeAd wArD 7", NC, NU, A7, DE, "P1", ESC, why="Mixed casing; nurse call")
add(c, "net work   gone   whole   hosp   no   wi fi   anywhere", NET, DR, A7, HW, "P1", ESC, why="Broken words; site-wide network loss")
add(c, "lab  results   not   going  out  .. dept   wide  ", LIS, LAB, CH, DE, "P2", ESC, why="Fragment; department LIS")
add(c, "XRAY  imgs  wnt  opn   rad  dept", PACS, RAD, CH, DE, "P2", ESC, why="Typos; imaging department")
add(c, "login  fails   for   a   few   nurses ,,,", ID, NU, BH, MU, "P2", ESC, why="Multi-user login")
add(c, "ehr  slooow  for  1  admin   user", EHR, AD, BH, SU, "P3", ACC, why="Single-user slowness")
add(c, "shared   mailbox   ???   not   opening", EM, AD, BH, DE, "P3", ACC, why="Partial email")
add(c, "toner   ward 3   printr", PR, NU, BH, SU, "P4", ACC, why="Fragment printer")
add(c, "pw   reset   1   user", ID, AD, BH, SU, "P4", ACC, why="Fragment password reset")
add(c, "portal   rota   wrong   1   person", SP, NU, BH, SU, "P4", ACC, why="Fragment portal")
add(c, "a e   emr   not   loading   ", EHR, ED, A7, DE, "P1", ESC, why="Fragment ED EHR outage")

# --------------------------------------------------------- E. paraphrased
c = "paraphrased"
add(c, "Clinical staff across multiple wards are unable to retrieve patient records.", EHR, DR, CH, HW, "P1", ESC, why="Indirect EHR outage, hospital-wide")
add(c, "Nursing teams on the intensive care unit have gone back to paper drug charts because the electronic system will not accept entries.", MM, ICU, A7, DE, "P1", ESC, why="Paper fallback implies outage")
add(c, "Bedside call signals from patient rooms are not appearing at the central desk, so staff are walking the corridors.", NC, NU, A7, DE, "P1", ESC, why="Indirect nurse call failure")
add(c, "Casualty clinicians cannot view any imaging for patients arriving by ambulance.", PACS, ED, A7, DE, "P1", ESC, why="ED imaging unavailable")
add(c, "Everyone on the ward is repeatedly thrown back to the sign-in screen and cannot stay logged in.", ID, NU, BH, DE, "P2", ESC, why="Ward-level login instability")
add(c, "Specimen results are queuing up and are not being released to the requesting teams.", LIS, LAB, CH, DE, "P2", ESC, why="LIS release failure")
add(c, "The reading room cannot pull up scans for reporting.", PACS, RAD, CH, DE, "P2", ESC, why="Department imaging outage")
add(c, "A single physician is refused entry to the patient record system with their own credentials.", EHR, DR, BH, SU, "P3", ACC, why="Single-user access")
add(c, "One person's calendar invitations are not arriving in their mailbox.", EM, AD, BH, SU, "P4", ACC, why="Single-user email")
add(c, "Someone from IT is needed to look at the jammed office copier.", PR, AD, BH, SU, "P4", ACC, why="Printer request")
add(c, "The whole site has lost its connection and ward terminals are blank.", NET, NU, A7, HW, "P1", ESC, why="Site-wide connectivity loss")
add(c, "A new starter needs the standard applications set up on their desktop.", SP, AD, SC, SU, "P4", ACC, why="Onboarding")

# ------------------------------------------------------ F. multi-system
c = "multi_system"
add(c, "EHR and the medication system are both failing for ICU, nurses cannot see orders or confirm doses.", EHR, ICU, A7, DE, "P1", ESC, why="EHR + medication, ICU")
add(c, "Patient admission and clinical documentation are both stalled; wards cannot register arrivals or write notes.", EHR, NU, A7, DE, "P1", ESC, why="Admission + documentation stalled")
add(c, "Pharmacy cannot see patient records and the medication system is not responding, so dispensing has stopped.", MM, NU, CH, DE, "P1", ESC, why="Pharmacy + patient records")
add(c, "Several hospital departments report that logins, email and the records system have all stopped working since the network change.", NET, DR, A7, HW, "P1", ESC, why="Multiple departments, network cause")
add(c, "Lab analysers cannot send results and the orders from wards are not arriving; the whole laboratory is affected.", LIS, LAB, CH, DE, "P2", ESC, why="LIS bidirectional failure, department")
add(c, "PACS and the radiology request system are both unavailable for the department.", PACS, RAD, CH, DE, "P2", ESC, why="Two radiology systems down, department")
add(c, "Sign-in and the staff portal both fail for admin offices, printing is also affected.", ID, AD, BH, DE, "P2", ESC, why="Admin department-wide; no clinical impact but department scale")
add(c, "Email and the staff portal are slow for one admin office.", EM, AD, BH, SU, "P4", ACC, why="Low-impact multi-system, single office")
add(c, "Printing and scanning both fail on one floor, only one person has reported it.", PR, AD, BH, SU, "P4", ACC, why="Low-impact multi-system")
add(c, "Nurse call and bed management screens are both blank in the emergency department.", NC, ED, A7, DE, "P1", ESC, why="Two safety systems blank in ED")
add(c, "Orders from EHR are not reaching laboratory or radiology for emergency patients.", EHR, ED, A7, HW, "P1", ESC, why="Order flow broken for ED")
add(c, "A handful of systems feel slow for one nurse today: portal, email and the records screen.", EHR, NU, BH, SU, "P3", ACC, why="Low-impact vague slowness, single user")

# ------------------------------------------------- G. adversarial / obfuscated
c = "adversarial"
# consistent fields: high-impact meaning without the usual keywords
add(c, "The problem is preventing clinicians across several departments from completing normal patient-care workflows.", EHR, DR, CH, HW, "P1", ESC, why="No outage words; fields consistent high impact")
add(c, "Staff have reverted to handwritten lists because the usual screen for evening treatments cannot be reached.", MM, ICU, A7, DE, "P1", ESC, why="Paper fallback; fields consistent high impact")
add(c, "It has gone very quiet at the nursing station and rooms are being checked on foot.", NC, NU, A7, DE, "P1", ESC, why="Silence implies alerts not arriving; fields consistent")
add(c, "Teams in emergency care are making decisions without the information they normally see on screen.", EHR, ED, A7, DE, "P1", ESC, why="Information unavailable; fields consistent")
add(c, "Reports for time-critical scans are being delayed because the usual viewer is not usable.", PACS, ED, A7, DE, "P1", ESC, why="Time-critical imaging; fields consistent")
add(c, "Specimens are being walked to the lab by hand because requests are not reaching it.", LIS, ICU, A7, DE, "P1", ESC, conf="borderline", why="LIS for ICU: P1/P2 borderline")
# obfuscated high-impact + low-impact structured fields (hard conflicts)
add(c, "Colleagues on three wards have stopped trusting the screen that shows which patients are due their evening treatments and are using handwritten lists.", SP, NU, BH, SU, "P1", REV, "text_high_fields_low", "borderline", "Obfuscated medication-safety issue, mis-filed as single-user portal")
add(c, "The thing that tells us when a patient needs help has been silent all morning, rooms are being checked by hand.", SP, AD, BH, SU, "P1", REV, "text_high_fields_low", "borderline", "Nurse-call failure described without keywords; mis-filed")
add(c, "Several departments cannot do their normal patient-care work and are waiting on IT.", PR, AD, SC, SU, "P1", REV, "text_high_fields_low", "borderline", "Broad patient-care impact; fields say printing/single user")
add(c, "Surgeons are delaying the start of lists because they cannot see the information they need.", EM, AD, BH, SU, "P1", REV, "text_high_fields_low", "borderline", "Operational impact on theatres; fields say email/single user")
# obfuscated but low impact (guard against over-sensitivity)
add(c, "The tool I use for my weekly report has moved a button and I cannot find it.", SP, AD, BH, SU, "P4", ACC, why="Obfuscation-looking but trivial")
add(c, "Everything feels a bit slow for me today but nothing is blocked.", SP, AD, BH, SU, "P4", ACC, why="Vague but low impact")
add(c, "My colleague says the lights on the meeting-room display are flickering.", PR, AD, SC, SU, "P4", ACC, why="Irrelevant facility issue")

# --------------------------------------------- H. misleading structured fields
c = "misleading_metadata"
# text high, fields low (keyword-style)
add(c, "EHR is completely down and ICU clinicians cannot access any patient charts.", PR, AD, SC, SU, "P1", REV, "text_high_fields_low", "borderline", "Mis-filed critical EHR outage")
add(c, "Medication system unavailable on ICU, nurses cannot confirm doses.", EM, AD, BH, SU, "P1", REV, "text_high_fields_low", "borderline", "Mis-filed critical medication outage")
add(c, "Nurse call alerts are not reaching the station on Ward 7.", SP, AD, BH, SU, "P1", REV, "text_high_fields_low", "borderline", "Mis-filed nurse call failure")
add(c, "Hospital-wide network outage, all wards offline.", PR, AD, BH, SU, "P1", REV, "text_high_fields_low", "borderline", "Mis-filed site outage")
add(c, "Emergency department cannot open any imaging for trauma patients.", EM, AD, BH, SU, "P1", REV, "text_high_fields_low", "borderline", "Mis-filed ED imaging outage")
add(c, "Laboratory Information System is down for the entire laboratory.", SP, AD, BH, SU, "P2", REV, "text_high_fields_low", "borderline", "Mis-filed LIS department outage")
add(c, "ICU nurses cannot log in, multiple users locked out of every clinical system.", PR, IT, SC, SU, "P1", REV, "text_high_fields_low", "borderline", "Mis-filed ICU login failure")
# text low, fields high (reverse direction): never silently downgraded
add(c, "Please change my desktop wallpaper.", EHR, ICU, A7, HW, "P4", ESC, "text_low_fields_high", "borderline", "Trivial text but fields claim critical; must not be accepted")
add(c, "One user needs a password reset.", NC, NU, A7, HW, "P4", ESC, "text_low_fields_high", "borderline", "Trivial text, critical fields")
add(c, "Need email signature updated.", MM, ICU, A7, DE, "P4", ESC, "text_low_fields_high", "borderline", "Trivial text, critical fields")
add(c, "EHR is slightly slow for one nurse.", EHR, ICU, A7, HW, "P3", ESC, "text_low_fields_high", "borderline", "Mild text, high fields")
# consistent controls
add(c, "Printer jammed again.", PR, AD, BH, SU, "P4", ACC, why="Consistent low impact control")
add(c, "Hospital-wide EHR outage, ICU and ED cannot reach charts.", EHR, ICU, A7, HW, "P1", ESC, why="Consistent high impact control")

# ------------------------------------------------------- I. mixed signals
c = "mixed_signals"
# severe text + low structured impact (not matching simple keyword+context pattern)
add(c, "Patients may be at risk because staff cannot get their medication lists.", SP, NU, BH, SU, "P1", REV, "text_high_fields_low", "borderline", "Severe text, low structured impact")
add(c, "Critical care staff are working blind, nobody can see results.", EM, AD, BH, SU, "P1", REV, "text_high_fields_low", "borderline", "Severe text, low structured impact")
add(c, "This has been stopping ward rounds for the whole floor since seven.", PR, AD, SC, SU, "P2", REV, "text_high_fields_low", "borderline", "Broad impact text, low fields")
# mild text + high structured impact
add(c, "Small cosmetic glitch with a menu label.", EHR, ED, A7, HW, "P4", ESC, "text_low_fields_high", "borderline", "Mild text, critical fields")
add(c, "Request to move a user to a different group.", NC, NU, A7, DE, "P4", ESC, "text_low_fields_high", "borderline", "Mild text, critical fields")
add(c, "Routine query about a licence.", MM, ICU, A7, DE, "P4", ESC, "text_low_fields_high", "borderline", "Mild text, critical fields")
# ambiguous text + conflicting metadata
add(c, "Something is not right with the system, people are complaining.", EHR, AD, BH, SU, "P3", ESC, "ambiguous", "borderline", "Vague text; EHR service but single admin user")
add(c, "Please look into it as soon as possible.", NC, NU, BH, SU, "P3", ESC, "ambiguous", "borderline", "No content; nurse-call service but single user")
add(c, "Not sure what is happening, a few people mentioned it.", ID, NU, BH, MU, "P3", ESC, "ambiguous", "borderline", "Vague text; moderate fields")
add(c, "Follow-up on previous ticket.", SP, AD, BH, SU, "P4", ACC, "ambiguous", "borderline", "No content, low fields")
add(c, "Urgent please!!", PR, AD, BH, SU, "P4", ACC, "ambiguous", "borderline", "Alarmist but no content; printing single user")
add(c, "Staff are asking about it.", EM, AD, SC, SU, "P4", ACC, "ambiguous", "borderline", "No content, low fields")

with OUT.open("w", newline="", encoding="utf-8") as f:
    w = csv.writer(f)
    w.writerow(["case_id", "category", "ticket_content", "affected_service", "user_group",
                "operating_schedule", "scope", "expected_priority", "label_confidence",
                "rationale", "expected_handling", "conflict_type"])
    for i, r in enumerate(rows, 1):
        w.writerow([f"X{i:03d}"] + r)

if __name__ == "__main__":
    import collections
    print(len(rows), "cases written to", OUT.name)
    print(collections.Counter(r[0] for r in rows))
    print(collections.Counter(r[9] for r in rows))
    print(collections.Counter(r[10] for r in rows))

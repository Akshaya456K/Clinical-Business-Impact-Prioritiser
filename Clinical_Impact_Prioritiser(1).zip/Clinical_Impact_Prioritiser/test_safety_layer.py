"""
Safety-layer tests: confidence thresholds, P2 rule, evidence rule, text-vs-field
conflicts (keyword + learned), human review routing, no-downgrade guarantees,
fail-safe behaviour and decision_engine integration.

Run:  python -m unittest test_safety_layer -v
"""
import contextlib
import io
import unittest

import safety
from safety import (
    HIGH_CONFIDENCE_THRESHOLD,
    LOW_CONFIDENCE_THRESHOLD,
    evaluate_prediction,
    find_learned_conflict,
    find_text_field_conflict,
    validate_and_decide,
    validate_ticket,
)

with contextlib.redirect_stdout(io.StringIO()):
    from decision_engine import process_ticket

EVIDENCE3 = ["service", "users", "scope"]


def ticket(text="Routine request", service="Printing", group="Administrative Staff",
           schedule="Business Hours", scope="Single User"):
    return {"ticket_content": text, "affected_service": service, "user_group": group,
            "operating_schedule": schedule, "scope": scope}


def pred(priority, confidence, evidence=EVIDENCE3):
    return {"predicted_priority": priority, "confidence": confidence, "evidence": evidence}


LOW_FIELDS = dict(service="Printing", group="Administrative Staff",
                  schedule="Scheduled/Non-Critical", scope="Single User")
HIGH_FIELDS = dict(service="EHR", group="ICU Clinicians", schedule="24/7", scope="Hospital-wide")


class TestThresholdsUnchanged(unittest.TestCase):

    def test_thresholds_are_the_original_values(self):
        self.assertEqual(LOW_CONFIDENCE_THRESHOLD, 0.60)
        self.assertEqual(HIGH_CONFIDENCE_THRESHOLD, 0.80)

    def test_signal_thresholds_shared_with_training_script(self):
        import train_signal_models as t
        self.assertEqual(safety.TEXT_HIGH_THRESHOLD, t.TEXT_HIGH_THRESHOLD)
        self.assertEqual(safety.STRUCT_LOW_THRESHOLD, t.STRUCT_LOW_THRESHOLD)


class TestConfidenceRouting(unittest.TestCase):

    def test_low_confidence_any_priority_goes_to_human_review(self):
        for pr in ("P1", "P2", "P3", "P4"):
            d = evaluate_prediction(pr, 0.59, EVIDENCE3)
            self.assertEqual(d["action"], "HUMAN_REVIEW", pr)
            self.assertIn("below 60%", d["reason"])

    def test_confidence_exactly_at_low_threshold_is_not_low(self):
        self.assertNotEqual(evaluate_prediction("P3", 0.60, EVIDENCE3)["action"] , "HUMAN_REVIEW")

    def test_p2_below_high_threshold_goes_to_human_review(self):
        d = evaluate_prediction("P2", 0.79, EVIDENCE3)
        self.assertEqual(d["action"], "HUMAN_REVIEW")
        self.assertIn("80%", d["reason"])

    def test_p2_at_or_above_threshold_is_priority_escalation(self):
        for c in (0.80, 0.95):
            self.assertEqual(evaluate_prediction("P2", c, EVIDENCE3)["action"], "PRIORITY_ESCALATION")

    def test_p1_with_evidence_is_urgent_escalation_even_below_80(self):
        self.assertEqual(evaluate_prediction("P1", 0.65, EVIDENCE3)["action"], "URGENT_ESCALATION")

    def test_high_impact_with_thin_evidence_goes_to_human_review(self):
        for pr in ("P1", "P2"):
            for ev in ([], None, ["only", "two"]):
                d = evaluate_prediction(pr, 0.95, ev)
                self.assertEqual(d["action"], "HUMAN_REVIEW", (pr, ev))

    def test_p3_p4_confident_are_accepted(self):
        for pr in ("P3", "P4"):
            self.assertEqual(evaluate_prediction(pr, 0.85, EVIDENCE3)["action"], "ACCEPT")


class TestValidationAndFallback(unittest.TestCase):

    def test_missing_and_blank_fields_are_reported(self):
        errs = validate_ticket({"ticket_content": "  ", "affected_service": None})
        self.assertTrue(any("ticket_content" in e for e in errs))
        self.assertTrue(any("affected_service" in e for e in errs))
        self.assertTrue(any("scope" in e for e in errs))

    def test_invalid_ticket_routes_to_human_review_with_flags_key(self):
        d = validate_and_decide({"ticket_content": "x"}, pred("P1", 99))
        self.assertEqual(d["action"], "HUMAN_REVIEW")
        self.assertFalse(d["safe"])
        self.assertEqual(d["flags"], [])

    def test_engine_fallback_on_incomplete_ticket(self):
        r = process_ticket({"ticket_content": "EHR down"})
        self.assertEqual((r["status"], r["action"]), ("FALLBACK", "HUMAN_REVIEW"))
        self.assertIsNone(r["predicted_priority"])


class TestKeywordConflict(unittest.TestCase):

    def test_critical_text_low_fields_is_flagged(self):
        t = ticket("EHR completely down, ICU clinicians cannot access any patient charts", **LOW_FIELDS)
        self.assertIsNotNone(find_text_field_conflict(t))

    def test_consistent_high_impact_is_not_a_conflict(self):
        t = ticket("EHR completely down, ICU clinicians cannot access any patient charts", **HIGH_FIELDS)
        self.assertIsNone(find_text_field_conflict(t))

    def test_alarmist_words_without_clinical_context_are_not_enough(self):
        for text in ("CRITICAL URGENT DOWN: email signature has the wrong font",
                     "Catastrophic emergency!!! My printer is out of paper",
                     "Terrible outage! Could someone add me to the book club mailing list"):
            self.assertIsNone(find_text_field_conflict(ticket(text, **LOW_FIELDS)), text)

    def test_word_boundaries_do_not_match_inside_other_words(self):
        # 'down' must not match 'download'; 'icu' must not match 'public'
        self.assertIsNone(find_text_field_conflict(
            ticket("Please download the public holiday rota", **LOW_FIELDS)))


class TestDecisionIntegration(unittest.TestCase):
    """Behaviour through validate_and_decide / process_ticket."""

    def test_conflict_overrides_accept_with_human_review(self):
        t = ticket("EHR completely down, ICU clinicians cannot access any patient charts", **LOW_FIELDS)
        d = validate_and_decide(t, pred("P4", 99.5))
        self.assertEqual(d["action"], "HUMAN_REVIEW")
        self.assertFalse(d["safe"])
        self.assertIn(safety.FLAG_KEYWORD_CONFLICT, d["flags"])
        self.assertIn("structured fields indicate low impact", d["reason"])

    def test_learned_signal_catches_conflict_without_listed_keywords(self):
        t = ticket("Nurse call alerts are not reaching the station on Ward 7.",
                   service="Staff Portal", group="Administrative Staff", schedule="Business Hours",
                   scope="Single User")
        self.assertIsNone(find_text_field_conflict(t))      # keyword rule misses it
        self.assertIsNotNone(find_learned_conflict(t))      # learned signal does not
        d = validate_and_decide(t, pred("P4", 97))
        self.assertEqual(d["action"], "HUMAN_REVIEW")
        self.assertIn(safety.FLAG_LEARNED_CONFLICT, d["flags"])

    def test_normal_low_impact_ticket_is_still_accepted(self):
        t = ticket("Requesting installation of Microsoft Office on a new workstation.", **LOW_FIELDS)
        d = validate_and_decide(t, pred("P4", 99))
        self.assertEqual(d["action"], "ACCEPT")
        self.assertTrue(d["safe"])
        self.assertEqual(d["flags"], [])

    def test_alarmist_trivial_ticket_is_still_accepted(self):
        t = ticket("CRITICAL URGENT DOWN: email signature has the wrong font",
                   service="Email", group="Administrative Staff", schedule="Business Hours",
                   scope="Single User")
        self.assertEqual(validate_and_decide(t, pred("P4", 91))["action"], "ACCEPT")

    def test_consistent_high_impact_keeps_existing_decision(self):
        t = ticket("EHR system completely unavailable. ICU clinicians cannot access patient records.",
                   **HIGH_FIELDS)
        d = validate_and_decide(t, pred("P1", 99.9))
        self.assertEqual(d["action"], "URGENT_ESCALATION")

    def test_escalations_are_never_downgraded_by_the_new_checks(self):
        # trivial text but critical fields: stays escalated (no downgrade)
        t = ticket("Please change my desktop wallpaper.", **HIGH_FIELDS)
        for pr, conf, expected in (("P1", 99.9, "URGENT_ESCALATION"), ("P2", 95, "PRIORITY_ESCALATION")):
            self.assertEqual(validate_and_decide(t, pred(pr, conf))["action"], expected)

    def test_low_confidence_still_wins_and_flags_stay_empty(self):
        t = ticket("EHR completely down, ICU clinicians cannot access charts", **LOW_FIELDS)
        d = validate_and_decide(t, pred("P4", 40))
        self.assertEqual(d["action"], "HUMAN_REVIEW")
        self.assertIn("below 60%", d["reason"])
        self.assertEqual(d["flags"], [])

    def test_reverse_warning_is_disabled_by_default(self):
        self.assertFalse(safety.ENABLE_TEXT_LOW_FIELDS_HIGH_WARNING)
        t = ticket("Please change my desktop wallpaper.", **HIGH_FIELDS)
        self.assertEqual(validate_and_decide(t, pred("P1", 99.9))["flags"], [])

    def test_engine_end_to_end_conflict(self):
        r = process_ticket(ticket(
            "EHR completely down, ICU clinicians cannot access any patient charts", **LOW_FIELDS))
        self.assertEqual((r["status"], r["action"]), ("SUCCESS", "HUMAN_REVIEW"))
        self.assertIn("TEXT_FIELD_CONFLICT_KEYWORD", r["safety_flags"])

    def test_engine_end_to_end_consistent_high_impact(self):
        r = process_ticket(ticket(
            "EHR system completely unavailable. ICU clinicians cannot access patient records. "
            "Multiple users affected.", **HIGH_FIELDS))
        self.assertEqual((r["predicted_priority"], r["action"]), ("P1", "URGENT_ESCALATION"))
        self.assertEqual(r["safety_flags"], [])

    def test_engine_output_keys_are_stable(self):
        r = process_ticket(ticket(**LOW_FIELDS))
        self.assertEqual(sorted(r), ["action", "confidence", "confidence_type", "errors", "evidence",
                                     "predicted_priority", "probabilities", "reason",
                                     "safety_flags", "status"])
        self.assertIn(r["confidence_type"], ("raw", "calibrated"))


class TestFailSafe(unittest.TestCase):

    def setUp(self):
        self._saved = dict(safety._signal_models_cache)

    def tearDown(self):
        safety._signal_models_cache.clear()
        safety._signal_models_cache.update(self._saved)

    def test_missing_signal_models_keep_keyword_rule_and_flag_unavailability(self):
        safety._signal_models_cache["models"] = None
        conflict = ticket("EHR completely down, ICU clinicians cannot access any patient charts", **LOW_FIELDS)
        d = validate_and_decide(conflict, pred("P4", 99))
        self.assertEqual(d["action"], "HUMAN_REVIEW")                       # keyword rule still active
        routine = validate_and_decide(ticket("Printer jammed again", **LOW_FIELDS), pred("P4", 99))
        self.assertEqual(routine["action"], "ACCEPT")                      # no crash, no over-blocking
        self.assertIn(safety.FLAG_SIGNAL_UNAVAILABLE, routine["flags"])

    def test_signal_probabilities_none_when_models_unavailable(self):
        safety._signal_models_cache["models"] = None
        self.assertIsNone(safety.get_signal_probabilities(ticket(**LOW_FIELDS)))

    def test_non_string_ticket_text_does_not_crash(self):
        t = ticket(**LOW_FIELDS)
        t["ticket_content"] = 12345
        self.assertEqual(validate_and_decide(t, pred("P4", 99))["action"], "ACCEPT")


if __name__ == "__main__":
    unittest.main(verbosity=2)

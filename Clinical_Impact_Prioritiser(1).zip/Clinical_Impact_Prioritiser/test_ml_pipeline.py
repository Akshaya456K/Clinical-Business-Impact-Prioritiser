"""
ML pipeline tests: preprocessing, training reproducibility, prediction,
confidence, calibration utilities and data-leakage guards.

Run:  python -m unittest test_ml_pipeline -v
"""
import contextlib
import io
import json
import unittest
import warnings
from pathlib import Path

import joblib
import numpy as np
import pandas as pd
from sklearn.model_selection import train_test_split

import calibrate_model as cal
from env_check import check_sklearn_version

with contextlib.redirect_stdout(io.StringIO()):
    import predict

BASE = Path(__file__).resolve().parent
FEATURES = ["ticket_content", "affected_service", "user_group", "operating_schedule", "scope"]
LABELS = ["P1", "P2", "P3", "P4"]
SAMPLE = {
    "ticket_content": "EHR system completely unavailable. ICU clinicians cannot access patient records.",
    "affected_service": "EHR", "user_group": "ICU Clinicians",
    "operating_schedule": "24/7", "scope": "Hospital-wide",
}


class TestDataAndSplit(unittest.TestCase):

    @classmethod
    def setUpClass(cls):
        cls.df = pd.read_csv(BASE / "hospital_it_tickets.csv")

    def test_dataset_schema_and_classes(self):
        self.assertTrue(set(FEATURES + ["priority"]) <= set(self.df.columns))
        self.assertEqual(sorted(self.df["priority"].unique()), LABELS)
        self.assertEqual(len(self.df), 2000)
        self.assertFalse(self.df[FEATURES].isna().any().any())

    def test_split_is_reproducible_and_stratified(self):
        a = train_test_split(self.df[FEATURES], self.df["priority"], test_size=0.2,
                             random_state=42, stratify=self.df["priority"])
        b = train_test_split(self.df[FEATURES], self.df["priority"], test_size=0.2,
                             random_state=42, stratify=self.df["priority"])
        self.assertTrue(a[1].index.equals(b[1].index))
        self.assertEqual(len(a[1]), 400)
        self.assertEqual(a[3].value_counts().to_dict(), {"P4": 160, "P3": 120, "P2": 80, "P1": 40})

    def test_calibration_script_uses_the_same_split_as_training(self):
        _, X_test, _, _ = train_test_split(self.df[FEATURES], self.df["priority"], test_size=0.2,
                                           random_state=42, stratify=self.df["priority"])
        self.assertEqual(cal.RANDOM_STATE, 42)
        self.assertEqual(cal.FEATURES, FEATURES)
        self.assertEqual(len(X_test), 400)

    def test_robustness_cases_do_not_overlap_training_text(self):
        norm = lambda s: " ".join(str(s).lower().split())
        train_text = {norm(t) for t in self.df["ticket_content"]}
        for name in ("robustness_test_cases.csv", "robustness_extended_cases.csv"):
            rob = pd.read_csv(BASE / "robustness" / name)
            overlap = {norm(t) for t in rob["ticket_content"]} & train_text
            self.assertEqual(overlap, set(), name)

    def test_robustness_files_never_referenced_by_training_scripts(self):
        """Training/calibration code must not load the robustness case files."""
        for script in ("train_model.py", "train_signal_models.py"):
            code = (BASE / script).read_text()
            for ref in ("robustness_test_cases", "robustness_extended_cases", "robustness/"):
                self.assertNotIn(ref, code, f"{script} references {ref}")

    def test_calibration_uses_robustness_data_only_for_reporting(self):
        """calibrate_model.py may read the cases, but only after fitting (reporting section)."""
        code = (BASE / "calibrate_model.py").read_text()
        fit_end = code.index("# 3. one-time reporting")
        self.assertNotIn("ROBUST_PATH", code[:fit_end].split("def main")[1])
        self.assertNotIn("ROBUST_EXT_PATH", code[:fit_end].split("def main")[1])


class TestPipelineStructure(unittest.TestCase):

    @classmethod
    def setUpClass(cls):
        cls.model = joblib.load(BASE / "models" / "priority_model.joblib")

    def test_pipeline_steps_and_preprocessing(self):
        self.assertEqual([n for n, _ in self.model.steps], ["preprocessor", "model"])
        pre = self.model.named_steps["preprocessor"]
        names = {n: t.__class__.__name__ for n, t, _ in pre.transformers_}
        self.assertEqual(names["text"], "TfidfVectorizer")
        self.assertEqual(names["categorical"], "OneHotEncoder")
        self.assertEqual(self.model.named_steps["model"].__class__.__name__, "LogisticRegression")

    def test_classes_order(self):
        self.assertEqual(list(self.model.classes_), LABELS)

    def test_unseen_categories_do_not_crash(self):
        t = dict(SAMPLE, affected_service="Telepathy Portal", user_group="Visitors")
        p = self.model.predict_proba(pd.DataFrame([t]))[0]
        self.assertAlmostEqual(p.sum(), 1.0, places=6)

    def test_model_loads_without_version_warning(self):
        # Deterministic: first verify the declared scikit-learn version is the
        # one installed (clear, actionable failure otherwise), then load with
        # all warnings promoted to errors. Warnings are NOT suppressed.
        check_sklearn_version()
        with warnings.catch_warnings():
            warnings.simplefilter("error")
            joblib.load(BASE / "models" / "priority_model.joblib")


class TestPrediction(unittest.TestCase):

    def test_output_keys_and_types(self):
        r = predict.prioritise_ticket(SAMPLE)
        self.assertEqual(sorted(r), ["confidence", "confidence_type", "evidence",
                                     "predicted_priority", "probabilities"])
        self.assertIn(r["predicted_priority"], LABELS)
        self.assertEqual(sorted(r["probabilities"]), LABELS)
        self.assertIsInstance(r["evidence"], list)

    def test_probabilities_sum_to_100_and_confidence_is_the_predicted_class_probability(self):
        r = predict.prioritise_ticket(SAMPLE)
        self.assertAlmostEqual(sum(r["probabilities"].values()), 100.0, delta=0.1)
        self.assertEqual(r["confidence"], r["probabilities"][r["predicted_priority"]])
        self.assertEqual(r["confidence"], max(r["probabilities"].values()))

    def test_prediction_is_deterministic_including_evidence_order(self):
        a, b = predict.prioritise_ticket(SAMPLE), predict.prioritise_ticket(dict(SAMPLE))
        self.assertEqual(a, b)

    def test_confidence_type_matches_loaded_model(self):
        expected = "calibrated" if predict.MODEL_SOURCE == "calibrated" else "raw"
        self.assertEqual(predict.prioritise_ticket(SAMPLE)["confidence_type"], expected)

    def test_known_examples(self):
        self.assertEqual(predict.prioritise_ticket(SAMPLE)["predicted_priority"], "P1")
        low = dict(ticket_content="Requesting installation of Microsoft Office on a new workstation.",
                   affected_service="Staff Portal", user_group="IT Staff",
                   operating_schedule="Scheduled/Non-Critical", scope="Single User")
        self.assertEqual(predict.prioritise_ticket(low)["predicted_priority"], "P4")

    def test_evidence_is_deterministic_across_processes_and_hash_seeds(self):
        """A set-based implementation is stable inside one process but changes
        between processes (hash randomisation), so compare separate runs."""
        import os
        import subprocess
        import sys
        code = ("from explanation import find_matching_keywords as f;"
                "print(f('Multiple users cannot access the system, outage is urgent, unable to log in'))")
        outputs = set()
        for seed in ("1", "2", "3", "4", "5"):
            env = dict(os.environ, PYTHONHASHSEED=seed)
            outputs.add(subprocess.run([sys.executable, "-c", code], cwd=BASE, env=env,
                                       capture_output=True, text=True, check=True).stdout)
        self.assertEqual(len(outputs), 1, outputs)

    def test_falls_back_to_original_model_when_calibrated_file_is_corrupt(self):
        import tempfile
        with tempfile.TemporaryDirectory() as d:
            bad = Path(d) / "x.joblib"
            bad.write_text("not a model")
            old = predict.CALIBRATED_MODEL_PATH
            predict.CALIBRATED_MODEL_PATH = bad
            try:
                with contextlib.redirect_stdout(io.StringIO()):
                    model, source = predict._load_model()
            finally:
                predict.CALIBRATED_MODEL_PATH = old
            self.assertEqual(source, "original")
            self.assertEqual(list(model.classes_), LABELS)


class TestCalibrationUtilities(unittest.TestCase):

    def test_multiclass_brier_known_values(self):
        y = np.array(["P1", "P2"])
        perfect = np.array([[1, 0, 0, 0], [0, 1, 0, 0]], dtype=float)
        worst = np.array([[0, 1, 0, 0], [1, 0, 0, 0]], dtype=float)
        self.assertAlmostEqual(cal.multiclass_brier(y, perfect, LABELS), 0.0)
        self.assertAlmostEqual(cal.multiclass_brier(y, worst, LABELS), 2.0)
        uniform = np.full((2, 4), 0.25)
        self.assertAlmostEqual(cal.multiclass_brier(y, uniform, LABELS), 0.75)

    def test_ece_zero_when_confidence_equals_accuracy(self):
        # 10 predictions at 80% confidence, 8 correct
        proba = np.tile([0.8, 0.1, 0.05, 0.05], (10, 1))
        y = np.array(["P1"] * 8 + ["P2"] * 2)
        _, ece = cal.reliability(y, proba, LABELS)
        self.assertAlmostEqual(ece, 0.0, places=6)

    def test_ece_detects_overconfidence(self):
        proba = np.tile([0.99, 0.0033, 0.0033, 0.0034], (10, 1))
        y = np.array(["P1"] * 5 + ["P2"] * 5)
        _, ece = cal.reliability(y, proba, LABELS)
        self.assertAlmostEqual(ece, 0.49, places=2)

    def test_summarise_reports_required_metrics(self):
        proba = np.tile([0.7, 0.2, 0.05, 0.05], (4, 1))
        s = cal.summarise(np.array(["P1", "P1", "P2", "P3"]), proba, LABELS)
        for k in ("accuracy", "macro_precision", "macro_recall", "macro_f1", "high_impact_precision",
                  "high_impact_recall", "high_impact_f1", "log_loss", "brier", "ece"):
            self.assertIn(k, s)
        self.assertAlmostEqual(s["accuracy"], 0.5)

    def test_adoption_rule_rejects_better_log_loss_with_worse_brier(self):
        base = dict(accuracy=0.99, high_impact_recall=0.99, log_loss=0.05, brier=0.01, ece=0.04)
        cand = dict(base, log_loss=0.02, brier=0.011, ece=0.01)
        ok, checks = cal.adoption_decision({"raw": base, "isotonic": cand}, "isotonic")
        self.assertFalse(ok)
        self.assertFalse(checks["brier_not_higher"])

    def test_adoption_rule_accepts_clear_improvement(self):
        base = dict(accuracy=0.99, high_impact_recall=0.99, log_loss=0.05, brier=0.01, ece=0.04)
        cand = dict(base, log_loss=0.02, brier=0.009, ece=0.01)
        self.assertTrue(cal.adoption_decision({"raw": base, "sigmoid": cand}, "sigmoid")[0])

    def test_adoption_rule_rejects_loss_of_high_impact_recall(self):
        base = dict(accuracy=0.99, high_impact_recall=0.99, log_loss=0.05, brier=0.01, ece=0.04)
        cand = dict(base, log_loss=0.02, brier=0.009, ece=0.01, high_impact_recall=0.97)
        self.assertFalse(cal.adoption_decision({"raw": base, "sigmoid": cand}, "sigmoid")[0])

    def test_calibration_report_lists_all_candidates_and_current_decision(self):
        r = json.loads((BASE / "reports" / "calibration_report.json").read_text())
        self.assertEqual(r["method_candidates"], ["raw", "sigmoid", "isotonic"])
        for ds in ("heldout_test_synthetic", "robustness_cases"):
            self.assertEqual(sorted(r[ds]["candidates"]), ["isotonic", "raw", "sigmoid"])
        self.assertEqual(r["thresholds_unchanged"],
                         {"LOW_CONFIDENCE_THRESHOLD": 0.6, "HIGH_CONFIDENCE_THRESHOLD": 0.8})
        # consistent with what predict.py actually loaded
        self.assertEqual(r["calibrated_model_adopted"], predict.MODEL_SOURCE == "calibrated")

    def test_calibrated_pipeline_preserves_class_order_and_probability_mass(self):
        from sklearn.calibration import CalibratedClassifierCV
        df = pd.read_csv(BASE / "hospital_it_tickets.csv").sample(300, random_state=0)
        with warnings.catch_warnings():
            warnings.simplefilter("ignore")
            m = CalibratedClassifierCV(cal.build_base_pipeline(), method="sigmoid", cv=3)
            m.fit(df[FEATURES], df["priority"])
        self.assertEqual(list(m.classes_), LABELS)
        p = m.predict_proba(pd.DataFrame([SAMPLE]))
        self.assertAlmostEqual(float(p.sum()), 1.0, places=6)


class TestSignalModels(unittest.TestCase):

    def test_signal_models_exist_and_use_expected_inputs(self):
        t = joblib.load(BASE / "models" / "signal_text_model.joblib")
        s = joblib.load(BASE / "models" / "signal_structured_model.joblib")
        self.assertEqual(list(t.classes_), LABELS)
        self.assertEqual(list(s.classes_), LABELS)
        self.assertEqual(t.named_steps["tfidf"].__class__.__name__, "TfidfVectorizer")
        self.assertEqual(s.named_steps["encoder"].__class__.__name__, "OneHotEncoder")

    def test_signal_report_documents_split_and_false_alarm_rate(self):
        r = json.loads((BASE / "reports" / "signal_models_report.json").read_text())
        self.assertIn("random_state=42", r["split"])
        self.assertEqual(r["out_of_fold_all_tickets"]["false_alarms_on_low_impact"], 0)


if __name__ == "__main__":
    unittest.main(verbosity=2)

"""
Schema-contract and state-recovery tests for TicketEventProcessor.

Complements test_event_processor.py (which is left unchanged).
Each test checks BOTH the returned result/status AND the ticket
state afterwards.

Run with either:
    python -m unittest test_event_contracts -v
    python test_event_contracts.py
    pytest test_event_contracts.py        (if pytest is installed)
"""

import copy
import unittest
from datetime import datetime

from event_processor import (
    INVALID_EVENT_STATUS,
    TicketEventProcessor,
    validate_event,
)

REMOVE = object()


def make_event(**overrides):
    """Build a valid event, then apply overrides (REMOVE deletes a field)."""
    event = {
        "event_id": "E001",
        "ticket_id": "T1001",
        "event_type": "TICKET_CREATED",
        "event_timestamp": "2026-08-27T09:00:00",
        "event_version": 1,
        "data": {"priority": "P2"},
    }
    for key, value in overrides.items():
        if value is REMOVE:
            event.pop(key, None)
        else:
            event[key] = value
    return event


class EventTestBase(unittest.TestCase):

    def setUp(self):
        self.processor = TicketEventProcessor()

    def apply(self, event):
        return self.processor.process_event(event)

    def state(self, ticket_id="T1001"):
        return self.processor.get_ticket_state(ticket_id)

    def assert_rejected(self, event, expected_fragment=None):
        """Event rejected, no state written, id not marked processed."""
        before_state = copy.deepcopy(self.processor.ticket_state)
        before_processed = set(self.processor.processed_events)

        result = self.apply(event)

        self.assertEqual(result["status"], INVALID_EVENT_STATUS)
        self.assertTrue(result["errors"])
        self.assertIn("message", result)
        if expected_fragment:
            self.assertTrue(
                any(expected_fragment in e for e in result["errors"]),
                f"{expected_fragment!r} not in {result['errors']}",
            )
        self.assertEqual(self.processor.ticket_state, before_state)
        self.assertEqual(self.processor.processed_events, before_processed)
        self.assertEqual(self.processor.event_log[-1], result)
        return result


# ======================================================================
# 1. VALID PROCESSING AND ORDERING (existing behaviour must hold)
# ======================================================================

class TestValidProcessingAndOrdering(EventTestBase):

    def test_normal_event_creates_state(self):
        result = self.apply(make_event())

        self.assertEqual(result["status"], "APPLIED")
        self.assertEqual(result["ticket_id"], "T1001")
        self.assertEqual(result["event_id"], "E001")
        self.assertNotIn("errors", result)
        self.assertEqual(
            self.state(),
            {
                "latest_version": 1,
                "latest_timestamp": "2026-08-27T09:00:00",
                "event_type": "TICKET_CREATED",
                "data": {"priority": "P2"},
            },
        )

    def test_duplicate_event_ignored_state_unchanged(self):
        event = make_event()
        self.apply(event)
        snapshot = copy.deepcopy(self.state())

        result = self.apply(event)

        self.assertEqual(result["status"], "DUPLICATE_IGNORED")
        self.assertEqual(self.state(), snapshot)

    def test_duplicate_of_older_event_after_newer_is_still_duplicate(self):
        self.apply(make_event())
        self.apply(make_event(
            event_id="E002", event_version=2,
            event_type="PRIORITY_UPDATED", data={"priority": "P1"}))

        result = self.apply(make_event())  # E001 again

        self.assertEqual(result["status"], "DUPLICATE_IGNORED")
        self.assertEqual(self.state()["latest_version"], 2)
        self.assertEqual(self.state()["data"]["priority"], "P1")

    def test_newer_event_updates_state(self):
        self.apply(make_event())

        result = self.apply(make_event(
            event_id="E002", event_version=2,
            event_type="PRIORITY_UPDATED",
            event_timestamp="2026-08-27T09:05:00",
            data={"priority": "P1"}))

        self.assertEqual(result["status"], "APPLIED")
        self.assertEqual(self.state()["latest_version"], 2)
        self.assertEqual(self.state()["event_type"], "PRIORITY_UPDATED")
        self.assertEqual(self.state()["latest_timestamp"],
                         "2026-08-27T09:05:00")
        self.assertEqual(self.state()["data"]["priority"], "P1")

    def test_older_out_of_order_event_ignored(self):
        self.apply(make_event(event_id="E002", event_version=2,
                              data={"priority": "P1"}))

        result = self.apply(make_event(event_id="E003", event_version=1,
                                       data={"priority": "P3"}))

        self.assertEqual(result["status"], "OUT_OF_ORDER_IGNORED")
        self.assertEqual(self.state()["latest_version"], 2)
        self.assertEqual(self.state()["data"]["priority"], "P1")

    def test_delayed_event_between_versions_ignored(self):
        self.apply(make_event(event_id="E1", event_version=1,
                              data={"priority": "P3"}))
        self.apply(make_event(event_id="E3", event_version=3,
                              data={"priority": "P1"}))

        result = self.apply(make_event(event_id="E2", event_version=2,
                                       data={"priority": "P2"}))

        self.assertEqual(result["status"], "OUT_OF_ORDER_IGNORED")
        self.assertEqual(self.state()["latest_version"], 3)
        self.assertEqual(self.state()["data"]["priority"], "P1")

    def test_same_version_different_event_id_is_stale(self):
        self.apply(make_event(event_id="E1", event_version=2,
                              data={"priority": "P2"}))

        result = self.apply(make_event(event_id="E2", event_version=2,
                                       data={"priority": "P4"}))

        self.assertEqual(result["status"], "STALE_EVENT_IGNORED")
        self.assertEqual(self.state()["data"]["priority"], "P2")

    def test_version_gap_is_accepted(self):
        """v1 then v5 (v2-v4 lost) is applied; no hard sequencing."""
        self.apply(make_event(event_id="E1", event_version=1))

        result = self.apply(make_event(event_id="E5", event_version=5,
                                       data={"priority": "P1"}))

        self.assertEqual(result["status"], "APPLIED")
        self.assertEqual(self.state()["latest_version"], 5)

    def test_version_not_timestamp_is_authoritative(self):
        """Characterisation: ordering is by event_version only."""
        self.apply(make_event(event_id="E1", event_version=2,
                              event_timestamp="2026-08-27T09:00:00",
                              data={"priority": "P1"}))

        result = self.apply(make_event(
            event_id="E2", event_version=3,
            event_timestamp="2026-08-27T08:00:00",
            data={"priority": "P2"}))

        self.assertEqual(result["status"], "APPLIED")
        self.assertEqual(self.state()["latest_version"], 3)

    def test_latest_valid_event_stays_authoritative_after_bad_events(self):
        self.apply(make_event(event_id="E1", event_version=1,
                              data={"priority": "P3"}))
        self.apply(make_event(event_id="E2", event_version=2,
                              data={"priority": "P1"}))
        good_state = copy.deepcopy(self.state())

        self.apply(make_event(event_id="E3", event_version="9"))  # bad type
        self.apply(make_event(event_id=REMOVE))                  # missing id
        self.apply(make_event(event_id="E4", event_version=1))   # old
        self.apply(make_event(event_id="E2", event_version=9))   # duplicate id
        self.apply("not an event")                               # malformed
        self.apply(make_event(event_id="E5", event_version=2))   # stale

        self.assertEqual(self.state(), good_state)
        self.assertEqual(self.state()["data"]["priority"], "P1")

    def test_tickets_are_independent(self):
        self.apply(make_event(event_id="E1", ticket_id="A", event_version=3))
        self.apply(make_event(event_id="E2", ticket_id="B", event_version=1))

        self.assertEqual(self.state("A")["latest_version"], 3)
        self.assertEqual(self.state("B")["latest_version"], 1)

    def test_unknown_ticket_returns_none(self):
        self.assertIsNone(self.state("DOES-NOT-EXIST"))

    def test_data_is_optional(self):
        result = self.apply(make_event(data=REMOVE))

        self.assertEqual(result["status"], "APPLIED")
        self.assertEqual(self.state()["data"], {})

    def test_data_none_is_normalised_to_empty_dict(self):
        result = self.apply(make_event(data=None))

        self.assertEqual(result["status"], "APPLIED")
        self.assertEqual(self.state()["data"], {})

    def test_extra_unknown_fields_are_tolerated(self):
        self.assertEqual(
            self.apply(make_event(source_system="legacy-feed"))["status"],
            "APPLIED")

    def test_int_identifiers_are_accepted(self):
        result = self.apply(make_event(event_id=101, ticket_id=5001))

        self.assertEqual(result["status"], "APPLIED")
        self.assertEqual(self.state(5001)["latest_version"], 1)

    def test_datetime_timestamp_is_accepted(self):
        result = self.apply(
            make_event(event_timestamp=datetime(2026, 8, 27, 9, 0, 0)))

        self.assertEqual(result["status"], "APPLIED")

    def test_version_zero_is_accepted(self):
        self.assertEqual(self.apply(make_event(event_version=0))["status"],
                         "APPLIED")

    def test_utc_z_suffix_timestamp_is_accepted(self):
        self.assertEqual(
            self.apply(make_event(
                event_timestamp="2026-08-27T09:00:00Z"))["status"],
            "APPLIED")


# ======================================================================
# 2. SCHEMA CONTRACT: MISSING REQUIRED FIELDS
# ======================================================================

class TestMissingRequiredFields(EventTestBase):

    def test_missing_event_id(self):
        self.assert_rejected(make_event(event_id=REMOVE),
                             "Missing required field: event_id")
        self.assertIsNone(self.state())

    def test_missing_ticket_id(self):
        result = self.assert_rejected(make_event(ticket_id=REMOVE),
                                      "Missing required field: ticket_id")
        self.assertIsNone(result["ticket_id"])
        self.assertEqual(result["event_id"], "E001")

    def test_missing_event_type(self):
        self.assert_rejected(make_event(event_type=REMOVE),
                             "Missing required field: event_type")
        self.assertIsNone(self.state())

    def test_missing_event_timestamp(self):
        self.assert_rejected(make_event(event_timestamp=REMOVE),
                             "Missing required field: event_timestamp")
        self.assertIsNone(self.state())

    def test_missing_event_version(self):
        self.assert_rejected(make_event(event_version=REMOVE),
                             "Missing required field: event_version")
        self.assertIsNone(self.state())

    def test_all_fields_missing_reports_every_error(self):
        result = self.assert_rejected({})

        self.assertEqual(len(result["errors"]), 5)

    def test_missing_field_on_existing_ticket_does_not_touch_state(self):
        self.apply(make_event())
        snapshot = copy.deepcopy(self.state())

        self.assert_rejected(
            make_event(event_id="E2", event_version=REMOVE))

        self.assertEqual(self.state(), snapshot)


# ======================================================================
# 3. SCHEMA CONTRACT: INVALID VALUES AND TYPES
# ======================================================================

class TestInvalidValues(EventTestBase):

    def test_empty_event_id(self):
        self.assert_rejected(make_event(event_id=""),
                             "Empty required field: event_id")

    def test_whitespace_event_id(self):
        self.assert_rejected(make_event(event_id="   "),
                             "Empty required field: event_id")

    def test_empty_ticket_id(self):
        self.assert_rejected(make_event(ticket_id=""),
                             "Empty required field: ticket_id")

    def test_none_ids_rejected(self):
        self.assert_rejected(make_event(event_id=None), "event_id")
        self.assert_rejected(make_event(ticket_id=None), "ticket_id")

    def test_unhashable_id_rejected_without_crashing(self):
        self.assert_rejected(make_event(event_id=["E1"]), "event_id")
        self.assert_rejected(make_event(ticket_id={"x": 1}), "ticket_id")

    def test_bool_id_rejected(self):
        self.assert_rejected(make_event(event_id=True), "event_id")

    def test_event_version_string_rejected(self):
        self.assert_rejected(make_event(event_version="2"),
                             "Invalid event_version")

    def test_event_version_float_rejected(self):
        self.assert_rejected(make_event(event_version=1.5),
                             "Invalid event_version")

    def test_event_version_none_rejected(self):
        self.assert_rejected(make_event(event_version=None),
                             "Invalid event_version")

    def test_event_version_bool_rejected(self):
        self.assert_rejected(make_event(event_version=True),
                             "Invalid event_version")

    def test_event_version_negative_rejected(self):
        self.assert_rejected(make_event(event_version=-1),
                             "must not be negative")

    def test_empty_event_type(self):
        self.assert_rejected(make_event(event_type=""),
                             "Empty required field: event_type")

    def test_whitespace_event_type(self):
        self.assert_rejected(make_event(event_type="  "),
                             "Empty required field: event_type")

    def test_non_string_event_type(self):
        self.assert_rejected(make_event(event_type=42),
                             "Invalid event_type")

    def test_malformed_timestamp_string(self):
        self.assert_rejected(make_event(event_timestamp="yesterday-ish"),
                             "Invalid event_timestamp")

    def test_empty_timestamp(self):
        self.assert_rejected(make_event(event_timestamp=""),
                             "Invalid event_timestamp")

    def test_non_string_timestamp(self):
        self.assert_rejected(make_event(event_timestamp=1724749200),
                             "Invalid event_timestamp")

    def test_data_wrong_type(self):
        self.assert_rejected(make_event(data="priority=P1"), "Invalid data")
        self.assert_rejected(make_event(data=["P1"]), "Invalid data")

    def test_multiple_problems_all_reported(self):
        result = self.assert_rejected(
            make_event(event_id="", event_version="x",
                       event_timestamp="bad"))

        self.assertEqual(len(result["errors"]), 3)


# ======================================================================
# 4. MALFORMED EVENTS (NOT EVEN A DICT)
# ======================================================================

class TestMalformedEvents(EventTestBase):

    def test_none_event(self):
        result = self.assert_rejected(None)
        self.assertIsNone(result["ticket_id"])
        self.assertIsNone(result["event_id"])

    def test_string_event(self):
        self.assert_rejected("E001,T1001,TICKET_CREATED")

    def test_list_event(self):
        self.assert_rejected([make_event()])

    def test_int_event(self):
        self.assert_rejected(7)

    def test_empty_dict_event(self):
        self.assert_rejected({})

    def test_process_event_never_raises_on_garbage(self):
        for garbage in (None, 1, "x", [], {}, set(), 3.14, b"x",
                        {"event_id": []}, {"event_version": object()}):
            result = self.apply(garbage)
            self.assertEqual(result["status"], INVALID_EVENT_STATUS)


# ======================================================================
# 5. EVENT-TYPE WHITELIST (OPTIONAL)
# ======================================================================

class TestEventTypeWhitelist(unittest.TestCase):

    def test_default_accepts_any_non_empty_type(self):
        processor = TicketEventProcessor()

        result = processor.process_event(make_event(event_type="CUSTOM"))

        self.assertEqual(result["status"], "APPLIED")

    def test_whitelist_rejects_unknown_type(self):
        processor = TicketEventProcessor(
            allowed_event_types={"TICKET_CREATED", "PRIORITY_UPDATED"})

        result = processor.process_event(make_event(event_type="HACKED"))

        self.assertEqual(result["status"], INVALID_EVENT_STATUS)
        self.assertIn("Unsupported event_type: HACKED", result["errors"])
        self.assertIsNone(processor.get_ticket_state("T1001"))

    def test_whitelist_accepts_known_type(self):
        processor = TicketEventProcessor(
            allowed_event_types={"TICKET_CREATED"})

        self.assertEqual(
            processor.process_event(make_event())["status"], "APPLIED")


# ======================================================================
# 6. RECOVERY AFTER REJECTION
# ======================================================================

class TestRecoveryAfterRejection(EventTestBase):

    def test_corrected_event_with_same_id_is_applied(self):
        """Rejected events are not marked processed, so a fixed
        re-send is not mistaken for a duplicate."""
        self.assert_rejected(make_event(event_version="1"))

        result = self.apply(make_event(event_version=1))

        self.assertEqual(result["status"], "APPLIED")
        self.assertEqual(self.state()["latest_version"], 1)

    def test_rejected_events_are_logged_but_do_not_count_as_processed(self):
        self.apply(make_event(event_id=""))

        self.assertEqual(len(self.processor.event_log), 1)
        self.assertEqual(self.processor.processed_events, set())

    def test_validation_does_not_mutate_input(self):
        event = make_event()
        snapshot = copy.deepcopy(event)

        validate_event(event)
        self.apply(event)

        self.assertEqual(event, snapshot)


# ======================================================================
# 7. validate_event() DIRECTLY
# ======================================================================

class TestValidateEventFunction(unittest.TestCase):

    def test_valid_event_has_no_errors(self):
        self.assertEqual(validate_event(make_event()), [])

    def test_returns_list_of_strings(self):
        errors = validate_event({})

        self.assertIsInstance(errors, list)
        self.assertTrue(all(isinstance(e, str) for e in errors))


if __name__ == "__main__":
    unittest.main(verbosity=2)

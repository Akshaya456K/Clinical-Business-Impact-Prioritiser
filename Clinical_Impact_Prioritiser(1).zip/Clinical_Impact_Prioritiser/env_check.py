"""
Dependency / environment verification (single source of truth).

The scikit-learn version is read from requirements.txt (the declared
dependency) so the pin lives in exactly one place. The serialized models
were produced with that exact version; loading them under a different
version can silently change behaviour, so this check runs BEFORE any
model is loaded and fails with an actionable message instead of a
warning that can be missed or suppressed.

Only the declared version is claimed as supported. Other versions are
untested and are rejected, not tolerated.
"""
import re
from pathlib import Path

REQUIREMENTS_PATH = Path(__file__).resolve().parent / "requirements.txt"


class EnvironmentMismatchError(RuntimeError):
    """Raised when the installed scikit-learn differs from the declared pin."""


def required_sklearn_version(requirements_path=REQUIREMENTS_PATH):
    """Return the exact scikit-learn version pinned in requirements.txt."""

    for line in Path(requirements_path).read_text().splitlines():
        match = re.match(
            r"^\s*scikit-learn\s*==\s*([0-9][^\s;#]*)", line, re.IGNORECASE
        )
        if match:
            return match.group(1)

    raise EnvironmentMismatchError(
        "requirements.txt must pin scikit-learn with '==' "
        "(e.g. scikit-learn==1.9.1); no exact pin was found."
    )


def check_sklearn_version(installed=None, required=None):
    """
    Raise EnvironmentMismatchError unless the installed scikit-learn is
    exactly the declared version. Returns the verified version string.
    `installed` / `required` can be passed in for testing.
    """

    if installed is None:
        import sklearn
        installed = sklearn.__version__

    if required is None:
        required = required_sklearn_version()

    if installed != required:
        raise EnvironmentMismatchError(
            f"scikit-learn {installed} is installed, but this project "
            f"requires scikit-learn=={required} (the version the saved "
            "models were trained with; other versions are untested). "
            "Fix: run  pip install -r requirements.txt  "
            f"(or  pip install scikit-learn=={required}),  ideally in a "
            "fresh virtual environment, then re-run."
        )

    return installed

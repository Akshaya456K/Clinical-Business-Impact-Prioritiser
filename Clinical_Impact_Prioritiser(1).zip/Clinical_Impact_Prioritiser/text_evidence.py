"""
Free-text evidence extraction for the safety layer.

Why this exists
---------------
The production classifier is dominated by the structured fields (service,
user group, schedule, scope); the ticket text barely moves its output.
So a ticket whose text describes real operational/clinical impact, or
whose text says almost nothing, can be ACCEPTed with high confidence on
the strength of metadata alone.

This module reads the TEXT independently and reports evidence by CONCEPT,
not by a single trigger word. Each concept is a group of surface forms
(stems, so plurals / tenses / common misspellings of the stem still match):

    consequence   work or care is delayed / stopped / put at risk
    access_loss   people cannot see / open / reach what they need
    clinical      a clinical role, setting, activity or clinical data
    plural        a group is affected (not a single person)
    limited       the text itself restricts impact to one person / "others fine"
    symptom       the text names an identifiable problem at all

Derived judgements (used by safety.py, only ever to turn an otherwise
ACCEPTed ticket into HUMAN_REVIEW, never to lower an escalation):

    operational_impact_evidence   meaningful operational / clinical impact
    lacks_identifiable_problem    too little information to judge impact

Limits (be honest): these are hand-written concept lexicons. They
generalise across paraphrase within the listed concepts, they do not
understand language, and wording that uses none of a concept's forms will
not be recognised. They are a safety net, not a clinical assessment.
"""
import re

# ------------------------------------------------------------------
# Concept lexicons. Entries are regex fragments matched at a word start
# (so "delay" matches delay/delays/delayed/delaying).
# ------------------------------------------------------------------

CONSEQUENCE = [
    r"delay", r"postpon", r"cancel", r"defer", r"stall", r"halt",
    r"stopp", r"held up", r"holding (?:back|up)", r"hold(?:s)? up",
    r"backlog", r"waiting", r"at risk", r"unsafe", r"risk to",
    r"can'?t (?:proceed|start|begin|continue|operate|work)",
    r"cannot (?:proceed|start|begin|continue|operate|work)",
    r"unable to (?:proceed|start|begin|continue|operate|work)",
    r"working blind", r"flying blind", r"blocked", r"stuck",
]

ACCESS_LOSS = [
    r"can'?t|cannot|can not|cant|unable to|not able to|no way to",
    r"locked out", r"no access", r"without access", r"lost access",
    r"not (?:showing|loading|opening|displaying|available|arriving|reaching)",
]
# What is being lost (information / clinical data / function).
ACCESS_OBJECT = [
    r"see", r"view", r"open", r"find", r"read", r"retrieve", r"reach",
    r"access", r"get (?:to|at|their|the|any)", r"information", r"results?",
    r"records?", r"charts?", r"images?", r"imaging", r"scans?", r"notes",
    r"data", r"history", r"list",
]

CLINICAL = [
    r"surgeon", r"surgery", r"surgical", r"theatre", r"theater",
    r"operating (?:room|theat)", r"anaesthe", r"anesthe", r"consultant",
    r"clinician", r"clinical", r"doctor", r"physician", r"registrar",
    r"nurs", r"midwi", r"paramedic", r"pharmac", r"radiolog", r"patholog",
    r"patient", r"ward", r"icu", r"intensive care", r"critical care",
    r"emergency", r"a ?& ?e", r"\bed\b", r"trauma", r"triage", r"bedside",
    r"ward round", r"rounds?", r"clinic", r"procedure", r"operation",
    r"medication", r"dose", r"prescri", r"blood", r"lab(?:oratory)? results?",
    r"discharge", r"admission", r"bed (?:state|management)", r"cases?",
    r"lists?",  # theatre lists / operating lists (needs another concept too)
]

PLURAL = [
    r"surgeons", r"nurses", r"doctors", r"clinicians", r"staff(?! portal)",
    r"teams?", r"everyone", r"everybody", r"all ", r"whole", r"entire",
    r"several(?! (?:failed|attempts|times|tries))", r"multiple", r"many", r"both", r"people",
    r"users", r"consultants", r"registrars", r"wards", r"patients",
]

LIMITED = [
    r"\bone (?:user|person|nurse|doctor|member|staff|colleague|machine|pc|laptop)",
    r"\b1 (?:user|person|nurse|doctor|member|staff|colleague|machine|pc|laptop)",
    r"single (?!sign)",
    r"\ban? (?:[a-z-]+ ){0,2}(?:pharmacist|radiologist|physician|nurse|doctor|"
    r"clerk|technician|surgeon|consultant|registrar|clinician|porter|"
    r"employee|member|midwife|user|person)\b",
    r"unaffected", r"not affected",
    r"(?:colleague|others?|everyone else|rest of)[^.]{0,40}(?:fine|ok|okay|working|unaffected)",
    r"only (?:one|me|my|1)", r"just (?:one|me|my|1)",
    r"others? (?:are |is )?(?:fine|ok|okay|working|unaffected)",
    r"everyone else (?:is )?(?:fine|ok|okay)",
    r"\bjust me\b", r"\bonly me\b", r"\bfor me\b",
]

# Any identifiable problem or symptom. Deliberately broad: its job is to
# detect that a ticket describes NOTHING identifiable, not to rate it.
SYMPTOM = [
    r"down", r"outage", r"offline", r"(?:switched|turned|powered) off", r"slow", r"lag",
    r"fail", r"error", r"crash", r"froze", r"frozen", r"freez", r"hang",
    r"jam", r"broke", r"broken", r"fault", r"bug", r"glitch",
    r"not (?:work|load|open|show|display|sync|connect|arriv|reach|respond|print|start|updat|log|sign|send|receiv)",
    r"can'?t|cannot|can not|cant|unable", r"won'?t|wont", r"doesn'?t|doesnt",
    r"unavailab", r"unreachab", r"unresponsiv", r"timeout|timing out",
    r"locked", r"missing", r"wrong", r"incorrect", r"stale", r"old ",
    r"stopped", r"silent", r"blank", r"disconnect", r"intermittent",
    r"reset", r"password", r"install", r"request", r"setup|set up",
    r"access", r"login|log in|log into|sign in|sign into", r"update",
    r"delay", r"cancel", r"stuck", r"blocked", r"cannot see|can'?t see",
    r"drop(?:ping|ped)?", r"flicker", r"sluggish", r"degraded",
    r"toner", r"paper", r"moved", r"change", r"add ", r"new ",
]


def _compile(patterns):
    return [
        re.compile(r"(?<![a-z0-9])" + p, re.IGNORECASE)
        if not p.startswith(r"\b") else re.compile(p, re.IGNORECASE)
        for p in patterns
    ]


_C = {
    "consequence": _compile(CONSEQUENCE),
    "access_loss": _compile(ACCESS_LOSS),
    "access_object": _compile(ACCESS_OBJECT),
    "clinical": _compile(CLINICAL),
    "plural": _compile(PLURAL),
    "limited": _compile(LIMITED),
    "symptom": _compile(SYMPTOM),
}


def _normalise(text):
    text = str(text or "").lower()
    text = text.replace("\u2019", "'")
    # collapse elongated letters ("slooow" -> "slow"); runs of 3+ only, so
    # ordinary double letters are untouched
    text = re.sub(r"([a-z])\1{2,}", r"\1", text)
    return " " + re.sub(r"\s+", " ", text) + " "


def _hits(concept, text):
    found = []
    for pattern in _C[concept]:
        match = pattern.search(text)
        if match:
            found.append(match.group(0).strip())
    return found


def extract_evidence(ticket_text):
    """Return {concept: [matched surface forms]} plus derived judgements."""

    text = _normalise(ticket_text)
    ev = {name: _hits(name, text) for name in _C}

    # access loss only counts when something is actually being lost
    access_loss = bool(ev["access_loss"]) and bool(ev["access_object"])

    consequence = bool(ev["consequence"])
    clinical = bool(ev["clinical"])
    plural = bool(ev["plural"])
    limited = bool(ev["limited"])

    # Meaningful operational / clinical impact described in the text:
    #   (a) work/care is disrupted AND a clinical context is involved, or
    #   (b) clinical information/function is lost for a GROUP and the text
    #       itself does not restrict the impact to one person.
    strong = (
        (consequence and clinical)
        or (access_loss and clinical and plural and not limited)
    )

    n_words = len(re.findall(r"[a-z]{2,}", text))

    return {
        "matches": ev,
        "consequence": consequence,
        "access_loss": access_loss,
        "clinical": clinical,
        "plural": plural,
        "limited": limited,
        "operational_impact_evidence": strong,
        "lacks_identifiable_problem": not ev["symptom"] and not strong,
        "n_words": n_words,
    }


def describe_operational_impact(evidence):
    """Human-readable list of concept evidence (for audit / reason text)."""

    m = evidence["matches"]
    parts = []
    for label, key in (
        ("disruption", "consequence"),
        ("clinical context", "clinical"),
        ("group affected", "plural"),
    ):
        if m[key]:
            parts.append(f"{label}: {', '.join(sorted(set(m[key])))}")
    if evidence["access_loss"]:
        parts.append(
            "loss of access: " + ", ".join(sorted(set(m["access_loss"])))
        )
    return "; ".join(parts)

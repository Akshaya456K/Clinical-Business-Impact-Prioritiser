"""
Full reproducible evaluation: baseline, ML, latency, robustness, calibration,
safety and event-processing results in one command.

    python run_full_evaluation.py              # evaluate the current artifacts
    python run_full_evaluation.py --refresh    # retrain everything first, then evaluate

--refresh runs, in order (all seeded with random_state=42):
    train_model.py, train_signal_models.py, calibrate_model.py

Everything reported here is computed by running the code; nothing is typed in.
All data are SYNTHETIC or hand-written. These results are not clinical
validation and the system is a decision-support prototype.

Outputs:
    reports/full_evaluation_report.json
    reports/full_evaluation_report.md
"""
import argparse
import contextlib
import hashlib
import io
import json
import platform
import subprocess
import sys
import time
import unittest
import warnings
from pathlib import Path

import numpy as np
import pandas as pd
import sklearn
from sklearn.metrics import (accuracy_score, f1_score, precision_score,
                             recall_score)
from sklearn.model_selection import train_test_split

BASE = Path(__file__).resolve().parent
REPORTS = BASE / "reports"
FEATURES = ["ticket_content", "affected_service", "user_group", "operating_schedule", "scope"]
LABELS = ["P1", "P2", "P3", "P4"]
HIGH = ["P1", "P2"]
RANDOM_STATE = 42
TARGET_MS = 1000.0

TEST_MODULES = ["test_event_contracts", "test_event_recovery", "test_safety_layer",
                "test_ml_pipeline", "test_robustness_suite"]


def sha(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()[:16]


def quiet_import(name):
    with contextlib.redirect_stdout(io.StringIO()):
        return __import__(name)


def cls_metrics(y, p):
    y, p = np.asarray(y), np.asarray(p)
    eh, ph = np.isin(y, HIGH), np.isin(p, HIGH)
    return {
        "accuracy": round(float(accuracy_score(y, p)), 4),
        "macro_precision": round(float(precision_score(y, p, labels=LABELS, average="macro", zero_division=0)), 4),
        "macro_recall": round(float(recall_score(y, p, labels=LABELS, average="macro", zero_division=0)), 4),
        "macro_f1": round(float(f1_score(y, p, labels=LABELS, average="macro", zero_division=0)), 4),
        "high_impact_precision": round(float(precision_score(eh, ph, zero_division=0)), 4),
        "high_impact_recall": round(float(recall_score(eh, ph, zero_division=0)), 4),
        "high_impact_f1": round(float(f1_score(eh, ph, zero_division=0)), 4),
    }


def refresh():
    for script in ("train_model.py", "train_signal_models.py", "calibrate_model.py"):
        print(f"[refresh] running {script}")
        subprocess.run([sys.executable, "-W", "ignore", script], cwd=BASE, check=True,
                       stdout=subprocess.DEVNULL)


def section_environment():
    files = ["hospital_it_tickets.csv", "models/priority_model.joblib",
             "models/signal_text_model.joblib", "models/signal_structured_model.joblib",
             "robustness/robustness_test_cases.csv", "robustness/robustness_extended_cases.csv"]
    cal = BASE / "models" / "priority_model_calibrated.joblib"
    if cal.exists():
        files.append("models/priority_model_calibrated.joblib")
    return {
        "python": platform.python_version(),
        "scikit-learn": sklearn.__version__,
        "pandas": pd.__version__,
        "numpy": np.__version__,
        "random_state": RANDOM_STATE,
        "split": "stratified 80/20, random_state=42 (train_model.py, calibrate_model.py, train_signal_models.py)",
        "artifact_sha256_prefix": {f: sha(BASE / f) for f in files},
    }


def section_baseline_and_ml(df):
    baseline = quiet_import("baseline")
    _, X_test, _, y_test = train_test_split(df[FEATURES], df["priority"], test_size=0.2,
                                            random_state=RANDOM_STATE, stratify=df["priority"])
    base_all = df.apply(baseline.predict_priority, axis=1, result_type="expand")[0]
    base_test = base_all.loc[X_test.index]
    import joblib
    with warnings.catch_warnings():
        warnings.simplefilter("ignore")
        raw_model = joblib.load(BASE / "models" / "priority_model.joblib")
    ml_pred = raw_model.predict(X_test)

    # batch latency (as in evaluate_system.py)
    t0 = time.perf_counter()
    raw_model.predict(X_test)
    batch_ms = (time.perf_counter() - t0) * 1000
    return {
        "test_set": {"n": int(len(y_test)), "note": "held-out 20% split; synthetic data"},
        "rule_based_baseline_heldout": cls_metrics(y_test, base_test),
        "rule_based_baseline_all_2000": cls_metrics(df["priority"], base_all),
        "logistic_regression_heldout": cls_metrics(y_test, ml_pred),
        "batch_latency": {"total_ms_for_400": round(batch_ms, 2),
                          "avg_ms_per_ticket": round(batch_ms / len(X_test), 4)},
    }, X_test, y_test


def percentile(a, q):
    return round(float(np.percentile(a, q)), 3)


def section_pipeline(X_test, y_test):
    """End-to-end (predict + evidence + safety) per-ticket latency and safety metrics."""
    de = quiet_import("decision_engine")
    rows, lat = [], []
    tickets = X_test.to_dict("records")
    with warnings.catch_warnings():
        warnings.simplefilter("ignore")
        for t in tickets[:20]:                       # warm-up (not timed)
            de.process_ticket(t)
        for t in tickets:
            t0 = time.perf_counter()
            r = de.process_ticket(t)
            lat.append((time.perf_counter() - t0) * 1000)
            rows.append(r)
    lat = np.array(lat)
    out = pd.DataFrame(rows)
    out["actual"] = y_test.to_numpy()
    out["actual_high"] = out["actual"].isin(HIGH)
    acc = out["action"] == "ACCEPT"
    total_s = lat.sum() / 1000
    latency = {
        "scope": "end-to-end process_ticket (ML + evidence + safety layer), one ticket at a time, 400 held-out tickets",
        "avg_ms": round(float(lat.mean()), 3), "p50_ms": percentile(lat, 50),
        "p95_ms": percentile(lat, 95), "p99_ms": percentile(lat, 99), "max_ms": round(float(lat.max()), 3),
        "throughput_tickets_per_sec": round(float(len(lat) / total_s), 1),
        "target_ms": TARGET_MS, "p99_within_target": bool(np.percentile(lat, 99) <= TARGET_MS),
    }
    safety = {
        "scope": "400 held-out SYNTHETIC tickets (clean, in-distribution)",
        "action_counts": out["action"].value_counts().to_dict(),
        "human_review_rate": round(float((out["action"] == "HUMAN_REVIEW").mean()), 4),
        "low_confidence_routed_to_review": int(out["reason"].str.contains("confidence is below", na=False).sum()),
        "high_impact_false_acceptance": int((out["actual_high"] & acc).sum()),
        "high_impact_false_acceptance_rate": round(float((out["actual_high"] & acc).sum() / out["actual_high"].sum()), 4),
        "false_rejection_low_impact_not_accepted": int((~out["actual_high"] & ~acc).sum()),
        "false_rejection_rate": round(float((~out["actual_high"] & ~acc).sum() / (~out["actual_high"]).sum()), 4),
        "conflict_flags_raised": int(out["safety_flags"].apply(lambda f: any("CONFLICT" in x for x in f)).sum()),
        "confidence_type": sorted(set(out["confidence_type"].dropna())),
    }
    return latency, safety


def section_robustness():
    er = __import__("evaluate_robustness")
    with warnings.catch_warnings():
        warnings.simplefilter("ignore")
        res = er.add_flags(er.run_pipeline(er.load_cases("all")))
    return {
        "overall": er.metrics(res),
        "legacy_110": er.metrics(res[res["suite"] == "legacy"]),
        "extended_115": er.metrics(res[res["suite"] == "extended"]),
        "per_category_all": er.category_table(res).to_dict("records"),
        "per_category_extended_only": er.category_table(res[res["suite"] == "extended"]).to_dict("records"),
        "known_false_acceptances": res.loc[res["false_acceptance"], ["case_id", "category", "ticket_content"]].to_dict("records"),
    }


def section_calibration():
    p = REPORTS / "calibration_report.json"
    if not p.exists():
        return {"error": "run calibrate_model.py (or --refresh)"}
    r = json.loads(p.read_text())
    keys = ("accuracy", "macro_f1", "high_impact_recall", "log_loss", "brier", "ece")
    pick = lambda blk: {k: {m: blk[k][m] for m in keys} for k in ("raw", "sigmoid", "isotonic")}
    return {
        "candidates": r["method_candidates"],
        "decision": "calibrated model adopted" if r["calibrated_model_adopted"] else "raw probabilities kept",
        "candidate_by_log_loss": r["chosen_method"],
        "rule_checks_for_candidate": r["rule_checks_for_candidate"],
        "nested_cv_train": pick(r["cv_train_oof"] if "sigmoid" in r["cv_train_oof"] else r),
        "heldout_test": pick(r["heldout_test_synthetic"]["candidates"]),
        "robustness_non_conflict": pick(r["robustness_cases"]["candidates"]),
        "thresholds": r["thresholds_unchanged"],
    }


def section_events():
    out = {}
    for mod in TEST_MODULES:
        suite = unittest.defaultTestLoader.loadTestsFromName(mod)
        stream = io.StringIO()
        with warnings.catch_warnings(), contextlib.redirect_stdout(io.StringIO()):
            warnings.simplefilter("ignore")
            res = unittest.TextTestRunner(stream=stream, verbosity=0).run(suite)
        out[mod] = {"tests": res.testsRun, "passed": res.testsRun - len(res.failures) - len(res.errors),
                    "failures": len(res.failures), "errors": len(res.errors)}
    legacy = subprocess.run([sys.executable, "-W", "ignore", "test_event_processor.py"], cwd=BASE,
                            capture_output=True, text=True).stdout
    line = [l for l in legacy.splitlines() if l.startswith("Passed:")]
    n, d = (int(x) for x in line[0].split(":")[1].strip().split("/")) if line else (0, 0)
    out["test_event_processor (original)"] = {"tests": d, "passed": n, "failures": d - n, "errors": 0}
    # named scenario results taken from the test classes
    scen = unittest.defaultTestLoader.loadTestsFromName("test_event_recovery")
    names = [t.id().split(".")[-1] for g in scen for t in g]
    out["scenario_groups"] = {
        "duplicate_handling": [n for n in names if "duplicate" in n or "replay" in n or "idempot" in n],
        "out_of_order_and_stale": [n for n in names if "out_of_order" in n or "stale" in n or "delayed" in n or "newer" in n],
        "state_recovery": [n for n in names if "recovery" in n or "converge" in n],
        "schema_validation": ["see test_event_contracts (59 tests) and TestMalformedAndSchema in test_event_recovery"],
    }
    out["totals"] = {"tests": sum(v["tests"] for k, v in out.items() if "tests" in v and k != "scenario_groups"),
                     "passed": sum(v["passed"] for k, v in out.items() if "passed" in v)}
    return out


def to_markdown(rep):
    f = lambda v: f"{v:.4f}" if isinstance(v, float) else str(v)
    L = ["# Full evaluation report", "",
         "> All data are synthetic or hand-written. Not clinical validation. Decision-support prototype only.", "",
         "## Environment and reproducibility", ""]
    e = rep["environment"]
    L += [f"- Python {e['python']}, scikit-learn {e['scikit-learn']}, pandas {e['pandas']}, numpy {e['numpy']}",
          f"- random_state = {e['random_state']}; split: {e['split']}",
          "- Artifact hashes: " + ", ".join(f"`{k}`={v}" for k, v in e["artifact_sha256_prefix"].items()), ""]
    b = rep["baseline_and_ml"]
    L += ["## Baseline vs ML (held-out 400 synthetic tickets)", "",
          "| Model | accuracy | macro P | macro R | macro F1 | high-impact P | high-impact R | high-impact F1 |", "|---|---|---|---|---|---|---|---|"]
    for k, n in (("rule_based_baseline_heldout", "Rule-based baseline"), ("logistic_regression_heldout", "Logistic Regression")):
        m = b[k]
        L.append(f"| {n} | {m['accuracy']} | {m['macro_precision']} | {m['macro_recall']} | {m['macro_f1']} | "
                 f"{m['high_impact_precision']} | {m['high_impact_recall']} | {m['high_impact_f1']} |")
    lt = rep["latency"]
    L += ["", "## Performance", "",
          f"- Batch model.predict: {b['batch_latency']['avg_ms_per_ticket']} ms/ticket",
          f"- End-to-end `process_ticket`: avg {lt['avg_ms']} ms, p50 {lt['p50_ms']}, p95 {lt['p95_ms']}, p99 {lt['p99_ms']} ms, "
          f"max {lt['max_ms']} ms; throughput {lt['throughput_tickets_per_sec']} tickets/s; target {lt['target_ms']} ms met at p99: {lt['p99_within_target']}", ""]
    s = rep["safety_synthetic_heldout"]
    L += ["## Safety (held-out synthetic tickets)", ""] + [f"- {k}: {v}" for k, v in s.items() if k != "scope"] + [""]
    r = rep["robustness"]
    for name, title in (("overall", "Overall (225 cases)"), ("legacy_110", "First-round suite (110)"), ("extended_115", "Extended suite (115, written before the safety upgrade)")):
        m = r[name]
        sf = m["safety"]
        h = m["high_impact"]
        L += [f"## Robustness: {title}", "",
              f"- Priority accuracy (non-conflict cases): {m['accuracy']} ; high-impact P/R/F1: {h['precision']}/{h['recall']}/{h['f1']}",
              f"- False acceptance (possible high-impact auto-ACCEPTed): {sf['false_acceptance']} ({sf['false_acceptance_rate_of_high_impact']:.1%})",
              f"- False rejection (routine ticket not accepted): {sf['false_rejection']} ({sf['false_rejection_rate_of_low_impact']:.1%}); review {sf['over_review']}, escalation {sf['over_escalation']}",
              f"- Human-review rate: {sf['human_review_rate']:.1%}; text-high/fields-low conflicts routed to HUMAN_REVIEW: {sf['conflict_routed_to_human_review']}/{sf['conflict_cases_text_high_fields_low']}", ""]
    for key, title in (("per_category_all", "Per category, both suites"), ("per_category_extended_only", "Per category, extended suite only")):
        L += [f"### {title}", "", "| category | n | scored | accuracy | hi-recall | hi-precision | false-accept | over-review | over-escalation |", "|---|---|---|---|---|---|---|---|---|"]
        for c in r[key]:
            L.append(f"| {c['category']} | {c['n']} | {c.get('n_scored')} | {c.get('accuracy')} | {c.get('hi_recall')} | {c.get('hi_precision')} | "
                     f"{c.get('false_accept')} | {c.get('over_review')} | {c.get('over_escalation')} |")
        L.append("")
    L += ["### Known false acceptances (not hidden)", ""] + [f"- {x['case_id']} ({x['category']}): {x['ticket_content']}" for x in r["known_false_acceptances"]] + [""]
    c = rep["calibration"]
    L += ["## Calibration", "", f"Decision: **{c['decision']}** (candidate by log loss: {c['candidate_by_log_loss']}; checks: "
          + ", ".join(f"{k}={'PASS' if v else 'FAIL'}" for k, v in c["rule_checks_for_candidate"].items()) + ")", ""]
    for key, title in (("nested_cv_train", "Nested CV on training split (decision data)"), ("heldout_test", "Held-out synthetic test (reporting)"), ("robustness_non_conflict", "Robustness non-conflict cases (reporting)")):
        L += [f"### {title}", "", "| method | accuracy | macro F1 | hi-recall | log loss | Brier | ECE |", "|---|---|---|---|---|---|---|"]
        for m, v in c[key].items():
            L.append(f"| {m} | {v['accuracy']} | {v['macro_f1']} | {v['high_impact_recall']} | {v['log_loss']} | {v['brier']} | {v['ece']} |")
        L.append("")
    ev = rep["tests"]
    L += ["## Test results", "", "| suite | tests | passed | failures | errors |", "|---|---|---|---|---|"]
    for k, v in ev.items():
        if k in ("scenario_groups", "totals"):
            continue
        L.append(f"| {k} | {v['tests']} | {v['passed']} | {v['failures']} | {v['errors']} |")
    L += [f"| **total** | **{ev['totals']['tests']}** | **{ev['totals']['passed']}** | | |", ""]
    return "\n".join(L) + "\n"


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--refresh", action="store_true", help="retrain models/signals/calibration first")
    ap.add_argument("--skip-tests", action="store_true")
    args = ap.parse_args()
    if args.refresh:
        refresh()
    warnings.filterwarnings("ignore")
    sys.path.insert(0, str(BASE))
    df = pd.read_csv(BASE / "hospital_it_tickets.csv")

    rep = {"environment": section_environment()}
    rep["baseline_and_ml"], X_test, y_test = section_baseline_and_ml(df)
    rep["latency"], rep["safety_synthetic_heldout"] = section_pipeline(X_test, y_test)
    rep["robustness"] = section_robustness()
    rep["calibration"] = section_calibration()
    if not args.skip_tests:
        rep["tests"] = section_events()
    REPORTS.mkdir(exist_ok=True)
    (REPORTS / "full_evaluation_report.json").write_text(json.dumps(rep, indent=2, default=str))
    if not args.skip_tests:
        md = to_markdown(rep)
        (REPORTS / "full_evaluation_report.md").write_text(md, encoding="utf-8")
        print(md)
    print("Saved reports/full_evaluation_report.json" + ("" if args.skip_tests else " and .md"))


if __name__ == "__main__":
    main()

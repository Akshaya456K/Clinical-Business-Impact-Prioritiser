# Clinical Business-Impact Prioritiser

An AI-assisted incident prioritisation system designed for hospital IT teams to identify urgent clinical and business-impacting service failures among routine support requests.

## Problem Statement

Hospital IT teams support clinical systems around the clock. Urgent patient-facing failures can be hidden among routine IT requests.

This project prioritises hospital IT tickets based on ticket content and operational context, helping identify high-impact incidents that may require faster escalation.

## Key Features

- Rule-based baseline prioritisation
- Machine learning-based priority prediction
- Four priority levels: P1, P2, P3 and P4
- High-impact incident detection for P1 and P2 incidents
- Evidence and explanation layer
- Safety checks and fallback workflow
- Human review for uncertain or failed predictions
- Duplicate event detection
- Delayed and out-of-order event handling
- Performance evaluation against a target processing time
- Multi-page Streamlit application

## Dataset

The project uses a synthetic hospital IT ticket dataset.

- Total tickets: 2,000
- Training samples: 1,600
- Testing samples: 400
- Missing values: 0
- Duplicate rows: 0

Priority distribution:

| Priority | Tickets |
|----------|--------:|
| P1 | 200 |
| P2 | 400 |
| P3 | 600 |
| P4 | 800 |

The dataset includes ticket content, affected service, user group, operating schedule, impact scope and escalation outcome.

## Results

| Metric | Result |
|--------|-------:|
| Baseline Accuracy | 59.25% |
| ML Model Accuracy | 99.75% |
| Improvement | 40.50 percentage points |
| High-Impact Precision | 100% |
| High-Impact Recall | 100% |
| High-Impact F1 Score | 100% |
| Average Processing Time | 0.0946 ms |
| Target Processing Time | 1000 ms |
| Target Achieved | Yes |

The results were obtained using a held-out synthetic test dataset.

## Failure-State Testing

The system was tested against the following scenarios:

1. **Duplicate Events**  
   Repeated events are detected and do not corrupt ticket state.

2. **Out-of-Order Events**  
   Older events cannot overwrite newer ticket information.

3. **Delayed Events**  
   The latest valid ticket state is preserved when delayed events arrive.

## Application

The Streamlit application includes:

- **Operations Dashboard** — Incident and escalation overview
- **Prioritise Ticket** — AI-assisted priority prediction
- **Active Incident Queue** — View and filter high-impact incidents
- **System Monitoring** — Model and performance metrics
- **Failure and Recovery** — Event failure-state demonstrations
- **Responsible AI** — Safety controls, limitations and deployment checklist

## Project Structure

```text
clinical_impact_prioritiser/
│
├── app.py
├── baseline.py
├── train_model.py
├── predict.py
├── decision_engine.py
├── event_processor.py
├── safety.py
├── train_signal_models.py
├── calibrate_model.py
├── evaluate_robustness.py
├── run_full_evaluation.py
├── test_*.py
├── robustness/
├── evaluate_system.py
├── hospital_it_tickets.csv
├── README.md
├── requirements.txt
│
├── models/
├── reports/
│
└── .streamlit/
    └── config.toml


## Installation

```powershell
python -m venv .venv
.venv\Scripts\Activate.ps1
pip install -r requirements.txt
Running the Application

Start the Streamlit application:

streamlit run app.py

##Responsible AI Considerations

This project is designed as a decision-support prototype and does not replace clinical or operational judgement.

The system includes:

Input validation
Evidence for high-impact predictions
Human review pathways
Fallback behaviour for prediction failures
Event-state protection


## Robustness, Calibration, Safety and Event Recovery

**Scope of the claims.** Everything below is evaluated on synthetic or hand-written data. None of it is clinical validation, real-world validation or evidence of safety in a hospital. The system is decision support: it recommends, a human decides, and uncertain or conflicting cases are routed to `HUMAN_REVIEW`.

### 1. Model and baseline

Logistic Regression (TF-IDF on ticket text + one-hot affected service / user group / schedule / scope; `class_weight="balanced"`, `random_state=42`). It was kept because nothing in the evaluation justified replacing it. On the 400 held-out synthetic tickets: rule-based baseline 58.25% accuracy vs Logistic Regression 99.75% (high-impact P/R/F1 1.0/1.0/1.0). The synthetic labels follow clean rules over the structured fields, so **99.75% is a synthetic-data result and is optimistic**. (The "Results" table above is the original first-round run; `reports/full_evaluation_report.md` is the reproducible current one.)

### 2. Robustness evaluation

* `robustness/robustness_test_cases.csv`: 110 first-round cases (unchanged).
* `robustness/robustness_extended_cases.csv`: 115 further cases (`generate_extended_cases.py`) written and frozen before the safety upgrade, so they act as a clean holdout for the new rules. Each has an explicit `expected_handling` (`ESCALATE_OR_REVIEW`, `ACCEPT_NORMAL`, `REVIEW_REQUIRED`) and `conflict_type`.
* Nine categories: clean, spelling, abbreviations (ICU, EHR, EMR, PACU, OR, ER, MAR...), noisy, paraphrased, multi-system, adversarial/obfuscated, misleading metadata, mixed signals.
* None of the cases are used for training or calibration; no text overlaps the training data (tested). No case was removed or edited to improve a score.

Results on all 225 cases (current pipeline):

| category | n | scored | accuracy | high-impact recall | false acceptances |
|---|---|---|---|---|---|
| clean | 14 | 14 | 1.00 | 1.00 | 0 |
| spelling | 25 | 25 | 1.00 | 1.00 | 0 |
| abbreviations | 25 | 25 | 0.96 | 1.00 | 0 |
| noisy | 35 | 35 | 1.00 | 1.00 | 0 |
| paraphrased | 24 | 24 | 1.00 | 1.00 | 0 |
| multi-system | 24 | 24 | 0.92 | 1.00 | 0 |
| adversarial | 39 | 35 | 0.97 | 0.87 | 1 |
| misleading metadata | 13 | 2 | 1.00 | 0.13 | 0 |
| mixed signals | 26 | 14 | **0.29** | 0.36 | 2 |

"Scored" excludes deliberately conflicting cases, which have no single correct label and are judged on routing instead. Overall: priority accuracy 92.9% on scored cases; false acceptance 3 cases (2.0%); false rejection of routine tickets 8 (11.0%: 4 sent to review, 4 escalated); human-review rate 12.4%. Mixed signals remain weak: the model follows the structured fields when they disagree with the text, which is why the safety layer (section 4) exists.

### 3. Confidence calibration

`calibrate_model.py` compares raw, sigmoid (Platt) and isotonic probabilities with nested out-of-fold evaluation **on the training split only**; the held-out and robustness sets are used afterwards for reporting. A selection objective is fixed in advance: the best candidate (lowest log loss) replaces raw only if log loss is lower **and** Brier, ECE, accuracy and high-impact recall do not get worse.

| Nested CV (training split) | log loss | Brier | ECE |
|---|---|---|---|
| Raw | 0.0471 | 0.0089 | 0.0407 |
| Sigmoid | 0.0524 | 0.0174 | 0.0430 |
| Isotonic | 0.0196 | 0.0092 | 0.0125 |

**Decision: raw probabilities kept.** Isotonic improved log loss and ECE but failed the Brier check, and on the shifted robustness cases it was clearly worse (log loss 0.38 to 0.71, ECE 0.025 to 0.056). Sigmoid was no better than raw. `python calibrate_model.py --adopt` would save a calibrated model; `predict.py` would then use it automatically. Every result carries `confidence_type` (`"raw"` or `"calibrated"`), and the UI labels it. A confidence value is a model probability, not a guarantee of correctness. Full tables and the reliability curve: `reports/calibration_report.md`, `reports/calibration_curve.csv`.

### 4. Safety logic

`safety.py` runs after the model; thresholds are unchanged (`LOW_CONFIDENCE_THRESHOLD = 0.60`, `HIGH_CONFIDENCE_THRESHOLD = 0.80`).

* Confidence below 60% goes to `HUMAN_REVIEW`. P2 below 80% goes to `HUMAN_REVIEW`. P1/P2 with fewer than three evidence items goes to `HUMAN_REVIEW`. P1 with evidence is `URGENT_ESCALATION`; P2 at 80% or above is `PRIORITY_ESCALATION`.
* **Text-vs-field conflict check (only on a would-be `ACCEPT`):** (a) a hand-written keyword rule (outage term **and** clinical-context/breadth term, against low-impact fields); (b) a learned signal from two small auxiliary Logistic Regression models (`train_signal_models.py`, text-only vs structured-only). If the text-only model says high-impact and the structured-only model says low-impact, the ticket goes to `HUMAN_REVIEW` with the reason and a flag (`TEXT_FIELD_CONFLICT_KEYWORD` / `TEXT_FIELD_CONFLICT_LEARNED`).
* Escalations are never downgraded. If the signal models are missing, the keyword rule still runs and `SIGNAL_CHECK_UNAVAILABLE` is flagged (fail-safe, no crash).
* A reverse-direction warning (trivial text, critical fields) exists but is **disabled** (`ENABLE_TEXT_LOW_FIELDS_HIGH_WARNING = False`): it had 25% precision on the robustness suite, so enabling it would mostly add noise.
* Measured effect: conflict cases (text high, fields low) routed to review 13/14 on the new cases (the keyword rule alone caught 4/14). On 400 held-out synthetic tickets: 0 high-impact false acceptances, 1.5% human-review rate, no conflict flags raised.

**Known gaps (not hidden):** X087 ("Surgeons are delaying the start of lists..."), X110 ("Something is not right with the system...") and X111 ("Please look into it as soon as possible.") are still auto-accepted. They are obfuscated or contentless texts the models cannot recognise. The learned signal was built from the same synthetic distribution, so 13/14 is an indication, not a guarantee.

### 5. Event processing and state recovery

`event_processor.py` validates every event (`event_id`, `ticket_id`, `event_type`, `event_timestamp`, `event_version`, optional `data`); invalid events return `INVALID_EVENT_REJECTED`, change nothing and are not recorded as processed. Duplicates are detected by `event_id`; older versions give `OUT_OF_ORDER_IGNORED`; equal versions give `STALE_EVENT_IGNORED`; version gaps are accepted. Ticket state is deep-copied on write and read (two tests exposed aliasing bugs, now fixed). "State recovery" here means the final state converges regardless of delivery order or duplication; **state is in memory only: there is no crash persistence or snapshot/restore.**

### 6. Tests

`test_event_contracts` 59, `test_event_recovery` 26 (all 16 required scenarios), `test_safety_layer` 30, `test_ml_pipeline` 28, `test_robustness_suite` 20, original `test_event_processor` 4: **167 tests, 167 pass.** The robustness tests are regression guards that list the three known false acceptances explicitly; a new one fails the suite.

### 7. Evaluation report and reproduction

```bash
pip install -r requirements.txt
python -m unittest test_event_contracts test_event_recovery test_safety_layer test_ml_pipeline test_robustness_suite
python test_event_processor.py
python run_full_evaluation.py            # writes reports/full_evaluation_report.md/.json
python run_full_evaluation.py --refresh  # also re-runs calibration, signal models and robustness
python calibrate_model.py                # add --adopt only to use a calibrated model
python train_signal_models.py
```

### 8. Reproducibility

Seeds are fixed (`random_state=42`, stratified 80/20 split), evidence ordering is deterministic (tested across `PYTHONHASHSEED` values), and artifact hashes are printed in the report. `scikit-learn==1.9.1` is pinned; the model was re-trained on that version with identical held-out results.

### 9. Performance

Batch `model.predict`: about 0.025 ms per ticket. End-to-end `process_ticket` (validation, model, safety, signal models, explanation): average about 5.4 ms, p95 about 7.0 ms, about 180 tickets/s on the sandbox CPU. The earlier "under 1 ms" figure applies to model inference only. The 1000 ms target is met.

### 10. Streamlit UI

Additive changes only: a confidence-type caption, a warning when a text/field conflict is flagged, and two new rows in the Responsible AI controls table. The Streamlit app could **not be launched** in the build sandbox (no package index); page logic was exercised with a stand-in harness only. Pre-existing issue, not changed: on the Active Incident Queue page the ticket-card block sits outside the `for` loop, so `priority_class` can be undefined when the queue is empty; this exists in the original code.

### 11. Limitations

* Data are synthetic; labels follow templates. No real tickets, no clinical validation.
* Robustness cases are author-written; expected labels are the author's judgement. Mixed-signal accuracy is 29%.
* Three known false acceptances (above); 8 routine robustness tickets were sent to review or escalated.
* The keyword lists and signal models are developed on synthetic text and will miss other phrasings.
* Raw probabilities are not guaranteed calibrated on real data; calibration was evaluated but not adopted.
* Events are held in memory; no persistence.
* Do not use for real patient-care decisions without independent clinical, safety and security validation.


## Round 4 changes (targeted)

**Environment check.** `env_check.py` reads the exact `scikit-learn==` pin from
`requirements.txt` and raises an actionable `EnvironmentMismatchError` if a different
version is installed. It runs before any model is loaded (`predict.py`, `safety.py`) and once
at the start of a pytest session (`conftest.py`). Only the declared version (1.9.1) is claimed
to work; other versions are untested. Warnings are not suppressed.

**Safety layer.** `text_evidence.py` extracts free-text evidence by concept (disruption,
loss of access, clinical context, group affected, self-limited scope, identifiable problem).
`safety.py` uses it, only on a decision that would otherwise be ACCEPT, to route to
HUMAN_REVIEW when (1) the text describes meaningful operational/clinical impact, (2) the text
names no identifiable problem while the fields show potential impact (critical service, 24/7,
or department/hospital-wide scope), or (3) the independent fields-only model clearly says high
impact. Escalations are never downgraded. Concept lexicons are hand-written and are a safety
net, not a clinical assessment. Not clinically validated.

**Evaluation.** `evaluate_robustness.py` now also reports decision-level metrics
(`decision_level` in the summary). Existing metrics are unchanged.

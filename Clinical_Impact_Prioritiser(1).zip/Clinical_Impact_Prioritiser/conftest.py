"""
pytest session guard: verify the declared scikit-learn version once, up
front, so a wrong environment fails fast with one actionable message
instead of scattered InconsistentVersionWarning failures.
"""
import pytest

from env_check import EnvironmentMismatchError, check_sklearn_version


def pytest_sessionstart(session):
    try:
        check_sklearn_version()
    except EnvironmentMismatchError as error:
        raise pytest.UsageError(str(error))

"""
Robustness evaluation (NOT used for training, calibration or rule development).

Suites
------
legacy    robustness/robustness_test_cases.csv      110 cases (first round)
extended  robustness/robustness_extended_cases.csv   new cases, 9 requested
                                                      categories, explicit
                                                      expected handling
all       both (default)

Metric definitions (all computed from the real decision pipeline)
-----------------------------------------------------------------
priority accuracy     predicted priority == expected priority. Cases marked
                      conflict_type != none are excluded from this number
                      because their "true" priority is ambiguous by design;
                      they are judged on handling instead.
high-impact P/R/F1    P1/P2 = high impact, from the predicted priority.
false acceptance      expected handling ESCALATE_OR_REVIEW or REVIEW_REQUIRED
                      but the final action is ACCEPT (a possible high-impact
                      incident silently treated as routine). UNSAFE.
false rejection       expected handling ACCEPT_NORMAL but the final action is
                      NOT ACCEPT (needless review/escalation). Reported as
                      over-review (HUMAN_REVIEW) and over-escalation
                      (URGENT/PRIORITY_ESCALATION). A cost, not a safety hole.
conflict routing      for cases with conflict_type text_high_fields_low: share
                      routed to HUMAN_REVIEW.
review satisfied      REVIEW_REQUIRED cases whose action is HUMAN_REVIEW.

For the legacy file, expected handling is derived from expected_priority
(P1/P2 -> ESCALATE_OR_REVIEW, P3/P4 -> ACCEPT_NORMAL) and conflict_type is
"unspecified"; the legacy file itself is left untouched.

Usage:
    python evaluate_robustness.py                       # all cases, full pipeline
    python evaluate_robustness.py --suite extended
    python evaluate_robustness.py --model models/priority_model.joblib --no-pipeline
    python evaluate_robustness.py --tag mytag

Outputs: reports/robustness_results[_tag].csv, reports/robustness_summary[_tag].json
"""
import argparse
import contextlib
import io
import json
import warnings
from pathlib import Path

import joblib
import numpy as np
import pandas as pd
from sklearn.metrics import (accuracy_score, classification_report,
                             confusion_matrix, f1_score, precision_score,
                             recall_score)

BASE_DIR = Path(__file__).resolve().parent
LEGACY_PATH = BASE_DIR / "robustness" / "robustness_test_cases.csv"
EXTENDED_PATH = BASE_DIR / "robustness" / "robustness_extended_cases.csv"
REPORT_DIR = BASE_DIR / "reports"
MODELS_DIR = BASE_DIR / "models"
FEATURES = ["ticket_content", "affected_service", "user_group",
            "operating_schedule", "scope"]
LABELS = ["P1", "P2", "P3", "P4"]
HIGH = ["P1", "P2"]

REPORT_CATEGORIES = ["clean", "spelling", "abbreviations", "noisy", "paraphrased",
                     "multi_system", "adversarial", "misleading_metadata",
                     "mixed_signals"]
LEGACY_CATEGORY_MAP = {
    "A_spelling": "spelling",
    "B_abbreviation": "abbreviations",
    "C_no_punctuation": "noisy",
    "D_incomplete_noisy": "noisy",
    "E_multi_system": "multi_system",
    "F_paraphrase": "paraphrased",
    "G_indirect_high_impact": "adversarial",
    "H_misleading_wording": "adversarial",
    "I_mixed_signals": "mixed_signals",
}
ESC, ACC, REV = "ESCALATE_OR_REVIEW", "ACCEPT_NORMAL", "REVIEW_REQUIRED"


def load_cases(suite="all"):
    frames = []
    if suite in ("legacy", "all"):
        d = pd.read_csv(LEGACY_PATH)
        d["suite"] = "legacy"
        d["source_category"] = d["category"]
        d["category"] = d["category"].map(LEGACY_CATEGORY_MAP)
        d["expected_handling"] = np.where(d["expected_priority"].isin(HIGH), ESC, ACC)
        d["conflict_type"] = "unspecified"
        frames.append(d)
    if suite in ("extended", "all"):
        d = pd.read_csv(EXTENDED_PATH)
        d["suite"] = "extended"
        d["source_category"] = d["category"]
        frames.append(d)
    cases = pd.concat(frames, ignore_index=True)
    required = FEATURES + ["expected_priority", "expected_handling", "category"]
    missing = [c for c in required if c not in cases.columns or cases[c].isna().any()]
    if missing:
        raise SystemExit(f"Robustness cases missing/invalid columns: {missing}")
    return cases


def load_model(path=None):
    if path is None:
        cal = MODELS_DIR / "priority_model_calibrated.joblib"
        path = cal if cal.exists() else MODELS_DIR / "priority_model.joblib"
    path = Path(path)
    return joblib.load(path), path


def predict_with_model(model, cases):
    proba = model.predict_proba(cases[FEATURES])
    classes = list(model.classes_)
    out = cases.copy()
    out["predicted_priority"] = np.array(classes)[proba.argmax(axis=1)]
    out["confidence"] = (proba.max(axis=1) * 100).round(2)
    return out


def run_pipeline(cases):
    """Route every case through the real decision engine (predict + safety)."""
    with contextlib.redirect_stdout(io.StringIO()):
        from decision_engine import process_ticket
    rows = []
    for _, r in cases.iterrows():
        res = process_ticket({k: r[k] for k in FEATURES})
        rows.append({
            "predicted_priority": res["predicted_priority"],
            "confidence": res["confidence"],
            "action": res["action"],
            "reason": res["reason"],
            "confidence_type": res.get("confidence_type"),
            "safety_flags": "|".join(res.get("safety_flags", [])),
        })
    out = cases.copy()
    for k in rows[0]:
        out[k] = [x[k] for x in rows]
    return out


def add_flags(df):
    df = df.copy()
    df["correct"] = df["predicted_priority"] == df["expected_priority"]
    exp_hi = df["expected_priority"].isin(HIGH)
    pred_hi = df["predicted_priority"].isin(HIGH)
    df["high_impact_missed"] = exp_hi & ~pred_hi
    df["high_impact_over_called"] = ~exp_hi & pred_hi
    if "action" in df.columns:
        accepted = df["action"] == "ACCEPT"
        df["false_acceptance"] = df["expected_handling"].isin([ESC, REV]) & accepted
        df["false_rejection"] = (df["expected_handling"] == ACC) & ~accepted
        df["over_review"] = (df["expected_handling"] == ACC) & (df["action"] == "HUMAN_REVIEW")
        df["over_escalation"] = (df["expected_handling"] == ACC) & df["action"].isin(
            ["URGENT_ESCALATION", "PRIORITY_ESCALATION"])
        df["review_satisfied"] = (df["expected_handling"] == REV) & (df["action"] == "HUMAN_REVIEW")
    return df


def prf(y_true_bool, y_pred_bool):
    return {
        "precision": round(float(precision_score(y_true_bool, y_pred_bool, zero_division=0)), 4),
        "recall": round(float(recall_score(y_true_bool, y_pred_bool, zero_division=0)), 4),
        "f1": round(float(f1_score(y_true_bool, y_pred_bool, zero_division=0)), 4),
    }


def metrics(df):
    nc = df[df["conflict_type"].isin(["none", "unspecified"])]
    y, p = df["expected_priority"], df["predicted_priority"]
    exp_hi, pred_hi = y.isin(HIGH), p.isin(HIGH)
    tn, fp, fn, tp = confusion_matrix(exp_hi, pred_hi, labels=[False, True]).ravel()
    wrong = ~df["correct"]
    m = {
        "n_cases": int(len(df)),
        "n_non_conflict": int(len(nc)),
        "accuracy_all": round(float(accuracy_score(y, p)), 4),
        "accuracy": round(float(accuracy_score(nc["expected_priority"], nc["predicted_priority"])), 4),
        "macro_precision": round(float(precision_score(y, p, labels=LABELS, average="macro", zero_division=0)), 4),
        "macro_recall": round(float(recall_score(y, p, labels=LABELS, average="macro", zero_division=0)), 4),
        "macro_f1": round(float(f1_score(y, p, labels=LABELS, average="macro", zero_division=0)), 4),
        "confusion_matrix": confusion_matrix(y, p, labels=LABELS).tolist(),
        "high_impact": {**prf(exp_hi, pred_hi), "TP": int(tp), "FP": int(fp),
                        "FN": int(fn), "TN": int(tn)},
        "mean_confidence_pct": round(float(df["confidence"].mean()), 2),
        "mean_confidence_when_wrong_pct": round(float(df.loc[wrong, "confidence"].mean()), 2) if wrong.any() else None,
        "wrong_with_confidence_ge_80": int((wrong & (df["confidence"] >= 80)).sum()),
    }
    if "action" in df.columns:
        n = len(df)
        hi_cases = df["expected_handling"].isin([ESC, REV])
        lo_cases = df["expected_handling"] == ACC
        conf = df[df["conflict_type"] == "text_high_fields_low"]
        m["safety"] = {
            "action_counts": df["action"].value_counts().to_dict(),
            "human_review_rate": round(float((df["action"] == "HUMAN_REVIEW").mean()), 4),
            "low_confidence_routed": int(df["reason"].str.contains("confidence is below", na=False).sum()),
            "false_acceptance": int(df["false_acceptance"].sum()),
            "false_acceptance_rate_of_high_impact": round(float(df["false_acceptance"].sum() / max(hi_cases.sum(), 1)), 4),
            "false_rejection": int(df["false_rejection"].sum()),
            "false_rejection_rate_of_low_impact": round(float(df["false_rejection"].sum() / max(lo_cases.sum(), 1)), 4),
            "over_review": int(df["over_review"].sum()),
            "over_escalation": int(df["over_escalation"].sum()),
            "conflict_cases_text_high_fields_low": int(len(conf)),
            "conflict_routed_to_human_review": int((conf["action"] == "HUMAN_REVIEW").sum()),
            "conflict_not_accepted": int((conf["action"] != "ACCEPT").sum()),
            "review_required_cases": int((df["expected_handling"] == REV).sum()),
            "review_required_satisfied": int(df["review_satisfied"].sum()),
        }
    return m


def decision_level_metrics(df):
    """
    DECISION-level view (added in Round 4; existing metrics unchanged).

    The priority metrics above score the model's predicted class. This scores
    the FINAL ACTION against the expected handling, which is what the safety
    layer actually changes:
      high-risk case   = expected_handling ESCALATE_OR_REVIEW / REVIEW_REQUIRED
      captured         = high-risk case whose action is not ACCEPT
      handling_correct = high-risk -> not ACCEPT ; ACCEPT_NORMAL -> ACCEPT
    """
    if df.empty or "action" not in df.columns:
        return {"n": int(len(df))}
    risky = df["expected_handling"].isin([ESC, REV])
    normal = df["expected_handling"] == ACC
    accepted = df["action"] == "ACCEPT"
    captured = risky & ~accepted
    flagged = ~accepted
    correct = (risky & ~accepted) | (normal & accepted)
    return {
        "n": int(len(df)),
        "high_risk_cases": int(risky.sum()),
        "high_risk_captured": int(captured.sum()),
        "high_risk_capture_rate": round(float(captured.sum() / max(risky.sum(), 1)), 4),
        "precision_of_non_accept": round(float((flagged & risky).sum() / max(flagged.sum(), 1)), 4),
        "false_acceptance": int((risky & accepted).sum()),
        "false_rejection": int((normal & ~accepted).sum()),
        "over_review": int((normal & (df["action"] == "HUMAN_REVIEW")).sum()),
        "over_escalation": int((normal & df["action"].isin(["URGENT_ESCALATION", "PRIORITY_ESCALATION"])).sum()),
        "human_review": int((df["action"] == "HUMAN_REVIEW").sum()),
        "handling_accuracy": round(float(correct.mean()), 4),
    }


def category_table(df):
    rows = []
    for cat in REPORT_CATEGORIES:
        d = df[df["category"] == cat]
        if d.empty:
            rows.append({"category": cat, "n": 0})
            continue
        nc = d[d["conflict_type"].isin(["none", "unspecified"])]
        exp_hi, pred_hi = d["expected_priority"].isin(HIGH), d["predicted_priority"].isin(HIGH)
        row = {
            "category": cat, "n": int(len(d)),
            "accuracy": round(float(nc["correct"].mean()), 3) if len(nc) else None,
            "n_scored": int(len(nc)),
            "hi_recall": round(float(recall_score(exp_hi, pred_hi, zero_division=0)), 3) if exp_hi.any() else None,
            "hi_precision": round(float(precision_score(exp_hi, pred_hi, zero_division=0)), 3) if pred_hi.any() else None,
        }
        if "action" in d.columns:
            row["false_accept"] = int(d["false_acceptance"].sum())
            row["over_review"] = int(d["over_review"].sum())
            row["over_escalation"] = int(d["over_escalation"].sum())
            row["human_review"] = int((d["action"] == "HUMAN_REVIEW").sum())
        rows.append(row)
    return pd.DataFrame(rows)


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--suite", choices=["legacy", "extended", "all"], default="all")
    ap.add_argument("--model", default=None)
    ap.add_argument("--no-pipeline", action="store_true",
                    help="model-only evaluation (no safety routing)")
    ap.add_argument("--full-pipeline", action="store_true",
                    help="kept for backward compatibility; pipeline is on by default")
    ap.add_argument("--tag", default=None)
    ap.add_argument("--quiet", action="store_true")
    args = ap.parse_args()

    cases = load_cases(args.suite)
    use_pipeline = not args.no_pipeline and args.model is None
    version_warn = []
    if use_pipeline:
        with warnings.catch_warnings(record=True) as caught:
            warnings.simplefilter("always")
            res = run_pipeline(cases)
        version_warn = [str(w.message) for w in caught if "InconsistentVersion" in w.category.__name__]
        model_path = "decision_engine pipeline (predict.py model + safety.py)"
    else:
        with warnings.catch_warnings(record=True) as caught:
            warnings.simplefilter("always")
            model, path = load_model(args.model)
        version_warn = [str(w.message) for w in caught if "InconsistentVersion" in w.category.__name__]
        res = predict_with_model(model, cases)
        model_path = str(path.relative_to(BASE_DIR)) if path.is_relative_to(BASE_DIR) else str(path)
    res = add_flags(res)

    summary = {"suite": args.suite, "model": model_path,
               "sklearn_version_warning": version_warn[0].split(" This might")[0] if version_warn else None,
               "overall": metrics(res)}
    for name in ("legacy", "extended"):
        sub = res[res["suite"] == name]
        if len(sub):
            summary[name] = metrics(sub)
    if "action" in res.columns:
        summary["decision_level"] = {"overall": decision_level_metrics(res)}
        for _cat in REPORT_CATEGORIES:
            summary["decision_level"][_cat] = decision_level_metrics(res[res["category"] == _cat])
    summary["per_category_all"] = category_table(res).to_dict("records")
    if "extended" in set(res["suite"]):
        summary["per_category_extended_only"] = category_table(res[res["suite"] == "extended"]).to_dict("records")

    if not args.quiet:
        o = summary["overall"]
        print("=" * 72)
        print("ROBUSTNESS EVALUATION  (hand-written stress cases; not clinical validation)")
        print("=" * 72)
        print("Pipeline/model:", model_path)
        if version_warn:
            print("WARNING: sklearn version mismatch:", summary["sklearn_version_warning"])
        for name in ("overall", "legacy", "extended"):
            if name not in summary:
                continue
            s = summary[name]
            h = s["high_impact"]
            print(f"\n--- {name.upper()} ({s['n_cases']} cases, {s['n_non_conflict']} scored for priority) ---")
            print(f"Priority accuracy (non-conflict): {s['accuracy']*100:.1f}%   all cases: {s['accuracy_all']*100:.1f}%")
            print(f"High-impact P1/P2  precision {h['precision']:.3f}  recall {h['recall']:.3f}  F1 {h['f1']:.3f}  (FN {h['FN']}, FP {h['FP']})")
            print(f"Mean confidence {s['mean_confidence_pct']}%; when wrong {s['mean_confidence_when_wrong_pct']}%; "
                  f"wrong with conf >= 80%: {s['wrong_with_confidence_ge_80']}")
            if "safety" in s:
                sf = s["safety"]
                print(f"SAFETY: false acceptance {sf['false_acceptance']} "
                      f"({sf['false_acceptance_rate_of_high_impact']*100:.1f}% of high-impact/review cases) | "
                      f"false rejection {sf['false_rejection']} ({sf['false_rejection_rate_of_low_impact']*100:.1f}% of low-impact; "
                      f"review {sf['over_review']}, escalation {sf['over_escalation']}) | "
                      f"human-review rate {sf['human_review_rate']*100:.1f}%")
                print(f"        conflict (text high / fields low): {sf['conflict_routed_to_human_review']}/"
                      f"{sf['conflict_cases_text_high_fields_low']} to HUMAN_REVIEW, "
                      f"{sf['conflict_not_accepted']}/{sf['conflict_cases_text_high_fields_low']} not accepted; "
                      f"REVIEW_REQUIRED satisfied {sf['review_required_satisfied']}/{sf['review_required_cases']}")
        if "decision_level" in summary:
            dl = summary["decision_level"]["mixed_signals"]
            print("\n--- Mixed-signal category, DECISION level (final action vs expected handling) ---")
            print(json.dumps(dl))
        print("\n--- Per category (all suites) ---")
        print(category_table(res).to_string(index=False))
        if "extended" in set(res["suite"]):
            print("\n--- Per category (extended suite only; written before safety changes) ---")
            print(category_table(res[res["suite"] == "extended"]).to_string(index=False))
        print("\n--- Classification report (all) ---")
        print(classification_report(res["expected_priority"], res["predicted_priority"], labels=LABELS, zero_division=0))
        if "action" in res.columns:
            bad = res[res["false_acceptance"]]
            print(f"--- FALSE ACCEPTANCES ({len(bad)}): possible high-impact tickets auto-ACCEPTed ---")
            for _, r in bad.iterrows():
                print(f"[{r['case_id']}] {r['category']} expected {r['expected_priority']} ({r['expected_handling']}) "
                      f"-> {r['predicted_priority']} {r['confidence']}%  {r['affected_service']} | {r['scope']}")
                print(f"    {r['ticket_content']}")
        wrong = res[~res["correct"] & res["conflict_type"].isin(["none", "unspecified"])]
        print(f"\n--- Priority misclassifications, non-conflict cases ({len(wrong)}) ---")
        for _, r in wrong.iterrows():
            flag = "  !! MISSED HIGH-IMPACT" if r["high_impact_missed"] else ""
            print(f"[{r['case_id']}] {r['category']} expected {r['expected_priority']} -> got {r['predicted_priority']} "
                  f"({r['confidence']}%){flag}")
            print(f"    {r['ticket_content']}")

    REPORT_DIR.mkdir(exist_ok=True)
    tag = f"_{args.tag}" if args.tag else ""
    res.drop(columns=["suite"], errors="ignore").assign(suite=res["suite"]).to_csv(
        REPORT_DIR / f"robustness_results{tag}.csv", index=False)
    (REPORT_DIR / f"robustness_summary{tag}.json").write_text(json.dumps(summary, indent=2, default=str))
    if not args.quiet:
        print(f"\nSaved: reports/robustness_results{tag}.csv, reports/robustness_summary{tag}.json")
    return summary


if __name__ == "__main__":
    main()

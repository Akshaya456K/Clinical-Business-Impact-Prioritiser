"""
Confidence calibration for the Clinical Impact Prioritiser.

Compares raw Logistic Regression probabilities with sigmoid (Platt) and
isotonic calibration, then saves a calibrated model alongside the original.

Leakage control
---------------
* The same stratified 80/20 split as train_model.py (random_state=42) is used.
* Method selection uses ONLY the 80% training portion: nested, out-of-fold
  evaluation (outer 5-fold; CalibratedClassifierCV fits its own inner 5-fold
  on the outer-training part only).
* The 20% test set and the robustness set are used ONCE, after the method is
  chosen, purely for reporting. Neither is used for fitting or selection.
* The robustness set is never used to train or calibrate anything.

Outputs
-------
    models/priority_model_calibrated.joblib   (original model is untouched)
    reports/calibration_report.json
    reports/calibration_curve.csv

Usage:
    python calibrate_model.py
"""
import argparse
import json
import warnings
from pathlib import Path

import joblib
import numpy as np
import pandas as pd
from sklearn.calibration import CalibratedClassifierCV
from sklearn.compose import ColumnTransformer
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.linear_model import LogisticRegression
from sklearn.metrics import (accuracy_score, f1_score, log_loss,
                             precision_score, recall_score)
from sklearn.model_selection import StratifiedKFold, train_test_split
from sklearn.pipeline import Pipeline
from sklearn.preprocessing import OneHotEncoder

BASE_DIR = Path(__file__).resolve().parent
DATA_PATH = BASE_DIR / "hospital_it_tickets.csv"
ROBUST_PATH = BASE_DIR / "robustness" / "robustness_test_cases.csv"
ROBUST_EXT_PATH = BASE_DIR / "robustness" / "robustness_extended_cases.csv"
MODEL_DIR = BASE_DIR / "models"
REPORT_DIR = BASE_DIR / "reports"
CAL_MODEL_PATH = MODEL_DIR / "priority_model_calibrated.joblib"

FEATURES = ["ticket_content", "affected_service", "user_group",
            "operating_schedule", "scope"]
TARGET = "priority"
LABELS = ["P1", "P2", "P3", "P4"]
RANDOM_STATE = 42
N_BINS = 10
# Current safety thresholds (safety.py). Read-only here; never modified.
LOW_T, HIGH_T = 0.60, 0.80


def build_base_pipeline():
    """Identical architecture/hyper-parameters to train_model.py."""
    pre = ColumnTransformer([
        ("text", TfidfVectorizer(lowercase=True, stop_words="english",
                                 ngram_range=(1, 2), min_df=1),
         "ticket_content"),
        ("categorical", OneHotEncoder(handle_unknown="ignore"),
         ["affected_service", "user_group", "operating_schedule", "scope"]),
    ])
    lr = LogisticRegression(max_iter=2000, class_weight="balanced",
                            random_state=RANDOM_STATE)
    return Pipeline([("preprocessor", pre), ("model", lr)])


# ------------------------------------------------------------------
# metrics
# ------------------------------------------------------------------
def multiclass_brier(y_true, proba, classes):
    onehot = (np.asarray(y_true)[:, None] == np.asarray(classes)[None, :]).astype(float)
    return float(np.mean(np.sum((proba - onehot) ** 2, axis=1)))


def reliability(y_true, proba, classes, n_bins=N_BINS):
    """Top-label reliability: confidence vs accuracy per bin, plus ECE."""
    classes = np.asarray(classes)
    conf = proba.max(axis=1)
    pred = classes[proba.argmax(axis=1)]
    hit = (pred == np.asarray(y_true)).astype(float)
    edges = np.linspace(0, 1, n_bins + 1)
    rows, ece = [], 0.0
    for lo, hi in zip(edges[:-1], edges[1:]):
        mask = (conf > lo) & (conf <= hi) if lo > 0 else (conf >= lo) & (conf <= hi)
        if not mask.any():
            continue
        w = mask.mean()
        gap = abs(hit[mask].mean() - conf[mask].mean())
        ece += w * gap
        rows.append({"bin": f"{lo:.1f}-{hi:.1f}", "n": int(mask.sum()),
                     "mean_confidence": round(float(conf[mask].mean()), 4),
                     "accuracy": round(float(hit[mask].mean()), 4)})
    return rows, float(ece)


def routing_counts(proba, classes):
    """How many tickets would fall under each confidence band (thresholds unchanged)."""
    conf = proba.max(axis=1)
    return {
        f"below_{int(LOW_T*100)}pct (low-confidence -> HUMAN_REVIEW)": int((conf < LOW_T).sum()),
        f"{int(LOW_T*100)}-{int(HIGH_T*100)}pct (P2 -> HUMAN_REVIEW)": int(((conf >= LOW_T) & (conf < HIGH_T)).sum()),
        f"at_or_above_{int(HIGH_T*100)}pct": int((conf >= HIGH_T).sum()),
    }


HIGH_IMPACT = ["P1", "P2"]


def summarise(y_true, proba, classes):
    """Probabilistic quality (log loss, Brier, ECE) + classification metrics,
    including high-impact (P1/P2 vs P3/P4) precision/recall/F1."""
    classes = list(classes)
    y_true = np.asarray(y_true)
    pred = np.asarray(classes)[proba.argmax(axis=1)]
    _, ece = reliability(y_true, proba, classes)
    # clip protects log_loss from exact 0/1 produced by isotonic calibration
    p = np.clip(proba, 1e-6, 1.0)
    p = p / p.sum(axis=1, keepdims=True)
    exp_hi, pred_hi = np.isin(y_true, HIGH_IMPACT), np.isin(pred, HIGH_IMPACT)
    return {
        "accuracy": round(float(accuracy_score(y_true, pred)), 4),
        "macro_precision": round(float(precision_score(y_true, pred, labels=LABELS, average="macro", zero_division=0)), 4),
        "macro_recall": round(float(recall_score(y_true, pred, labels=LABELS, average="macro", zero_division=0)), 4),
        "macro_f1": round(float(f1_score(y_true, pred, labels=LABELS, average="macro", zero_division=0)), 4),
        "high_impact_precision": round(float(precision_score(exp_hi, pred_hi, zero_division=0)), 4),
        "high_impact_recall": round(float(recall_score(exp_hi, pred_hi, zero_division=0)), 4),
        "high_impact_f1": round(float(f1_score(exp_hi, pred_hi, zero_division=0)), 4),
        "log_loss": round(float(log_loss(y_true, p, labels=classes)), 4),
        "brier": round(multiclass_brier(y_true, proba, classes), 4),
        "ece": round(ece, 4),
        "mean_confidence": round(float(proba.max(axis=1).mean()), 4),
    }


def adoption_decision(cv, chosen):
    """
    Documented selection objective (fixed in advance; uses nested
    out-of-fold results on the TRAINING split only):

      1. Among sigmoid (Platt) and isotonic, the CANDIDATE is the one with the
         lowest out-of-fold log loss (ties -> sigmoid, the simpler method).
      2. The candidate replaces raw probabilities only if ALL hold versus raw:
           - log loss is lower
           - Brier score is not higher        (proper score must not degrade)
           - ECE is not higher
           - accuracy is not lower by more than 0.005
           - high-impact (P1/P2) recall is not lower by more than 0.005
      3. Otherwise raw probabilities stay in production.
    The held-out test set and the robustness cases are reported afterwards and
    are never used for this decision.
    """
    raw, cand = cv["raw"], cv[chosen]
    checks = {
        "log_loss_lower": cand["log_loss"] < raw["log_loss"],
        "brier_not_higher": cand["brier"] <= raw["brier"],
        "ece_not_higher": cand["ece"] <= raw["ece"],
        "accuracy_not_lower_by_more_than_0.005": cand["accuracy"] >= raw["accuracy"] - 0.005,
        "high_impact_recall_not_lower_by_more_than_0.005": cand["high_impact_recall"] >= raw["high_impact_recall"] - 0.005,
    }
    return all(checks.values()), {k: bool(v) for k, v in checks.items()}


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--adopt", action="store_true",
                    help="save the calibrated model even if the adoption rule says no "
                         "(opt-in; predict.py will then prefer it)")
    args = ap.parse_args()
    warnings.filterwarnings("ignore", category=FutureWarning)
    df = pd.read_csv(DATA_PATH)
    X, y = df[FEATURES], df[TARGET]
    X_train, X_test, y_train, y_test = train_test_split(
        X, y, test_size=0.20, random_state=RANDOM_STATE, stratify=y)
    X_train = X_train.reset_index(drop=True)
    y_train = y_train.reset_index(drop=True)
    print(f"Train {len(X_train)} / Test {len(X_test)} (same split as train_model.py)")

    # --------------------------------------------------------------
    # 1. method selection: nested out-of-fold on TRAINING data only
    # --------------------------------------------------------------
    methods = {"raw": None, "sigmoid": "sigmoid", "isotonic": "isotonic"}
    oof = {k: np.zeros((len(X_train), len(LABELS))) for k in methods}
    outer = StratifiedKFold(n_splits=5, shuffle=True, random_state=RANDOM_STATE)
    for fold, (tr, va) in enumerate(outer.split(X_train, y_train), 1):
        for name, method in methods.items():
            if method is None:
                est = build_base_pipeline().fit(X_train.iloc[tr], y_train.iloc[tr])
            else:
                est = CalibratedClassifierCV(build_base_pipeline(), method=method, cv=5)
                est.fit(X_train.iloc[tr], y_train.iloc[tr])
            assert list(est.classes_) == LABELS
            oof[name][va] = est.predict_proba(X_train.iloc[va])
        print(f"  outer fold {fold}/5 done")

    cv_results = {k: summarise(y_train, oof[k], LABELS) for k in methods}
    cv_results_full = cv_results
    # candidate = lowest out-of-fold log loss; ties prefer the simpler sigmoid method
    chosen = min(["sigmoid", "isotonic"], key=lambda k: (cv_results[k]["log_loss"], k != "sigmoid"))
    improves, rule_checks = adoption_decision(cv_results, chosen)
    adopted = bool(improves or args.adopt)
    print("\nNested CV on training data:")
    print(pd.DataFrame(cv_results).T.to_string())
    print(f"\nBest calibration method by log loss: {chosen}; "
          f"improves on raw: {improves}")

    # --------------------------------------------------------------
    # 2. fit final models on the training portion only
    # --------------------------------------------------------------
    raw_model = build_base_pipeline().fit(X_train, y_train)
    finals = {"raw": raw_model}
    for name in ("sigmoid", "isotonic"):
        m = CalibratedClassifierCV(build_base_pipeline(), method=name, cv=5)
        m.fit(X_train, y_train)
        assert list(m.classes_) == LABELS
        finals[name] = m
    cal_model = finals[chosen]

    # --------------------------------------------------------------
    # 3. one-time reporting on held-out test + robustness (NOT used for fitting)
    # --------------------------------------------------------------
    report = {
        "sklearn_version": __import__("sklearn").__version__,
        "method_candidates": list(methods),
        "selection_data": "5-fold nested out-of-fold on the 80% training split only",
        "chosen_method": chosen,
        "model": "Logistic Regression (balanced class weights) in the production Pipeline; "
                 "'sigmoid' = Platt scaling (sklearn CalibratedClassifierCV, one-vs-rest sigmoid + normalisation)",
        "adoption_rule": adoption_decision.__doc__.strip(),
        "rule_checks_for_candidate": rule_checks,
        "rule_satisfied": bool(improves),
        "random_state": RANDOM_STATE,
        "split": "stratified 80/20 (random_state=42), identical to train_model.py; calibration CV folds seeded with the same value",
        "calibrated_model_adopted": adopted,
        "cv_train_oof": cv_results,
        "thresholds_unchanged": {"LOW_CONFIDENCE_THRESHOLD": LOW_T, "HIGH_CONFIDENCE_THRESHOLD": HIGH_T},
    }
    sets = {"heldout_test_synthetic": (X_test, y_test)}
    if ROBUST_PATH.exists():
        # Reporting only. Cases whose true priority is ambiguous by design
        # (conflict_type != none) are excluded from probabilistic scoring.
        rob = pd.read_csv(ROBUST_PATH)
        if ROBUST_EXT_PATH.exists():
            ext = pd.read_csv(ROBUST_EXT_PATH)
            rob = pd.concat([rob, ext[ext["conflict_type"] == "none"]], ignore_index=True)
        sets["robustness_cases"] = (rob[FEATURES], rob["expected_priority"])
    curve_rows = []
    for name, (Xs, ys) in sets.items():
        pr = raw_model.predict_proba(Xs)
        pc = cal_model.predict_proba(Xs)
        report[name] = {
            "n": int(len(ys)),
            "raw": summarise(ys, pr, LABELS),
            "calibrated": summarise(ys, pc, LABELS),
            "candidates": {k: summarise(ys, finals[k].predict_proba(Xs), LABELS) for k in finals},
            "routing_bands_raw": routing_counts(pr, LABELS),
            "routing_bands_calibrated": routing_counts(pc, LABELS),
        }
        for label, p in (("raw", pr), ("calibrated", pc)):
            rows, _ = reliability(ys, p, LABELS)
            for r in rows:
                curve_rows.append({"dataset": name, "model": label, **r})
        # confidence when wrong
        for label, p in (("raw", pr), ("calibrated", pc)):
            pred = np.array(LABELS)[p.argmax(axis=1)]
            wrong = pred != np.asarray(ys)
            report[name][f"{label}_wrong_predictions"] = int(wrong.sum())
            report[name][f"{label}_wrong_with_conf_ge_80"] = int((wrong & (p.max(axis=1) >= HIGH_T)).sum())
            report[name][f"{label}_mean_conf_when_wrong"] = (
                round(float(p.max(axis=1)[wrong].mean()), 4) if wrong.any() else None)

    # prediction agreement between raw and calibrated argmax
    pr, pc = raw_model.predict_proba(X_test), cal_model.predict_proba(X_test)
    report["heldout_test_synthetic"]["argmax_agreement_raw_vs_calibrated"] = round(
        float((pr.argmax(1) == pc.argmax(1)).mean()), 4)

    # --------------------------------------------------------------
    # 4. threshold assessment (documentation only; no threshold is changed)
    # --------------------------------------------------------------
    ht = report["heldout_test_synthetic"]
    report["threshold_assessment"] = {
        "decision": "NOT CHANGED (0.60 / 0.80 kept)",
        "reason": ("Thresholds are retained unless calibration shows they are technically "
                   "inappropriate. See routing bands and ECE above; compare raw vs calibrated."),
        "heldout_routing_raw": ht["routing_bands_raw"],
        "heldout_routing_calibrated": ht["routing_bands_calibrated"],
    }

    # --------------------------------------------------------------
    # 5. save
    # --------------------------------------------------------------
    REPORT_DIR.mkdir(exist_ok=True)
    pd.DataFrame(curve_rows).to_csv(REPORT_DIR / "calibration_curve.csv", index=False)
    (REPORT_DIR / "calibration_report.json").write_text(json.dumps(report, indent=2))
    if adopted:
        joblib.dump(cal_model, CAL_MODEL_PATH)
        print(f"\nSaved calibrated model: {CAL_MODEL_PATH.relative_to(BASE_DIR)}")
    else:
        if CAL_MODEL_PATH.exists():
            CAL_MODEL_PATH.unlink()
        print("\nAdoption rule not met (mixed evidence: see report); calibrated model NOT "
              "saved, predict.py keeps using the original. Use --adopt to opt in.")

    # human-readable report
    cols = ["accuracy", "macro_precision", "macro_recall", "macro_f1", "high_impact_recall",
            "log_loss", "brier", "ece"]

    def md_table(block):
        out = ["| Method | " + " | ".join(cols) + " |", "|---|" + "---|" * len(cols)]
        for k in ("raw", "sigmoid", "isotonic"):
            out.append(f"| {k} | " + " | ".join(f"{block[k][c]:.4f}" for c in cols) + " |")
        return "\n".join(out)

    lines = ["# Calibration report", "",
             "Model: Logistic Regression (production pipeline). Candidates: Raw, Sigmoid (Platt), Isotonic.", "",
             "## Selection objective", "", "```", adoption_decision.__doc__.strip(), "```", "",
             "## Nested cross-validation on the training split (used for the decision)", "",
             md_table(cv_results_full), "",
             f"Candidate (lowest log loss): **{chosen}**. Checks vs raw: " +
             ", ".join(f"{k}={'PASS' if v else 'FAIL'}" for k, v in rule_checks.items()) + ".", "",
             f"**Decision: {'calibrated model ADOPTED' if improves else 'raw probabilities KEPT'}**"
             + ("" if improves else " (the candidate failed at least one check above)."), ""]
    for name, title in (("heldout_test_synthetic", "Held-out synthetic test split (reporting only)"),
                        ("robustness_cases", "Robustness cases, non-conflict (reporting only)")):
        if name in report:
            lines += [f"## {title}", "", md_table(report[name]["candidates"]), ""]
    lines += ["Thresholds unchanged: LOW_CONFIDENCE_THRESHOLD = 0.60, HIGH_CONFIDENCE_THRESHOLD = 0.80.", "",
              "Reliability bins: reports/calibration_curve.csv. Synthetic data: results do not imply real-world calibration."]
    (REPORT_DIR / "calibration_report.md").write_text("\n".join(lines) + "\n", encoding="utf-8")

    print("\nHeld-out synthetic test (reporting only):")
    print(pd.DataFrame({"raw": ht["raw"], "calibrated": ht["calibrated"]}).T.to_string())
    if "robustness_cases" in report:
        rb = report["robustness_cases"]
        print("\nRobustness cases (reporting only):")
        print(pd.DataFrame({"raw": rb["raw"], "calibrated": rb["calibrated"]}).T.to_string())
    print("\nSaved reports/calibration_report.json and reports/calibration_curve.csv")


if __name__ == "__main__":
    main()

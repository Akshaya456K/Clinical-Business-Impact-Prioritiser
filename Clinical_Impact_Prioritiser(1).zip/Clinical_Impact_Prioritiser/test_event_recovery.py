"""
Explicit event-processing, ordering and state-recovery tests.

Complements test_event_processor.py (unchanged) and test_event_contracts.py
(schema contract). Each test name maps to one of the requirements:

  1 duplicate event            2 duplicate with same ID     3 out-of-order
  4 delayed event              5 stale event                6 version gap
  7 malformed event            8 missing required field    9 invalid field type
 10 independent streams       11 state recovery            12 state preservation
 13 replayed event            14 idempotency               15 conflicting event
 16 event arriving after a newer version

"State recovery" here means: whatever order or repetition the transport
delivers events in, the processor converges to the state defined by the
highest-version valid event per ticket, and late/duplicate/garbage events never
regress it. Crash persistence (snapshot/restore to disk) is not implemented and
is therefore not tested.

Run:  python -m unittest test_event_recovery -v
"""
import copy
import itertools
import random
import unittest

from event_processor import INVALID_EVENT_STATUS, TicketEventProcessor, validate_event


def ev(eid, version, ticket="T1", priority="P3", etype="PRIORITY_UPDATED", **extra):
    e = {
        "event_id": eid,
        "ticket_id": ticket,
        "event_type": etype,
        "event_timestamp": f"2026-08-27T09:{version:02d}:00",
        "event_version": version,
        "data": {"priority": priority},
    }
    e.update(extra)
    return e


STREAM = [ev("E1", 1, priority="P4", etype="TICKET_CREATED"),
          ev("E2", 2, priority="P3"),
          ev("E3", 3, priority="P2"),
          ev("E4", 4, priority="P1"),
          ev("E5", 5, priority="P1")]


def final_state(events, ticket="T1"):
    p = TicketEventProcessor()
    for e in events:
        p.process_event(copy.deepcopy(e))
    return p.get_ticket_state(ticket)


class TestDuplicates(unittest.TestCase):

    def test_01_duplicate_event_is_ignored(self):
        p = TicketEventProcessor()
        p.process_event(ev("E1", 1))
        r = p.process_event(ev("E1", 1))
        self.assertEqual(r["status"], "DUPLICATE_IGNORED")
        self.assertEqual(p.get_ticket_state("T1")["latest_version"], 1)

    def test_02_duplicate_event_id_with_different_payload_first_write_wins(self):
        """Same event_id, tampered payload/version: treated as a duplicate."""
        p = TicketEventProcessor()
        p.process_event(ev("E1", 1, priority="P2"))
        r = p.process_event(ev("E1", 9, priority="P1"))
        self.assertEqual(r["status"], "DUPLICATE_IGNORED")
        s = p.get_ticket_state("T1")
        self.assertEqual((s["latest_version"], s["data"]["priority"]), (1, "P2"))

    def test_02b_duplicate_across_tickets_uses_global_event_id(self):
        """Documented behaviour: event_id is globally unique, not per ticket."""
        p = TicketEventProcessor()
        p.process_event(ev("E1", 1, ticket="A"))
        r = p.process_event(ev("E1", 1, ticket="B"))
        self.assertEqual(r["status"], "DUPLICATE_IGNORED")
        self.assertIsNone(p.get_ticket_state("B"))


class TestOrdering(unittest.TestCase):

    def test_03_out_of_order_event_does_not_overwrite_newer_state(self):
        p = TicketEventProcessor()
        p.process_event(ev("E3", 3, priority="P1"))
        r = p.process_event(ev("E2", 2, priority="P4"))
        self.assertEqual(r["status"], "OUT_OF_ORDER_IGNORED")
        self.assertEqual(p.get_ticket_state("T1")["data"]["priority"], "P1")

    def test_04_delayed_event_arriving_late_is_ignored(self):
        p = TicketEventProcessor()
        for e in (STREAM[0], STREAM[2]):
            p.process_event(e)
        r = p.process_event(STREAM[1])  # v2 delivered after v3
        self.assertEqual(r["status"], "OUT_OF_ORDER_IGNORED")
        self.assertEqual(p.get_ticket_state("T1")["latest_version"], 3)

    def test_05_stale_event_same_version_is_ignored(self):
        p = TicketEventProcessor()
        p.process_event(ev("E1", 2, priority="P2"))
        r = p.process_event(ev("E2", 2, priority="P4"))
        self.assertEqual(r["status"], "STALE_EVENT_IGNORED")
        self.assertEqual(p.get_ticket_state("T1")["data"]["priority"], "P2")

    def test_06_version_gap_is_applied_and_late_gap_events_are_ignored(self):
        p = TicketEventProcessor()
        p.process_event(ev("E1", 1))
        self.assertEqual(p.process_event(ev("E4", 4, priority="P1"))["status"], "APPLIED")
        for v in (2, 3):  # the missing versions arrive late
            self.assertEqual(p.process_event(ev(f"L{v}", v, priority="P4"))["status"],
                             "OUT_OF_ORDER_IGNORED")
        s = p.get_ticket_state("T1")
        self.assertEqual((s["latest_version"], s["data"]["priority"]), (4, "P1"))

    def test_16_event_arriving_after_a_newer_version_never_regresses_state(self):
        p = TicketEventProcessor()
        p.process_event(ev("E5", 5, priority="P1"))
        for v in range(0, 5):
            p.process_event(ev(f"O{v}", v, priority="P4"))
        s = p.get_ticket_state("T1")
        self.assertEqual((s["latest_version"], s["data"]["priority"]), (5, "P1"))


class TestMalformedAndSchema(unittest.TestCase):

    def setUp(self):
        self.p = TicketEventProcessor()
        self.p.process_event(ev("E1", 1, priority="P2"))
        self.before = copy.deepcopy(self.p.get_ticket_state("T1"))

    def assert_rejected_state_intact(self, event):
        r = self.p.process_event(event)
        self.assertEqual(r["status"], INVALID_EVENT_STATUS)
        self.assertTrue(r["errors"])
        self.assertEqual(self.p.get_ticket_state("T1"), self.before)

    def test_07_malformed_event_fails_safely(self):
        for bad in (None, 42, "text", [], ["E2"], {}, object()):
            self.assert_rejected_state_intact(bad)

    def test_08_missing_required_field_each_field(self):
        for field in ("event_id", "ticket_id", "event_type", "event_timestamp", "event_version"):
            e = ev("E2", 2)
            del e[field]
            self.assertIn(f"Missing required field: {field}", validate_event(e))
            self.assert_rejected_state_intact(e)

    def test_09_invalid_field_types(self):
        cases = {
            "event_version": ["2", 2.0, None, True, -1, [2]],
            "event_timestamp": ["not-a-date", "", 12345, None, ["2026-08-27"]],
            "event_type": ["", "  ", 7, None],
            "event_id": ["", None, [], {}, True],
            "ticket_id": ["", None, [], {}],
            "data": ["P1", 5, ["P1"]],
        }
        for field, values in cases.items():
            for v in values:
                with self.subTest(field=field, value=v):
                    e = ev("E2", 2)
                    e[field] = v
                    self.assert_rejected_state_intact(e)

    def test_valid_payload_variants(self):
        for data in ({}, None, {"nested": {"a": [1, 2]}}):
            e = ev(f"P{id(data)}", 2)
            e["data"] = data
            self.assertEqual(validate_event(e), [])

    def test_rejected_event_can_be_resent_corrected(self):
        bad = ev("E2", 2)
        bad["event_version"] = "2"
        self.assertEqual(self.p.process_event(bad)["status"], INVALID_EVENT_STATUS)
        self.assertEqual(self.p.process_event(ev("E2", 2, priority="P1"))["status"], "APPLIED")


class TestIndependenceAndPreservation(unittest.TestCase):

    def test_10_independent_ticket_streams(self):
        p = TicketEventProcessor()
        p.process_event(ev("A1", 5, ticket="A", priority="P1"))
        p.process_event(ev("B1", 1, ticket="B", priority="P4"))
        # an old version on B must not be judged against A's version
        self.assertEqual(p.process_event(ev("B2", 2, ticket="B", priority="P3"))["status"], "APPLIED")
        self.assertEqual(p.get_ticket_state("A")["latest_version"], 5)
        self.assertEqual(p.get_ticket_state("B")["latest_version"], 2)

    def test_12_state_preservation_after_ignored_and_rejected_events(self):
        p = TicketEventProcessor()
        for e in STREAM:
            p.process_event(e)
        snapshot = copy.deepcopy(p.get_ticket_state("T1"))
        for junk in (STREAM[0], ev("X", 1), ev("Y", 5, priority="P4"), {"bad": 1}, None):
            p.process_event(copy.deepcopy(junk) if isinstance(junk, dict) else junk)
        self.assertEqual(p.get_ticket_state("T1"), snapshot)

    def test_12b_state_is_isolated_from_caller_mutation_of_the_event(self):
        """Mutating the event dict after processing must not alter stored state."""
        p = TicketEventProcessor()
        e = ev("E1", 1, priority="P2")
        p.process_event(e)
        e["data"]["priority"] = "TAMPERED"
        self.assertEqual(p.get_ticket_state("T1")["data"]["priority"], "P2")

    def test_12c_state_is_isolated_from_mutation_of_the_returned_state(self):
        """Mutating what get_ticket_state returned must not alter stored state."""
        p = TicketEventProcessor()
        p.process_event(ev("E1", 1, priority="P2"))
        p.get_ticket_state("T1")["data"]["priority"] = "TAMPERED"
        p.get_ticket_state("T1")["latest_version"] = 999
        s = p.get_ticket_state("T1")
        self.assertEqual((s["latest_version"], s["data"]["priority"]), (1, "P2"))


class TestRecoveryReplayIdempotency(unittest.TestCase):

    def test_11_state_recovery_every_delivery_order_converges(self):
        """All 120 orderings of 5 versioned events end in the same state."""
        expected = final_state(STREAM)
        self.assertEqual((expected["latest_version"], expected["data"]["priority"]), (5, "P1"))
        for perm in itertools.permutations(STREAM):
            self.assertEqual(final_state(perm), expected, [e["event_id"] for e in perm])

    def test_11b_recovery_with_duplicates_gaps_and_garbage_mixed_in(self):
        rng = random.Random(42)
        expected = final_state(STREAM)
        for _ in range(200):
            delivery = STREAM * 2 + [{"junk": True}, None, ev("Z", 0, priority="P4")]
            rng.shuffle(delivery)
            self.assertEqual(final_state([d for d in delivery]), expected)

    def test_11c_recovery_with_lost_events_uses_highest_received_version(self):
        lost = [STREAM[1], STREAM[3]]  # v2 and v4 never arrive
        received = [e for e in STREAM if e not in lost]
        s = final_state(list(reversed(received)))
        self.assertEqual(s["latest_version"], 5)

    def test_13_replayed_event_stream_is_ignored(self):
        p = TicketEventProcessor()
        for e in STREAM:
            p.process_event(copy.deepcopy(e))
        before = copy.deepcopy(p.get_ticket_state("T1"))
        statuses = [p.process_event(copy.deepcopy(e))["status"] for e in STREAM]
        self.assertEqual(set(statuses), {"DUPLICATE_IGNORED"})
        self.assertEqual(p.get_ticket_state("T1"), before)

    def test_14_idempotency_applying_a_stream_n_times_equals_once(self):
        once = final_state(STREAM)
        for n in (2, 3, 5):
            self.assertEqual(final_state(STREAM * n), once)

    def test_14b_each_event_applied_at_most_once(self):
        p = TicketEventProcessor()
        results = [p.process_event(copy.deepcopy(e))["status"] for e in STREAM * 3]
        self.assertEqual(results.count("APPLIED"), len(STREAM))

    def test_15_conflicting_events_same_version_first_applied_wins(self):
        a = ev("A", 3, priority="P1")
        b = ev("B", 3, priority="P4")
        self.assertEqual(final_state([a, b])["data"]["priority"], "P1")
        self.assertEqual(final_state([b, a])["data"]["priority"], "P4")
        # documented limitation: ties are broken by arrival order, not content

    def test_15b_conflicting_event_with_higher_version_supersedes(self):
        s = final_state([ev("A", 3, priority="P4"), ev("B", 4, priority="P1")])
        self.assertEqual(s["data"]["priority"], "P1")

    def test_audit_log_records_every_outcome(self):
        p = TicketEventProcessor()
        for e in (STREAM[0], STREAM[0], STREAM[2], STREAM[1], {"bad": 1}):
            p.process_event(copy.deepcopy(e) if isinstance(e, dict) else e)
        self.assertEqual([r["status"] for r in p.event_log],
                         ["APPLIED", "DUPLICATE_IGNORED", "APPLIED",
                          "OUT_OF_ORDER_IGNORED", INVALID_EVENT_STATUS])


if __name__ == "__main__":
    unittest.main(verbosity=2)

# Full evaluation report

> All data are synthetic or hand-written. Not clinical validation. Decision-support prototype only.

## Environment and reproducibility

- Python 3.13.16, scikit-learn 1.9.1, pandas 3.0.5, numpy 2.5.3
- random_state = 42; split: stratified 80/20, random_state=42 (train_model.py, calibrate_model.py, train_signal_models.py)
- Artifact hashes: `hospital_it_tickets.csv`=0bdfff5734997974, `models/priority_model.joblib`=97c4fda1ac6e138c, `models/signal_text_model.joblib`=ca1ba4205fc22c46, `models/signal_structured_model.joblib`=03d94da5d939040e, `robustness/robustness_test_cases.csv`=b19b4bffd516caea, `robustness/robustness_extended_cases.csv`=f104ab2f622ef54d

## Baseline vs ML (held-out 400 synthetic tickets)

| Model | accuracy | macro P | macro R | macro F1 | high-impact P | high-impact R | high-impact F1 |
|---|---|---|---|---|---|---|---|
| Rule-based baseline | 0.5825 | 0.6214 | 0.6453 | 0.6078 | 0.6272 | 0.8833 | 0.7336 |
| Logistic Regression | 0.9975 | 0.9969 | 0.9938 | 0.9953 | 1.0 | 1.0 | 1.0 |

## Performance

- Batch model.predict: 0.0249 ms/ticket
- End-to-end `process_ticket`: avg 5.449 ms, p50 5.962, p95 7.005, p99 7.801 ms, max 9.254 ms; throughput 183.5 tickets/s; target 1000.0 ms met at p99: True

## Safety (held-out synthetic tickets)

- action_counts: {'ACCEPT': 280, 'PRIORITY_ESCALATION': 75, 'URGENT_ESCALATION': 39, 'HUMAN_REVIEW': 6}
- human_review_rate: 0.015
- low_confidence_routed_to_review: 6
- high_impact_false_acceptance: 0
- high_impact_false_acceptance_rate: 0.0
- false_rejection_low_impact_not_accepted: 0
- false_rejection_rate: 0.0
- conflict_flags_raised: 0
- confidence_type: ['raw']

## Robustness: Overall (225 cases)

- Priority accuracy (non-conflict cases): 0.9293 ; high-impact P/R/F1: 0.9051/0.8732/0.8889
- False acceptance (possible high-impact auto-ACCEPTed): 3 (2.0%)
- False rejection (routine ticket not accepted): 8 (11.0%); review 4, escalation 4
- Human-review rate: 12.4%; text-high/fields-low conflicts routed to HUMAN_REVIEW: 13/14

## Robustness: First-round suite (110)

- Priority accuracy (non-conflict cases): 0.8909 ; high-impact P/R/F1: 0.9315/0.9444/0.9379
- False acceptance (possible high-impact auto-ACCEPTed): 0 (0.0%)
- False rejection (routine ticket not accepted): 7 (18.4%); review 3, escalation 4
- Human-review rate: 10.9%; text-high/fields-low conflicts routed to HUMAN_REVIEW: 0/0

## Robustness: Extended suite (115, written before the safety upgrade)

- Priority accuracy (non-conflict cases): 0.9773 ; high-impact P/R/F1: 0.875/0.8/0.8358
- False acceptance (possible high-impact auto-ACCEPTed): 3 (3.8%)
- False rejection (routine ticket not accepted): 1 (2.9%); review 1, escalation 0
- Human-review rate: 13.9%; text-high/fields-low conflicts routed to HUMAN_REVIEW: 13/14

### Per category, both suites

| category | n | scored | accuracy | hi-recall | hi-precision | false-accept | over-review | over-escalation |
|---|---|---|---|---|---|---|---|---|
| clean | 14 | 14 | 1.0 | 1.0 | 1.0 | 0 | 0 | 0 |
| spelling | 25 | 25 | 1.0 | 1.0 | 1.0 | 0 | 0 | 0 |
| abbreviations | 25 | 25 | 0.96 | 1.0 | 1.0 | 0 | 1 | 0 |
| noisy | 35 | 35 | 1.0 | 1.0 | 1.0 | 0 | 0 | 0 |
| paraphrased | 24 | 24 | 1.0 | 1.0 | 1.0 | 0 | 2 | 0 |
| multi_system | 24 | 24 | 0.917 | 1.0 | 0.944 | 0 | 1 | 0 |
| adversarial | 39 | 35 | 0.971 | 0.871 | 1.0 | 1 | 0 | 0 |
| misleading_metadata | 13 | 2 | 1.0 | 0.125 | 0.2 | 0 | 0 | 0 |
| mixed_signals | 26 | 14 | 0.286 | 0.364 | 0.333 | 2 | 0 | 4 |

### Per category, extended suite only

| category | n | scored | accuracy | hi-recall | hi-precision | false-accept | over-review | over-escalation |
|---|---|---|---|---|---|---|---|---|
| clean | 14 | 14 | 1.0 | 1.0 | 1.0 | 0 | 0 | 0 |
| spelling | 13 | 13 | 1.0 | 1.0 | 1.0 | 0 | 0 | 0 |
| abbreviations | 13 | 13 | 0.923 | 1.0 | 1.0 | 0 | 0 | 0 |
| noisy | 13 | 13 | 1.0 | 1.0 | 1.0 | 0 | 0 | 0 |
| paraphrased | 12 | 12 | 1.0 | 1.0 | 1.0 | 0 | 1 | 0 |
| multi_system | 12 | 12 | 0.917 | 1.0 | 1.0 | 0 | 0 | 0 |
| adversarial | 13 | 9 | 1.0 | 0.6 | 1.0 | 1 | 0 | 0 |
| misleading_metadata | 13 | 2 | 1.0 | 0.125 | 0.2 | 0 | 0 | 0 |
| mixed_signals | 12 | 0 | nan | 0.0 | 0.0 | 2 | 0 | 0 |

### Known false acceptances (not hidden)

- X087 (adversarial): Surgeons are delaying the start of lists because they cannot see the information they need.
- X110 (mixed_signals): Something is not right with the system, people are complaining.
- X111 (mixed_signals): Please look into it as soon as possible.

## Calibration

Decision: **raw probabilities kept** (candidate by log loss: isotonic; checks: log_loss_lower=PASS, brier_not_higher=FAIL, ece_not_higher=PASS, accuracy_not_lower_by_more_than_0.005=PASS, high_impact_recall_not_lower_by_more_than_0.005=PASS)

### Nested CV on training split (decision data)

| method | accuracy | macro F1 | hi-recall | log loss | Brier | ECE |
|---|---|---|---|---|---|---|
| raw | 0.9975 | 0.9969 | 0.9938 | 0.0471 | 0.0089 | 0.0407 |
| sigmoid | 0.9975 | 0.9969 | 0.9958 | 0.0524 | 0.0174 | 0.043 |
| isotonic | 0.9981 | 0.9975 | 0.9958 | 0.0196 | 0.0092 | 0.0125 |

### Held-out synthetic test (reporting)

| method | accuracy | macro F1 | hi-recall | log loss | Brier | ECE |
|---|---|---|---|---|---|---|
| raw | 0.9975 | 0.9953 | 1.0 | 0.0402 | 0.0085 | 0.0339 |
| sigmoid | 0.995 | 0.9927 | 0.9917 | 0.0489 | 0.0186 | 0.0366 |
| isotonic | 0.9975 | 0.9953 | 1.0 | 0.0199 | 0.0106 | 0.0128 |

### Robustness non-conflict cases (reporting)

| method | accuracy | macro F1 | hi-recall | log loss | Brier | ECE |
|---|---|---|---|---|---|---|
| raw | 0.9293 | 0.927 | 0.9688 | 0.3788 | 0.1179 | 0.0253 |
| sigmoid | 0.9293 | 0.9249 | 0.9609 | 0.39 | 0.1282 | 0.0358 |
| isotonic | 0.9293 | 0.9304 | 0.9766 | 0.7082 | 0.132 | 0.056 |

## Test results

| suite | tests | passed | failures | errors |
|---|---|---|---|---|
| test_event_contracts | 59 | 59 | 0 | 0 |
| test_event_recovery | 26 | 26 | 0 | 0 |
| test_safety_layer | 30 | 30 | 0 | 0 |
| test_ml_pipeline | 28 | 28 | 0 | 0 |
| test_robustness_suite | 20 | 20 | 0 | 0 |
| test_event_processor (original) | 4 | 4 | 0 | 0 |
| **total** | **167** | **167** | | |


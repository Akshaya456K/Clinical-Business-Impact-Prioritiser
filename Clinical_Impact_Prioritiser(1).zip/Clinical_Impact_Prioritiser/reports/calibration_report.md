# Calibration report

Model: Logistic Regression (production pipeline). Candidates: Raw, Sigmoid (Platt), Isotonic.

## Selection objective

```
Documented selection objective (fixed in advance; uses nested
out-of-fold results on the TRAINING split only):

  1. Among sigmoid (Platt) and isotonic, the CANDIDATE is the one with the
     lowest out-of-fold log loss (ties -> sigmoid, the simpler method).
  2. The candidate replaces raw probabilities only if ALL hold versus raw:
       - log loss is lower
       - Brier score is not higher        (proper score must not degrade)
       - ECE is not higher
       - accuracy is not lower by more than 0.005
       - high-impact (P1/P2) recall is not lower by more than 0.005
  3. Otherwise raw probabilities stay in production.
The held-out test set and the robustness cases are reported afterwards and
are never used for this decision.
```

## Nested cross-validation on the training split (used for the decision)

| Method | accuracy | macro_precision | macro_recall | macro_f1 | high_impact_recall | log_loss | brier | ece |
|---|---|---|---|---|---|---|---|---|
| raw | 0.9975 | 0.9977 | 0.9961 | 0.9969 | 0.9938 | 0.0471 | 0.0089 | 0.0407 |
| sigmoid | 0.9975 | 0.9974 | 0.9964 | 0.9969 | 0.9958 | 0.0524 | 0.0174 | 0.0430 |
| isotonic | 0.9981 | 0.9982 | 0.9969 | 0.9975 | 0.9958 | 0.0196 | 0.0092 | 0.0125 |

Candidate (lowest log loss): **isotonic**. Checks vs raw: log_loss_lower=PASS, brier_not_higher=FAIL, ece_not_higher=PASS, accuracy_not_lower_by_more_than_0.005=PASS, high_impact_recall_not_lower_by_more_than_0.005=PASS.

**Decision: raw probabilities KEPT** (the candidate failed at least one check above).

## Held-out synthetic test split (reporting only)

| Method | accuracy | macro_precision | macro_recall | macro_f1 | high_impact_recall | log_loss | brier | ece |
|---|---|---|---|---|---|---|---|---|
| raw | 0.9975 | 0.9969 | 0.9938 | 0.9953 | 1.0000 | 0.0402 | 0.0085 | 0.0339 |
| sigmoid | 0.9950 | 0.9948 | 0.9906 | 0.9927 | 0.9917 | 0.0489 | 0.0186 | 0.0366 |
| isotonic | 0.9975 | 0.9969 | 0.9938 | 0.9953 | 1.0000 | 0.0199 | 0.0106 | 0.0128 |

## Robustness cases, non-conflict (reporting only)

| Method | accuracy | macro_precision | macro_recall | macro_f1 | high_impact_recall | log_loss | brier | ece |
|---|---|---|---|---|---|---|---|---|
| raw | 0.9293 | 0.9241 | 0.9309 | 0.9270 | 0.9688 | 0.3788 | 0.1179 | 0.0253 |
| sigmoid | 0.9293 | 0.9197 | 0.9309 | 0.9249 | 0.9609 | 0.3900 | 0.1282 | 0.0358 |
| isotonic | 0.9293 | 0.9312 | 0.9309 | 0.9304 | 0.9766 | 0.7082 | 0.1320 | 0.0560 |

Thresholds unchanged: LOW_CONFIDENCE_THRESHOLD = 0.60, HIGH_CONFIDENCE_THRESHOLD = 0.80.

Reliability bins: reports/calibration_curve.csv. Synthetic data: results do not imply real-world calibration.

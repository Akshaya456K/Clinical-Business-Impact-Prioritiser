"""
Environment / dependency verification tests.

Run:  python -m pytest test_environment.py -v
"""
import unittest
from pathlib import Path

import env_check
from env_check import EnvironmentMismatchError, check_sklearn_version

BASE = Path(__file__).resolve().parent


class TestSklearnVersionCheck(unittest.TestCase):

    def test_requirements_pin_is_exact(self):
        self.assertEqual(env_check.required_sklearn_version(), "1.9.1")

    def test_installed_version_matches_declared_requirement(self):
        import sklearn
        self.assertEqual(check_sklearn_version(), sklearn.__version__)

    def test_mismatch_raises_actionable_error(self):
        with self.assertRaises(EnvironmentMismatchError) as ctx:
            check_sklearn_version(installed="1.8.0", required="1.9.1")
        msg = str(ctx.exception)
        self.assertIn("1.8.0", msg)
        self.assertIn("scikit-learn==1.9.1", msg)
        self.assertIn("pip install -r requirements.txt", msg)

    def test_newer_untested_version_also_rejected(self):
        with self.assertRaises(EnvironmentMismatchError):
            check_sklearn_version(installed="1.10.0", required="1.9.1")

    def test_missing_pin_is_an_error(self):
        import tempfile
        with tempfile.TemporaryDirectory() as d:
            p = Path(d) / "requirements.txt"
            p.write_text("pandas\nscikit-learn>=1.0\n")
            with self.assertRaises(EnvironmentMismatchError):
                env_check.required_sklearn_version(p)

    def test_predict_checks_version_before_loading_models(self):
        code = (BASE / "predict.py").read_text()
        self.assertLess(code.index("check_sklearn_version()"),
                        code.index("model, MODEL_SOURCE = _load_model()"))


if __name__ == "__main__":
    unittest.main()
